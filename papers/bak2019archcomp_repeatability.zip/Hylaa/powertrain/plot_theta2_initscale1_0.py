'''
Created by Hyst v1.6
Hybrid Automaton in Hylaa2
Converted from file: 
Command Line arguments: -gen drivetrain "-theta 2 -init_scale 1.0 -reverse_errors -switch_time 0.20001" -passes sub_constants "" simplify -p -o hylaa_drivetrain_theta2_initscale1_0.py -tool hylaa "-settings settings.aggstrat=aggstrat.Unaggregated()"
'''

import sys
from matplotlib import collections

import numpy as np

from hylaa.hybrid_automaton import HybridAutomaton
from hylaa.settings import HylaaSettings, PlotSettings
from hylaa.core import Core
from hylaa.stateset import StateSet
from hylaa import lputil, aggstrat

def define_ha():
    '''make the hybrid automaton and return it'''

    ha = HybridAutomaton()

    # dynamics variable order: [x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, t, affine]

    negAngle = ha.new_mode('negAngle')
    a_matrix = [ \
        [0, 0, 0, 0, 0, 0, 0.0833333333333333, 0, -1, 0, 0, 0, 0], \
        [13828.8888888889, -26.6666666666667, 60, 60, 0, 0, -5, -60, 0, 0, 0, 0, 716.666666666667], \
        [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5], \
        [0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0], \
        [0, 0, 0, 0, -714.285714285714, -0.04, 0, 0, 0, 714.285714285714, 0, 0, 0], \
        [-2777.77777777778, 3.33333333333333, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -83.3333333333333], \
        [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0], \
        [100, 0, 0, 0, 0, 0, 0, -1000, -0.01, 1000, 0, 0, 3], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0], \
        [0, 0, 0, 0, 1000, 0, 0, 1000, 0, -2000, -0.01, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        ]
    negAngle.set_dynamics(a_matrix)
    # x1 <= -0.03
    negAngle.set_invariant([[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], ], [-0.03, ])

    deadzone = ha.new_mode('deadzone')
    a_matrix = [ \
        [0, 0, 0, 0, 0, 0, 0.0833333333333333, 0, -1, 0, 0, 0, 0], \
        [-60, -26.6666666666667, 60, 60, 0, 0, -5, -60, 0, 0, 0, 0, 300], \
        [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5], \
        [0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0], \
        [0, 0, 0, 0, -714.285714285714, -0.04, 0, 0, 0, 714.285714285714, 0, 0, 0], \
        [0, 3.33333333333333, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, -1000, -0.01, 1000, 0, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0], \
        [0, 0, 0, 0, 1000, 0, 0, 1000, 0, -2000, -0.01, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        ]
    deadzone.set_dynamics(a_matrix)
    # -0.03 <= x1 & x1 <= 0.03
    deadzone.set_invariant([[-1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], ], [0.03, 0.03, ])

    posAngle = ha.new_mode('posAngle')
    a_matrix = [ \
        [0, 0, 0, 0, 0, 0, 0.0833333333333333, 0, -1, 0, 0, 0, 0], \
        [13828.8888888889, -26.6666666666667, 60, 60, 0, 0, -5, -60, 0, 0, 0, 0, -116.666666666667], \
        [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 5], \
        [0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0], \
        [0, 0, 0, 0, -714.285714285714, -0.04, 0, 0, 0, 714.285714285714, 0, 0, 0], \
        [-2777.77777777778, 3.33333333333333, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 83.3333333333333], \
        [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0], \
        [100, 0, 0, 0, 0, 0, 0, -1000, -0.01, 1000, 0, 0, -3], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0], \
        [0, 0, 0, 0, 1000, 0, 0, 1000, 0, -2000, -0.01, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        ]
    posAngle.set_dynamics(a_matrix)
    # 0.03 <= x1
    posAngle.set_invariant([[-1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], ], [-0.03, ])

    negAngleInit = ha.new_mode('negAngleInit')
    a_matrix = [ \
        [0, 0, 0, 0, 0, 0, 0.0833333333333333, 0, -1, 0, 0, 0, 0], \
        [13828.8888888889, -26.6666666666667, 60, 60, 0, 0, -5, -60, 0, 0, 0, 0, 116.666666666667], \
        [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -5], \
        [0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0], \
        [0, 0, 0, 0, -714.285714285714, -0.04, 0, 0, 0, 714.285714285714, 0, 0, 0], \
        [-2777.77777777778, 3.33333333333333, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, -83.3333333333333], \
        [0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0], \
        [100, 0, 0, 0, 0, 0, 0, -1000, -0.01, 1000, 0, 0, 3], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0], \
        [0, 0, 0, 0, 1000, 0, 0, 1000, 0, -2000, -0.01, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        ]
    negAngleInit.set_dynamics(a_matrix)
    # t <= 0.20001
    negAngleInit.set_invariant([[0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0], ], [0.20001, ])

    error = ha.new_mode('error')
    a_matrix = [ \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        ]
    error.set_dynamics(a_matrix)

    _error = ha.new_mode('_error')

    trans = ha.new_transition(negAngleInit, negAngle)
    # t >= 0.20001
    trans.set_guard([[-0, -0, -0, -0, -0, -0, -0, -0, -0, -0, -0, -1, -0], ], [-0.20001, ])

    trans = ha.new_transition(negAngle, deadzone)
    # x1 >= -0.03
    trans.set_guard([[-1, -0, -0, -0, -0, -0, -0, -0, -0, -0, -0, -0, -0], ], [0.03, ])

    trans = ha.new_transition(deadzone, posAngle)
    # x1 >= 0.03
    trans.set_guard([[-1, -0, -0, -0, -0, -0, -0, -0, -0, -0, -0, -0, -0], ], [-0.03, ])

    trans = ha.new_transition(deadzone, error)
    # x1 <= -0.03
    trans.set_guard([[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], ], [-0.03, ])

    trans = ha.new_transition(posAngle, error)
    # x1 <= 0.03
    trans.set_guard([[1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], ], [0.03, ])

    trans = ha.new_transition(error, _error)
    trans.set_guard_true()

    return ha

def define_init_states(ha):
    '''returns a list of StateSet objects'''
    # Variable ordering: [x1, x2, x3, x4, x5, x6, x7, x8, x9, x10, x11, t, affine]
    rv = []
    
    # 1.0 * x1 + 0.0488 = 0.00056 * x4 - 0.0112 & 1.0 * x2 + 15.67 = 0.46699999999999997 * x4 - 9.34 & x3 = 0.0 & x5 = 0.0 & 1.0 * x6 - 20.0 = 1.0 * x4 - 20.0 & 1.0 * x7 - 240.0 = 12.0 * x4 - 240.0 & 1.0 * x8 + 0.0019199999999999998 = 0.00006 * x4 - 0.0012 & 1.0 * x9 - 20.0 = 1.0 * x4 - 20.0 & 1.0 * x10 + 0.0019199999999999998 = 0.00006 * x4 - 0.0012 & 1.0 * x11 - 20.0 = 1.0 * x4 - 20.0 & 20.0 <= x4 & x4 <= 40.0 & t = 0.0 & affine = 1.0
    mode = ha.modes['negAngleInit']
    mat = [[1, 0, 0, -0.00056, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        [-1, -0, -0, 0.00056, -0, -0, -0, -0, -0, -0, -0, -0, -0], \
        [0, 1, 0, -0.46699999999999997, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        [-0, -1, -0, 0.46699999999999997, -0, -0, -0, -0, -0, -0, -0, -0, -0], \
        [0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        [-0, -0, -1, -0, -0, -0, -0, -0, -0, -0, -0, -0, -0], \
        [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0], \
        [-0, -0, -0, -0, -1, -0, -0, -0, -0, -0, -0, -0, -0], \
        [0, 0, 0, -1, 0, 1, 0, 0, 0, 0, 0, 0, 0], \
        [-0, -0, -0, 1, -0, -1, -0, -0, -0, -0, -0, -0, -0], \
        [0, 0, 0, -12, 0, 0, 1, 0, 0, 0, 0, 0, 0], \
        [-0, -0, -0, 12, -0, -0, -1, -0, -0, -0, -0, -0, -0], \
        [0, 0, 0, -0.00006, 0, 0, 0, 1, 0, 0, 0, 0, 0], \
        [-0, -0, -0, 0.00006, -0, -0, -0, -1, -0, -0, -0, -0, -0], \
        [0, 0, 0, -1, 0, 0, 0, 0, 1, 0, 0, 0, 0], \
        [-0, -0, -0, 1, -0, -0, -0, -0, -1, -0, -0, -0, -0], \
        [0, 0, 0, -0.00006, 0, 0, 0, 0, 0, 1, 0, 0, 0], \
        [-0, -0, -0, 0.00006, -0, -0, -0, -0, -0, -1, -0, -0, -0], \
        [0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 1, 0, 0], \
        [-0, -0, -0, 1, -0, -0, -0, -0, -0, -0, -1, -0, -0], \
        [0, 0, 0, -1, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        [0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0], \
        [-0, -0, -0, -0, -0, -0, -0, -0, -0, -0, -0, -1, -0], \
        [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1], \
        [-0, -0, -0, -0, -0, -0, -0, -0, -0, -0, -0, -0, -1], ]
    rhs = [-0.060000000000000005, 0.060000000000000005, -25.009999999999998, 25.009999999999998, 0, -0, 0, -0, 0, -0, 0, -0, -0.0031199999999999995, 0.0031199999999999995, 0, -0, -0.0031199999999999995, 0.0031199999999999995, 0, -0, -20, 40, 0, -0, 1, -1, ]
    rv.append(StateSet(lputil.from_constraints(mat, rhs, mode), mode))
    
    return rv


def define_settings(image_path):
    '''get the hylaa settings object
    see hylaa/settings.py for a complete list of reachability settings'''

    # step_size = 5.0E-4, max_time = 2.0
    settings = HylaaSettings(5.0E-4, 2.0) 
    settings.plot.plot_mode = PlotSettings.PLOT_NONE
    
    if image_path is not None:
        settings.plot.filename = image_path
        settings.plot.plot_mode = PlotSettings.PLOT_IMAGE
        settings.plot.xdim_dir = 0
        settings.plot.ydim_dir = 2
        
        plot_settings = settings.plot
        plot_settings.label.y_label = '$x_{3}$' # variables are numbered differently than Matthias' model
        plot_settings.label.x_label = '$x_{1}$'
        plot_settings.label.title = ''
        plot_settings.plot_size = (6, 6)
        
        # add lines
        line_pts = []
        
        for x in [-0.03, 0.03]:
            tmax = settings.num_steps * settings.step_size
            
            line_pts.append([(x, -20), (x, 100)])
            
        c1 = collections.LineCollection(line_pts, animated=True, colors=('gray'), linewidths=(2), linestyle='dotted')
        
        settings.plot.extra_collections = [[c1]]

    settings.aggstrat=aggstrat.Unaggregated()

    return settings

def run_hylaa(image_path):
    'runs hylaa, returning a HylaaResult object'
    
    image_path = 'DTN03.png'
    
    ha = define_ha()
    init = define_init_states(ha)
    settings = define_settings(image_path)

    result = Core(ha, settings).run(init)

    return result

if __name__ == '__main__':
    image_path = None
    
    if len(sys.argv) > 1 and sys.argv[1].endswith('.png'):
        image_path = sys.argv[1]
    
    run_hylaa(image_path)

