'''
settings for single runs
'''

import numpy as np

from nnenum.settings import Settings

def set_settings1(settings_name):
    'set the settings'

    assert settings_name[0] == '1'

    Settings.reset()
    Settings.TIMING_STATS = False
    Settings.PARALLEL_ROOT_LP = False
    Settings.SPLIT_IF_IDLE = False
    Settings.PRINT_OVERAPPROX_OUTPUT = False
    Settings.TRY_QUICK_OVERAPPROX = False

    Settings.BRANCH_MODE = Settings.BRANCH_EXACT

    if settings_name == '1_exact':
        return

    Settings.CONTRACT_ZONOTOPE = True

    if settings_name == "1_quick_contract":
        return

    Settings.CONTRACT_ZONOTOPE = False
    Settings.CONTRACT_ZONOTOPE_LP = True
    Settings.CONTRACT_LP_OPTIMIZED = False
    Settings.CONTRACT_LP_TRACK_WITNESSES = False

    if settings_name == "1_lp_old":
        return

    Settings.CONTRACT_LP_TRACK_WITNESSES = True

    if settings_name == "1_lp_old_witness":
        return

    Settings.CONTRACT_LP_OPTIMIZED = True
    Settings.CONTRACT_LP_TRACK_WITNESSES = False

    if settings_name == "1_lp_new":
        return

    Settings.CONTRACT_LP_TRACK_WITNESSES = True

    assert settings_name == "1_lp_new_witness"

def set_settings2(settings_name):
    'set the settings'

    assert settings_name[0] == '2'

    Settings.reset()
    Settings.TIMING_STATS = False
    Settings.PARALLEL_ROOT_LP = False
    Settings.SPLIT_IF_IDLE = False
    Settings.PRINT_OVERAPPROX_OUTPUT = False
    Settings.TRY_QUICK_OVERAPPROX = False

    Settings.CONTRACT_ZONOTOPE_LP = True
    Settings.CONTRACT_LP_OPTIMIZED = True
    Settings.CONTRACT_LP_TRACK_WITNESSES = True

    Settings.BRANCH_MODE = Settings.BRANCH_OVERAPPROX
    Settings.OVERAPPROX_CONTRACT_ZONO_LP = False

    Settings.OVERAPPROX_MIN_GEN_LIMIT = np.inf
    Settings.OVERAPPROX_LP_TIMEOUT = np.inf
    Settings.OVERAPPROX_BOTH_BOUNDS = True

    Settings.OVERAPPROX_TYPES = [['zono.area']]

    if settings_name == '2_zono':
        return

    Settings.OVERAPPROX_TYPES = [['star.lp']]

    if settings_name == '2_lp':
        return

    Settings.OVERAPPROX_TYPES = [['zono.area', 'star.lp']]

    if settings_name == '2_lpzono':
        return

    Settings.OVERAPPROX_TYPES = [['zono.area'], ['zono.area', 'star.lp']]

    if settings_name == '2_zonolpzono':
        return

    Settings.OVERAPPROX_TYPES = [['zono.area'],
                                 ['zono.area', 'zono.ybloat', 'zono.interval'],
                                 ['zono.area', 'zono.ybloat', 'zono.interval', 'star.lp']]

    if settings_name == '2_3rounds':
        return

    Settings.OVERAPPROX_TYPES = [['zono.area'],
                                 ['zono.area', 'zono.ybloat', 'zono.interval'],
                                 ['zono.area', 'zono.ybloat', 'zono.interval', 'star.quick']]

    if settings_name == '2_3rounds_quickstar':
        return

    Settings.OVERAPPROX_TYPES = [['zono.area'],
                                 ['zono.area', 'zono.ybloat', 'zono.interval'],
                                 ['zono.area', 'zono.ybloat', 'zono.interval', 'star.lp']]

    Settings.BRANCH_MODE = Settings.BRANCH_EGO

    if settings_name == '2_ego':
        return

    Settings.BRANCH_MODE = Settings.BRANCH_OVERAPPROX
    Settings.OVERAPPROX_LP_TIMEOUT = 0.05

    if settings_name == "2_lp0.05":
        return
        
    Settings.OVERAPPROX_LP_TIMEOUT = 0.1

    if settings_name == "2_lp0.1":
        return

    Settings.OVERAPPROX_LP_TIMEOUT = 0.2

    if settings_name == "2_lp0.2":
        return

    Settings.OVERAPPROX_LP_TIMEOUT = 0.25

    if settings_name == "2_lp0.25":
        return

    Settings.OVERAPPROX_LP_TIMEOUT = 0.3

    if settings_name == "2_lp0.3":
        return

    Settings.OVERAPPROX_LP_TIMEOUT = 0.4

    if settings_name == "2_lp0.4":
        return

    Settings.OVERAPPROX_LP_TIMEOUT = 0.5

    if settings_name == "2_lp0.5":
        return

    Settings.OVERAPPROX_LP_TIMEOUT = 0.75

    if settings_name == "2_lp0.75":
        return

    Settings.OVERAPPROX_LP_TIMEOUT = 1.0

    if settings_name == "2_lp1.0":
        return

    Settings.OVERAPPROX_LP_TIMEOUT = 1.25

    if settings_name == "2_lp1.25":
        return

    Settings.OVERAPPROX_LP_TIMEOUT = 1.5

    if settings_name == "2_lp1.5":
        return

    Settings.OVERAPPROX_LP_TIMEOUT = 1.75

    if settings_name == "2_lp1.75":
        return

    Settings.OVERAPPROX_LP_TIMEOUT = 2.0

    if settings_name == "2_lp2.0":
        return

    Settings.OVERAPPROX_BOTH_BOUNDS = False
    Settings.OVERAPPROX_LP_TIMEOUT = 0.1

    if settings_name == "2_one_bound":
        return

    Settings.OVERAPPROX_GEN_LIMIT_MULTIPLIER = 1.1

    if settings_name == "2_gens1.1":
        return
    
    Settings.OVERAPPROX_GEN_LIMIT_MULTIPLIER = 1.2

    if settings_name == "2_gens1.2":
        return

    Settings.OVERAPPROX_GEN_LIMIT_MULTIPLIER = 1.3

    if settings_name == "2_gens1.3":
        return

    Settings.OVERAPPROX_GEN_LIMIT_MULTIPLIER = 1.4

    if settings_name == "2_gens1.4":
        return

    Settings.OVERAPPROX_GEN_LIMIT_MULTIPLIER = 1.5

    if settings_name == "2_gens1.5":
        return

    Settings.OVERAPPROX_GEN_LIMIT_MULTIPLIER = 1.6

    if settings_name == "2_gens1.6":
        return

    Settings.OVERAPPROX_GEN_LIMIT_MULTIPLIER = 1.7

    if settings_name == "2_gens1.7":
        return

    Settings.OVERAPPROX_GEN_LIMIT_MULTIPLIER = 1.8

    if settings_name == "2_gens1.8":
        return

    Settings.OVERAPPROX_GEN_LIMIT_MULTIPLIER = 1.5 # don't try approx star if multizono.gens > THIS * last_safe_gens

    for limit in range(10, 110, 10):
        Settings.OVERAPPROX_MIN_GEN_LIMIT = limit

        if settings_name == f'2_gens_limit{limit}':
            return

    Settings.reset()
    Settings.TIMING_STATS = False
    Settings.PARALLEL_ROOT_LP = False
    Settings.SPLIT_IF_IDLE = False
    Settings.PRINT_OVERAPPROX_OUTPUT = False
    Settings.TRY_QUICK_OVERAPPROX = False

    Settings.CONTRACT_ZONOTOPE_LP = True
    Settings.CONTRACT_LP_OPTIMIZED = True
    Settings.CONTRACT_LP_TRACK_WITNESSES = True

    Settings.BRANCH_MODE = Settings.BRANCH_OVERAPPROX
    Settings.OVERAPPROX_CONTRACT_ZONO_LP = False

    if settings_name == '2_complete_orig':
        return

    assert False    

def set_settings3(settings_name):
    'set the settings'

    assert settings_name[0] == '3'

    Settings.reset()
    Settings.TIMING_STATS = False
    Settings.PARALLEL_ROOT_LP = False
    Settings.SPLIT_IF_IDLE = False
    Settings.PRINT_OVERAPPROX_OUTPUT = False
    Settings.TRY_QUICK_OVERAPPROX = False

    Settings.CONTRACT_ZONOTOPE_LP = True
    Settings.CONTRACT_LP_OPTIMIZED = True
    Settings.CONTRACT_LP_TRACK_WITNESSES = True

    Settings.BRANCH_MODE = Settings.BRANCH_OVERAPPROX
    Settings.OVERAPPROX_CONTRACT_ZONO_LP = False

    Settings.OVERAPPROX_MIN_GEN_LIMIT = np.inf
    Settings.OVERAPPROX_LP_TIMEOUT = np.inf
    Settings.OVERAPPROX_BOTH_BOUNDS = True

    Settings.OVERAPPROX_TYPES = [['zono.area', 'star.lp']]
    Settings.OVERAPPROX_BOTH_BOUNDS = False

    if settings_name == '3_single_bound_lpzono':
        return

    Settings.BRANCH_MODE = Settings.BRANCH_EGO

    if settings_name == '3_ego':
        return

    Settings.OVERAPPROX_TYPES = [['zono.area'],
                                 ['zono.area', 'zono.ybloat', 'zono.interval'],
                                 ['zono.area', 'zono.ybloat', 'zono.interval', 'star.lp']]

    if settings_name == '3_ego_3rounds':
        return

    Settings.BRANCH_MODE = Settings.BRANCH_OVERAPPROX

    for gen_lim in range(1, 10):
        Settings.OVERAPPROX_GEN_LIMIT_MULTIPLIER = 1 + gen_lim / 10

        if settings_name == f"3_gens1.{gen_lim}":
            return

    Settings.OVERAPPROX_GEN_LIMIT_MULTIPLIER = 1.5 # don't try approx star if multizono.gens > THIS * last_safe_gens

    Settings.OVERAPPROX_LP_TIMEOUT = 0.02
    if settings_name == "3_lp0.02":
        return

    Settings.OVERAPPROX_LP_TIMEOUT = 0.04
    if settings_name == "3_lp0.04":
        return

    Settings.OVERAPPROX_LP_TIMEOUT = 0.06
    if settings_name == "3_lp0.06":
        return

    Settings.OVERAPPROX_LP_TIMEOUT = 0.08
    if settings_name == "3_lp0.08":
        return

    Settings.OVERAPPROX_LP_TIMEOUT = 0.1
    if settings_name == "3_lp0.1":
        return

    Settings.OVERAPPROX_LP_TIMEOUT = 0.04

    for limit in range(10, 100, 10):
        Settings.OVERAPPROX_MIN_GEN_LIMIT = limit

        if settings_name == f'3_gens_limit{limit}':
            return

    Settings.OVERAPPROX_LP_TIMEOUT = 0.02

    for limit in range(10, 100, 10):
        Settings.OVERAPPROX_MIN_GEN_LIMIT = limit

        if settings_name == f'3_gens_0.02_limit{limit}':
            return

    Settings.OVERAPPROX_LP_TIMEOUT = 0.06

    for limit in range(10, 100, 10):
        Settings.OVERAPPROX_MIN_GEN_LIMIT = limit

        if settings_name == f'3_gens_0.06_limit{limit}':
            return

    assert False
