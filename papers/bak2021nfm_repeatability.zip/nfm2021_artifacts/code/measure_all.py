'''
Measurement script for Acas Xu enumeration comparison

This is the EGO / overapproximation version (NFM), not pure enumerative version (CAV)

measurement plan:

first plot: 
- exact without contraction
- LP contraction old
- LP contraction new
- LP contraction old w/witnesses
- LP contraction new w/witnesses
- quick contraction (no LP) ** expected winner

second plot:
- evaluate different overapproximation methods

third plot:
- overapprox
- ego
- overapprox with timeout (try different levels)
- overapprox with generator limit (try different levels)
- overapprox with combined timeout + generator limit

sixth plot:
- split order inorder
- split one-norm
- split largest
- split smallest

Stanley Bak
Feb 2020
'''

import sys
import os
import time
import subprocess
import multiprocessing

from termcolor import cprint
from nnenum.result import Result

# path to reluval (neurify) folder after compilation (should contain network_test executable)
RELUVAL_FOLDER = os.environ.get('RELUVAL_FOLDER', default='/home/stan/repositories/ReluVal/')

# path to marabou folder after compilation (should contain executable in build/Marabou)
MARABOU_FOLDER = os.environ.get('MARABOU_FOLDER', default='/home/stan/repositories/Marabou/')

# single-run timeout in seconds
TIMEOUT = 60 

# If True, does not run any measurements, only accumulates cached results
ACCUMULATE_ONLY = False

def main():
    'main entry point'

    #run_all = len(sys.argv) > 1 and sys.argv[1] == 'all'
    run_all = True

    if run_all:
        # full
        a_prev_range = range(1, 6)
        tau_range = range(1, 10)
        spec_range = range(1, 5)
    else:
        # fast, 3-7 prop 3
        # med, 5-1 prop 3
        problem = 3, 7, 3
        a_prev_range = range(problem[0], problem[0] + 1)
        tau_range = range(problem[1], problem[1] + 1)
        spec_range = range(problem[2], problem[2] + 1)

    # the settings functions to call and measurements to run, in order
    #methods = ['marabou', 'reluval', 'nnv-exact', 'nnv-approx', 'enum', 'overapprox_multizono', 'overapprox_lp',
    #           'ego_lp', 'ego_lp_limit3']
    methods = ['1_exact', '1_quick_contract', '1_lp_old', '1_lp_old_witness', '1_lp_new', '1_lp_new_witness',
               '2_zono', '2_lp', '2_lpzono', '2_zonolpzono', '2_3rounds', '2_3rounds_quickstar', '2_ego',
               '2_lp0.1', '2_lp0.2', '2_lp0.3', '2_lp0.4',
               '2_lp0.25', '2_lp0.5', '2_lp0.75', '2_lp1.0', '2_lp1.25', '2_lp1.5', '2_lp1.75', '2_lp2.0',
               '2_lp0.05',
               '2_one_bound', '2_gens1.1', '2_gens1.2', '2_gens1.3', '2_gens1.4', '2_gens1.5', '2_gens1.6',
               '2_gens1.7', '2_gens1.8', '2_complete_orig']

    for limit in range(10, 110, 10):
        m = f'2_gens_limit{limit}'
        methods.append(m)

    methods += ['3_single_bound_lpzono', '3_ego', '3_ego_3rounds']

    for gen_lim in range(1, 8):
        m = f"3_gens1.{gen_lim}"
        methods.append(m)

    methods += ['3_lp0.02', '3_lp0.04', '3_lp0.06', '3_lp0.08', '3_lp0.1']

    for limit in range(10, 100, 10):
        m = f'3_gens_limit{limit}'
        methods.append(m)

    for limit in range(10, 100, 10):
        m = f'3_gens_0.02_limit{limit}'
        methods.append(m)

    for limit in range(10, 100, 10):
        m = f'3_gens_0.06_limit{limit}'
        methods.append(m)

    all_results, triples = compare(methods, spec_range, a_prev_range, tau_range)

    errors = []
    
    for key, (result_str, _time) in all_results.items():
        if not result_str in ["safe", "unsafe", "timeout"]:
            print(f"{key} was {result_str}")
            errors.append(f"\n{key} was {result_str}")

    for method, timeouts, runtime in triples:
        print(f"{method} & {timeouts} & {round(runtime, 1)} \\\\")

    print(f"errors: {errors}")

    #make_tables(all_results, methods, spec_range, a_prev_range, tau_range)

def write_data_table(f, all_results, spec_range, a_prev_range, tau_range, method_list, show_min):
    'write the data table, return total_secs'

    method = 'multibfs'
    total_secs = 0

    for spec in spec_range:
        for a_prev in a_prev_range:
            for tau in tau_range:

                instance_str = f"{method}_{spec}_{a_prev}_{tau}"
                expected_result = all_results[instance_str][0]

                f.write(f"{spec} & {a_prev}-{tau} & \\texttt{{ {expected_result.upper()} }}")

                for method_name in method_list:
                    instance_str = f"{method_name}_{spec}_{a_prev}_{tau}"
                    res_str, secs = all_results[instance_str]

                    total_secs += secs

                    f.write(" & ")

                    if res_str == 'error':
                        f.write('\\bf{ERROR}')
                    elif res_str == 'none':
                        f.write('~~\\textcolor{darkgray}{(')

                    is_min = False

                    if show_min: # tools
                        if res_str in ['safe', 'unsafe']:
                            is_min = True

                        for other_method_name in method_list:
                            if method_name == other_method_name:
                                continue

                            other_instance_str = f"{other_method_name}_{spec}_{a_prev}_{tau}"
                            other_res_str, other_secs = all_results[other_instance_str]

                            if other_res_str in ['safe', 'unsafe'] and other_secs < secs:
                                is_min = False
                                break

                    assert not res_str in ['error', 'none']

                    if res_str == 'timeout':
                        f.write('\\textcolor{darkgray}{---}')
                    else:
                        if is_min:
                            f.write('\\textbf{')

                        if round(secs, 1) >= 1:
                            f.write(f'{int(round(secs, 0))}')
                        elif round(secs, 1) >= 0.1:
                            f.write(f'{str(round(secs, 1))[1:]}')
                        else:
                            f.write(f'{str(round(secs, 2))[1:]}')

                        if is_min:
                            f.write('}')

                f.write(' \\\\\n')

    return total_secs

def write_matrix(f, all_results, spec_range, a_prev_range, tau_range, method_list, pretty_method_list):
    'write the method-method comparison table'

    suffixes = []

    for spec in spec_range:
        for a_prev in a_prev_range:
            for tau in tau_range:
                suffixes.append(f"{spec}_{a_prev}_{tau}")

    # write header
    f.write("%\\toprule\n")
    f.write("%~ ")
                    
    for pm in pretty_method_list:
        f.write(f"& \\textbf{{{pm}}} ")

    f.write("\\\\\n")
    f.write("%\\midrule\n")

    for row, method in enumerate(method_list):
        f.write(f"\\textbf{{{pretty_method_list[row]}}} ")

        for other_method in method_list:

            if method == other_method:
                f.write("& - ")
                continue
            
            count = 0
            total_secs = 0
            other_total_secs = 0

            for suffix in suffixes:

                instance_str = f"{method}_{suffix}"
                result_str, secs = all_results[instance_str]

                other_instance_str = f"{other_method}_{suffix}"
                other_result_str, other_secs = all_results[other_instance_str]

                if result_str in ['safe', 'unsafe'] and other_result_str == result_str:
                    count += 1
                    total_secs += secs
                    other_total_secs += other_secs

            assert other_total_secs > 0
            ratio = total_secs / other_total_secs

            #print(f"{method} total runtime: {total_secs} vs {other_method} total runtime: {other_total_secs}")

            f.write(f"& {round(ratio, 1)}x ")

        f.write("\\\\\n")

    f.write("%\\bottomrule")

def make_tables(all_results, methods, spec_range, a_prev_range, tau_range):
    'make summary tables from all the results'

    # all_results is a map of instance_str -> (result_str, secs)
    # where instance_str is f"{method}_{spec}_{a_prev}_{tau}"

    optimizations = ['bfs', 'copy', 'bounds', 'sim', 'zono', 'zonosim', 'eager', 'contractlp', 'contract', 'multibfs']
    tools = ['marabou', 'nnv-exact', 'multibfs', 'reluval']

    optimizations_pretty = ['BFS', 'Copy', 'Bound', 'Sim', 'Zono-B', 'Zono-S', 'Eager', 'Con-LP', 'Con-Sim', 'Par']
    tools_pretty = ['Marabou', 'NNV Exact', 'Our Method', 'Neurify']

    method_lists = [optimizations, tools]
    pretty_method_lists = [optimizations_pretty, tools_pretty]

    total_secs = 0

    for table_index, table_type in enumerate(['optimizations', 'tools']):
        method_list = method_lists[table_index]
        pretty_method_list = pretty_method_lists[table_index]
                    
        filename = os.path.join('results', f'table_{table_type}.tex')
        print(f"writing {filename}...")

        with open(filename, "w") as f:
            show_min = table_index == 1
            total_secs += write_data_table(f, all_results, spec_range, a_prev_range, tau_range, method_list, show_min)

        filename = os.path.join('results', f'matrix_{table_type}.tex')
        print(f"writing {filename}...")

        with open(filename, "w") as f:
            write_matrix(f, all_results, spec_range, a_prev_range, tau_range, method_list, pretty_method_list)

    print(f"Total measurement time in tables: {round(total_secs, 1)} secs ({total_secs / 60 / 60 / 24} days)")
    
def compare(methods, spec_range, a_prev_range, tau_range):
    '''run a generic comparison with the given settings

    folder - folder where to save results
    methods - a list of settings_func, which returns the name of the method

    returns all_results, triples
    '''

    # all_results is a map of instance_str -> (result_str, secs)
    # where instance_str is f"{method}_{spec}_{a_prev}_{tau}"
    all_results = {}
    triples = [] # method_name, num_timeouts, runtime

    # make sure results directory exists
    folder = 'results'
    
    if not os.path.exists(folder):
        os.makedirs(folder)

    indiv_folder = os.path.join(folder, 'individual')

    if not os.path.exists(indiv_folder):
        os.makedirs(indiv_folder)

    ###############################
    start = time.time()

    for method_name in methods:

        cprint(f"\nRunning {method_name}", "grey", "on_blue")
        print("")

        finished_times = [] # for results that finished
        finished_times24 = [] # for properties 2-4 (skip property 1)
        
        full_filename = f'{folder}/{method_name}_full.dat'
        accumulated_filename = f'{folder}/{method_name}_accumulated.dat'
        accumulated24_filename = f'{folder}/{method_name}24_accumulated.dat'

        with open(full_filename, "w") as f:
            total_secs = 0
            total_errors = 0
            total_timeout = 0
            
            for spec in spec_range:
                for a_prev in a_prev_range:
                    for tau in tau_range:

                        res_str, secs = run_single(indiv_folder, method_name, a_prev, tau, spec)

                        s = f"{a_prev}_{tau}\t{spec}\t{res_str}\t{secs}"
                        f.write(s + "\n")
                        f.flush()

                        instance_str = f"{method_name}_{spec}_{a_prev}_{tau}"
                        all_results[instance_str] = (res_str, secs)

                        # limit min time to 0.1 since that's where our plots start
                        #secs = max(secs, 0.1)
                        secs = min(secs, TIMEOUT)
                        
                        print(s)
                        total_secs += secs
                        
                        if res_str not in ["timeout", "error", "none"]:
                            finished_times.append(secs)

                            if 2 <= spec <= 4:
                                finished_times24.append(secs)
                        elif res_str == "timeout":
                            total_timeout += 1
                        else:
                            total_errors += 1

            f.write(f"\nTotal Errors: {total_errors}\n")
            f.write(f"Total Timeouts: {total_timeout}\n")
            f.write(f"Runtime Sum for {method_name}: {total_secs}\n")

            triples.append((method_name, total_timeout, total_secs))

        # save accumulated results
        finished_times.sort()
        i = 0

        with open(accumulated_filename, "w") as f:

            for i, secs in enumerate(finished_times):
                f.write(f"{secs}\t{i+1}\n")

            if len(finished_times) % 45 != 0:
                # write last one
                f.write(f"{TIMEOUT}\t{i+1}\n")

        if method_name in ['multibfs', 'marabou', 'reluval', 'nnv-exact', 'nnv-approx']:
            finished_times24.sort()

            with open(accumulated24_filename, "w") as f:
                for i, secs in enumerate(finished_times24):
                    f.write(f"{secs}\t{i+1}\n")

                if len(finished_times24) % 45 != 0:
                    # write last one
                    f.write(f"{TIMEOUT}\t{i+1}\n")

    mins = (time.time() - start) / 60.0
    print(f"Completed all measurements in {round(mins, 2)} minutes")

    return all_results, triples

def run_single(indiv_folder, method_name, a_prev, tau, spec):
    '''
    run a single measurement (or load cached result)

    returns res_str, secs
    '''

    if method_name in ['nnv-exact', 'nnv-approx']:
        # special handling for nnv
        filename = f"{method_name[4:]}_{spec}_{a_prev}_{tau}.dat"
        path = os.path.join('nnv', 'individual', filename)
    else:
        filename = f"{method_name}_{a_prev}_{tau}_{spec}.dat"
        path = os.path.join(indiv_folder, filename)

    res_str = None
    secs = None

    timeout_rerun = TIMEOUT # if timeone was less than this, result gets re-ran

    if os.path.exists(path):
        # try opening and read results from file
        with open(path, "r") as f:
            res_str = f.readline().strip()
            secs = f.readline().strip()

        try:
            secs = float(secs)
        except ValueError:
            print(f"float convert error with {path}")
            res_str = 'error'
            secs = 0

        if res_str == 'error' or (res_str == 'timeout' and secs < timeout_rerun):
            print(f"\n{path}: res_str was '{res_str}', with time {secs}, rerunning measurement")
            
            # re-run
            res_str = None
            secs = None
    

    if res_str is None:            
        if ACCUMULATE_ONLY:
            res_str = 'none'
            secs = 0
        else:
            net_pair = (a_prev, tau)

            res_str = "none"
            secs = "-"

            cprint(f"\nRunning {method_name} on network {net_pair} with spec {spec}", "grey", "on_green")

            if method_name in ['nnv-exact', 'nnv-approx']:
                print(f"Warning: NNV result missing for {net_pair} with spec {spec}. Did you run nnv_measure.m first?")
                res_str, secs = 'none', 0
            if method_name == 'reluval':
                res_str, secs = run_reluval(net_pair, spec)
            elif method_name == 'marabou':
                res_str, secs = run_marabou(net_pair, spec)
            else:
                res_str, secs = run_process(net_pair, spec, method_name)

            # write the cache file
            with open(path, "w") as f:
                f.write(f'{res_str}\n{secs}')

    return res_str, secs

def run_process(net_pair, spec, method_name):
    '''create a new process and run a measurement

    returns result_str, secs
    '''

    args = [sys.executable, "acasxu_single_nnenum.py", str(net_pair[0]), str(net_pair[1]), str(spec), method_name]
    reported_time = -1    

    try:
        result = subprocess.run(args, check=False, timeout=TIMEOUT,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

        if 0 <= result.returncode < len(Result.results):        
            res_str = Result.results[result.returncode]

            stdout = result.stdout.decode("utf-8")

            for line in stdout.split('\n'):
                if line.startswith('time: '):
                    t = line[len('time: '):]
                    reported_time = float(t)
                    break

            if res_str == "error":
                print("##############################")
                print(stdout)
                exit(1)
        else:
            res_str = 'error'
            reported_time = TIMEOUT + 1e-3
    except subprocess.TimeoutExpired:
        res_str = 'timeout'
        reported_time = TIMEOUT + 1e-3

    return res_str, reported_time

def run_reluval(net_pair, spec):
    'run reluval'

    path = os.path.join(RELUVAL_FOLDER, 'network_test')

    if not os.path.exists(path):
        print(f"Reluval executable (network_test) not found at path: {path}. " + \
              "Did you set the environment RELUVAL_FOLDER?")
        
        return 'error', 0

    # ./network_test 1 ./nnet/ACASXU_run2a_1_1_batch_2000.nnet 0

    network = os.path.join(RELUVAL_FOLDER, 'nnet', f'ACASXU_run2a_{net_pair[0]}_{net_pair[1]}_batch_2000.nnet')

    if not os.path.exists(network):
        print(f"Reluval network not found at path: {network}")
        
        return 'error', 0
    
    args = [path, str(spec), network, "0"]

    timeout_secs = TIMEOUT
    result_str = 'error'
    reported_time = -1

    try:
        print(f"Running reluval with args: {args}")
        result = subprocess.run(args, check=False, timeout=timeout_secs,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

        if result.returncode == 0:
            # byte string
            safe_str = b'No adv!'
            unsafe_str = b'adv found:'

            if result.stdout.find(safe_str) != -1:
                result_str = 'safe'
            elif result.stdout.find(unsafe_str) != -1:
                result_str = 'unsafe'

            stdout = result.stdout.decode("utf-8")

            for line in stdout.split('\n'):
                if line.startswith('time: '):
                    t = line[len('time: '):]
                    reported_time = float(t)
                    break

        else:
            print(f"Error, non-zero returncode from reluval process: {result.returncode}")
        
    except subprocess.TimeoutExpired:
        result_str = 'timeout'
        reported_time = timeout_secs + 1e-3

    rv = result_str, reported_time

    return rv

def run_marabou(net_pair, spec):
    'run marabou with DnC mode'

    num_cores = multiprocessing.cpu_count()

    # example command line
    # build/Marabou resources/nnet/acasxu/ACASXU_experimental_v2a_2_7.nnet
    # resources/properties/acas_property_3.txt --dnc --initial-divides=4
    # --initial-timeout=5 --num-online-divides=4 --timeout-factor=1.5 --num-workers=4

    path = os.path.join(MARABOU_FOLDER, 'build', 'Marabou')

    if not os.path.exists(path):
        print(f"Marabou executable not found at path: {path}. " + \
              "Did you set the environment variable MARARBOU_FOLDER?")
        
        return 'error', 0

    a, b = net_pair
    network = os.path.join(MARABOU_FOLDER, 'resources', 'nnet', 'acasxu', f'ACASXU_experimental_v2a_{a}_{b}.nnet')

    if not os.path.exists(network):
        print(f"Marabou network not found at path: {network}")
        
        return 'error', 0

    spec_str = os.path.join(MARABOU_FOLDER, 'resources', 'properties', f'acas_property_{spec}.txt')

    if not os.path.exists(spec_str):
        print(f"Marabou spec not found at path: {spec_str}")
        
        return 'error', 0
    
    args = [path, network, spec_str, '--dnc', f'--initial-divides=4', '--initial-timeout=5',
            f'--num-online-divides=4', '--timeout-factor=1.5', f'--num-workers={num_cores}']

    timeout_secs = TIMEOUT
    start = time.perf_counter()
    result_str = 'error'

    try:
        print(f"Running Marabou with args: {args}")
        result = subprocess.run(args, check=False, timeout=timeout_secs,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT)

        if result.returncode == 0:
            # byte string
            safe_str = b'\nUNSAT\n'
            unsafe_str = b'\nSAT\n'

            if result.stdout.find(safe_str) != -1:
                result_str = 'safe'
            elif result.stdout.find(unsafe_str) != -1:
                result_str = 'unsafe'

        else:
            print(f"Error, non-zero returncode from process: {result.returncode}")
        
    except subprocess.TimeoutExpired:
        result_str = 'timeout'

    total = time.perf_counter() - start

    rv = result_str, total

    return rv
        
if __name__ == '__main__':
    main()
