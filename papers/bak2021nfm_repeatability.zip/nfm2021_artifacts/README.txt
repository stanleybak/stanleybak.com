 
Repeatability instructions for NFM 2021 nnenum paper, prepared by Stanley Bak, Dec 2020. This was prepared using Ubuntu 20.04.

== PAPER MEASUREMENTS ==

All the measurements in the paper are produced by the measure_all.py python 3 script in the code directory.
This stores results into a results folder. A copy of the expected_results is in expected_results. For example, for the exact analysis with no contraction in Table 1 in the paper, the measurement is in code/expected_results/1_exact_full.dat. It lists the times and results for each of the 180 benchmarks, followed by a summary at the end:

Total Timeouts: 50
Runtime Sum for 1_exact: 3471.1546784100647

This is the value for that row in the table.

The single-loop data is in expected_results/1_quick_contract_full.dat. In general, all the measurement results are in the *_full.dat files.



A nice trick to see all the results at once is to use grep:

$ grep "Runtime\|Timeouts" expected_results/*.dat  

expected_results/1_exact_full.dat:Total Timeouts: 50
expected_results/1_exact_full.dat:Runtime Sum for 1_exact: 3471.1546784100647
expected_results/1_lp_new_full.dat:Total Timeouts: 31
expected_results/1_lp_new_full.dat:Runtime Sum for 1_lp_new: 2743.7836438378436
expected_results/1_lp_new_witness_full.dat:Total Timeouts: 28
expected_results/1_lp_new_witness_full.dat:Runtime Sum for 1_lp_new_witness: 2548.9682495760208
expected_results/1_lp_old_full.dat:Total Timeouts: 44
expected_results/1_lp_old_full.dat:Runtime Sum for 1_lp_old: 3220.8672992939537
expected_results/1_lp_old_witness_full.dat:Total Timeouts: 31
expected_results/1_lp_old_witness_full.dat:Runtime Sum for 1_lp_old_witness: 2680.1432604767615
expected_results/1_quick_contract_full.dat:Total Timeouts: 32
expected_results/1_quick_contract_full.dat:Runtime Sum for 1_quick_contract: 2778.8290468181076
expected_results/2_3rounds_full.dat:Total Timeouts: 65
expected_results/2_3rounds_full.dat:Runtime Sum for 2_3rounds: 4189.992416118941
expected_results/2_3rounds_quickstar_full.dat:Total Timeouts: 43
expected_results/2_3rounds_quickstar_full.dat:Runtime Sum for 2_3rounds_quickstar: 3802.8435570930596
expected_results/2_complete_orig_full.dat:Total Timeouts: 0
expected_results/2_complete_orig_full.dat:Runtime Sum for 2_complete_orig: 277.94431939860806
expected_results/2_ego_full.dat:Total Timeouts: 22
expected_results/2_ego_full.dat:Runtime Sum for 2_ego: 2513.4913095560623
expected_results/2_gens1.1_full.dat:Total Timeouts: 1
expected_results/2_gens1.1_full.dat:Runtime Sum for 2_gens1.1: 776.208190306148
expected_results/2_gens1.25_full.dat:Total Timeouts: 52
expected_results/2_gens1.25_full.dat:Runtime Sum for 2_gens1.25: 3724.2652187900467
expected_results/2_gens1.2_full.dat:Total Timeouts: 1
expected_results/2_gens1.2_full.dat:Runtime Sum for 2_gens1.2: 783.5263245688984
expected_results/2_gens1.3_full.dat:Total Timeouts: 1
expected_results/2_gens1.3_full.dat:Runtime Sum for 2_gens1.3: 770.7690302330884
expected_results/2_gens1.4_full.dat:Total Timeouts: 1
expected_results/2_gens1.4_full.dat:Runtime Sum for 2_gens1.4: 768.045278689824
expected_results/2_gens1.5_full.dat:Total Timeouts: 1
expected_results/2_gens1.5_full.dat:Runtime Sum for 2_gens1.5: 716.2761989050196
expected_results/2_gens1.6_full.dat:Total Timeouts: 1
expected_results/2_gens1.6_full.dat:Runtime Sum for 2_gens1.6: 772.449109504174
expected_results/2_gens1.75_full.dat:Total Timeouts: 28
expected_results/2_gens1.75_full.dat:Runtime Sum for 2_gens1.75: 3060.517584038064
expected_results/2_gens1.7_full.dat:Total Timeouts: 1
expected_results/2_gens1.7_full.dat:Runtime Sum for 2_gens1.7: 768.8310687242192
expected_results/2_gens1.8_full.dat:Total Timeouts: 1
expected_results/2_gens1.8_full.dat:Runtime Sum for 2_gens1.8: 773.80706988764
expected_results/2_gens2.0_full.dat:Total Timeouts: 29
expected_results/2_gens2.0_full.dat:Runtime Sum for 2_gens2.0: 3072.910187037478
expected_results/2_gens2.25_full.dat:Total Timeouts: 39
expected_results/2_gens2.25_full.dat:Runtime Sum for 2_gens2.25: 3368.207468585997
expected_results/2_gens_limit100_full.dat:Total Timeouts: 0
expected_results/2_gens_limit100_full.dat:Runtime Sum for 2_gens_limit100: 259.9472467385931
expected_results/2_gens_limit10_full.dat:Total Timeouts: 15
expected_results/2_gens_limit10_full.dat:Runtime Sum for 2_gens_limit10: 1858.763898635516
expected_results/2_gens_limit20_full.dat:Total Timeouts: 0
expected_results/2_gens_limit20_full.dat:Runtime Sum for 2_gens_limit20: 511.2975571754505
expected_results/2_gens_limit30_full.dat:Total Timeouts: 0
expected_results/2_gens_limit30_full.dat:Runtime Sum for 2_gens_limit30: 314.6734957721783
expected_results/2_gens_limit40_full.dat:Total Timeouts: 0
expected_results/2_gens_limit40_full.dat:Runtime Sum for 2_gens_limit40: 239.53410380869173
expected_results/2_gens_limit50_full.dat:Total Timeouts: 0
expected_results/2_gens_limit50_full.dat:Runtime Sum for 2_gens_limit50: 206.9144390488509
expected_results/2_gens_limit60_full.dat:Total Timeouts: 0
expected_results/2_gens_limit60_full.dat:Runtime Sum for 2_gens_limit60: 195.61802002607146
expected_results/2_gens_limit70_full.dat:Total Timeouts: 0
expected_results/2_gens_limit70_full.dat:Runtime Sum for 2_gens_limit70: 199.68492474022787
expected_results/2_gens_limit80_full.dat:Total Timeouts: 0
expected_results/2_gens_limit80_full.dat:Runtime Sum for 2_gens_limit80: 207.72699175792513
expected_results/2_gens_limit90_full.dat:Total Timeouts: 0
expected_results/2_gens_limit90_full.dat:Runtime Sum for 2_gens_limit90: 228.60546003706986
expected_results/2_lp0.05_full.dat:Total Timeouts: 0
expected_results/2_lp0.05_full.dat:Runtime Sum for 2_lp0.05: 612.8484273565118
expected_results/2_lp0.1_full.dat:Total Timeouts: 1
expected_results/2_lp0.1_full.dat:Runtime Sum for 2_lp0.1: 830.0740178278938
expected_results/2_lp0.25_full.dat:Total Timeouts: 1
expected_results/2_lp0.25_full.dat:Runtime Sum for 2_lp0.25: 976.9553386967455
expected_results/2_lp0.2_full.dat:Total Timeouts: 3
expected_results/2_lp0.2_full.dat:Runtime Sum for 2_lp0.2: 1135.9953143801831
expected_results/2_lp0.3_full.dat:Total Timeouts: 5
expected_results/2_lp0.3_full.dat:Runtime Sum for 2_lp0.3: 1337.0941772588412
expected_results/2_lp0.4_full.dat:Total Timeouts: 6
expected_results/2_lp0.4_full.dat:Runtime Sum for 2_lp0.4: 1504.6560928559047
expected_results/2_lp0.5_full.dat:Total Timeouts: 2
expected_results/2_lp0.5_full.dat:Runtime Sum for 2_lp0.5: 1290.9096345953876
expected_results/2_lp0.75_full.dat:Total Timeouts: 4
expected_results/2_lp0.75_full.dat:Runtime Sum for 2_lp0.75: 1477.8899679768365
expected_results/2_lp1.0_full.dat:Total Timeouts: 4
expected_results/2_lp1.0_full.dat:Runtime Sum for 2_lp1.0: 1656.7365564991196
expected_results/2_lp1.25_full.dat:Total Timeouts: 6
expected_results/2_lp1.25_full.dat:Runtime Sum for 2_lp1.25: 1822.681305324193
expected_results/2_lp1.5_full.dat:Total Timeouts: 8
expected_results/2_lp1.5_full.dat:Runtime Sum for 2_lp1.5: 1983.0156823467987
expected_results/2_lp1.75_full.dat:Total Timeouts: 12
expected_results/2_lp1.75_full.dat:Runtime Sum for 2_lp1.75: 2109.006752538029
expected_results/2_lp2.0_full.dat:Total Timeouts: 14
expected_results/2_lp2.0_full.dat:Runtime Sum for 2_lp2.0: 2195.0653854933917
expected_results/2_lp_full.dat:Total Timeouts: 64
expected_results/2_lp_full.dat:Runtime Sum for 2_lp: 4174.328449227105
expected_results/2_lpzono_full.dat:Total Timeouts: 63
expected_results/2_lpzono_full.dat:Runtime Sum for 2_lpzono: 4186.800116432074
expected_results/2_one_bound_full.dat:Total Timeouts: 1
expected_results/2_one_bound_full.dat:Runtime Sum for 2_one_bound: 770.1831658611773
expected_results/2_orig_limit_gen_full.dat:Total Timeouts: 0
expected_results/2_orig_limit_gen_full.dat:Runtime Sum for 2_orig_limit_gen: 0.08271183300530538
expected_results/2_orig_limit_gen_min0_full.dat:Total Timeouts: 1
expected_results/2_orig_limit_gen_min0_full.dat:Runtime Sum for 2_orig_limit_gen_min0: 918.8237180538815
expected_results/2_orig_limit_gen_min100_full.dat:Total Timeouts: 0
expected_results/2_orig_limit_gen_min100_full.dat:Runtime Sum for 2_orig_limit_gen_min100: 341.75104491537786
expected_results/2_orig_limit_gen_min25_full.dat:Total Timeouts: 0
expected_results/2_orig_limit_gen_min25_full.dat:Runtime Sum for 2_orig_limit_gen_min25: 459.28047085681465
expected_results/2_orig_limit_gen_min50_full.dat:Total Timeouts: 0
expected_results/2_orig_limit_gen_min50_full.dat:Runtime Sum for 2_orig_limit_gen_min50: 239.38047145988094
expected_results/2_orig_limit_gen_min75_full.dat:Total Timeouts: 0
expected_results/2_orig_limit_gen_min75_full.dat:Runtime Sum for 2_orig_limit_gen_min75: 262.82198577944655
expected_results/2_zono_full.dat:Total Timeouts: 29
expected_results/2_zono_full.dat:Runtime Sum for 2_zono: 3517.051818195032
expected_results/2_zonolpzono_full.dat:Total Timeouts: 63
expected_results/2_zonolpzono_full.dat:Runtime Sum for 2_zonolpzono: 4160.728352263977
expected_results/3_ego_3rounds_full.dat:Total Timeouts: 2
expected_results/3_ego_3rounds_full.dat:Runtime Sum for 3_ego_3rounds: 1467.0900979784783
expected_results/3_ego_full.dat:Total Timeouts: 2
expected_results/3_ego_full.dat:Runtime Sum for 3_ego: 1469.2071555739967
expected_results/3_gens_0.02_limit10_full.dat:Total Timeouts: 3
expected_results/3_gens_0.02_limit10_full.dat:Runtime Sum for 3_gens_0.02_limit10: 1245.1535111548728
expected_results/3_gens_0.02_limit20_full.dat:Total Timeouts: 0
expected_results/3_gens_0.02_limit20_full.dat:Runtime Sum for 3_gens_0.02_limit20: 487.73763290111674
expected_results/3_gens_0.02_limit30_full.dat:Total Timeouts: 0
expected_results/3_gens_0.02_limit30_full.dat:Runtime Sum for 3_gens_0.02_limit30: 300.2133136781049
expected_results/3_gens_0.02_limit40_full.dat:Total Timeouts: 0
expected_results/3_gens_0.02_limit40_full.dat:Runtime Sum for 3_gens_0.02_limit40: 230.78057197097223
expected_results/3_gens_0.02_limit50_full.dat:Total Timeouts: 0
expected_results/3_gens_0.02_limit50_full.dat:Runtime Sum for 3_gens_0.02_limit50: 197.87818186660297
expected_results/3_gens_0.02_limit60_full.dat:Total Timeouts: 0
expected_results/3_gens_0.02_limit60_full.dat:Runtime Sum for 3_gens_0.02_limit60: 184.96431582502555
expected_results/3_gens_0.02_limit70_full.dat:Total Timeouts: 0
expected_results/3_gens_0.02_limit70_full.dat:Runtime Sum for 3_gens_0.02_limit70: 180.17940601176815
expected_results/3_gens_0.02_limit80_full.dat:Total Timeouts: 0
expected_results/3_gens_0.02_limit80_full.dat:Runtime Sum for 3_gens_0.02_limit80: 179.49532037990866
expected_results/3_gens_0.02_limit90_full.dat:Total Timeouts: 0
expected_results/3_gens_0.02_limit90_full.dat:Runtime Sum for 3_gens_0.02_limit90: 185.15186209476087
expected_results/3_gens_0.06_limit10_full.dat:Total Timeouts: 3
expected_results/3_gens_0.06_limit10_full.dat:Runtime Sum for 3_gens_0.06_limit10: 1252.6402194999391
expected_results/3_gens_0.06_limit20_full.dat:Total Timeouts: 0
expected_results/3_gens_0.06_limit20_full.dat:Runtime Sum for 3_gens_0.06_limit20: 484.2423540155287
expected_results/3_gens_0.06_limit30_full.dat:Total Timeouts: 0
expected_results/3_gens_0.06_limit30_full.dat:Runtime Sum for 3_gens_0.06_limit30: 298.9672457005945
expected_results/3_gens_0.06_limit40_full.dat:Total Timeouts: 0
expected_results/3_gens_0.06_limit40_full.dat:Runtime Sum for 3_gens_0.06_limit40: 226.0965833342634
expected_results/3_gens_0.06_limit50_full.dat:Total Timeouts: 0
expected_results/3_gens_0.06_limit50_full.dat:Runtime Sum for 3_gens_0.06_limit50: 194.50031492701964
expected_results/3_gens_0.06_limit60_full.dat:Total Timeouts: 0
expected_results/3_gens_0.06_limit60_full.dat:Runtime Sum for 3_gens_0.06_limit60: 177.76216879370622
expected_results/3_gens_0.06_limit70_full.dat:Total Timeouts: 0
expected_results/3_gens_0.06_limit70_full.dat:Runtime Sum for 3_gens_0.06_limit70: 177.95484349987237
expected_results/3_gens_0.06_limit80_full.dat:Total Timeouts: 0
expected_results/3_gens_0.06_limit80_full.dat:Runtime Sum for 3_gens_0.06_limit80: 183.45553014701
expected_results/3_gens_0.06_limit90_full.dat:Total Timeouts: 0
expected_results/3_gens_0.06_limit90_full.dat:Runtime Sum for 3_gens_0.06_limit90: 198.7383853411302
expected_results/3_gens1.1_full.dat:Total Timeouts: 31
expected_results/3_gens1.1_full.dat:Runtime Sum for 3_gens1.1: 3090.2185648134327
expected_results/3_gens1.2_full.dat:Total Timeouts: 32
expected_results/3_gens1.2_full.dat:Runtime Sum for 3_gens1.2: 3288.4201473522116
expected_results/3_gens1.3_full.dat:Total Timeouts: 31
expected_results/3_gens1.3_full.dat:Runtime Sum for 3_gens1.3: 3247.655933256028
expected_results/3_gens1.4_full.dat:Total Timeouts: 31
expected_results/3_gens1.4_full.dat:Runtime Sum for 3_gens1.4: 3215.371628880268
expected_results/3_gens1.5_full.dat:Total Timeouts: 28
expected_results/3_gens1.5_full.dat:Runtime Sum for 3_gens1.5: 3229.940575722896
expected_results/3_gens1.6_full.dat:Total Timeouts: 32
expected_results/3_gens1.6_full.dat:Runtime Sum for 3_gens1.6: 3291.056965477008
expected_results/3_gens1.7_full.dat:Total Timeouts: 30
expected_results/3_gens1.7_full.dat:Runtime Sum for 3_gens1.7: 3184.8412743340596
expected_results/3_gens1.8_full.dat:Total Timeouts: 0
expected_results/3_gens1.8_full.dat:Runtime Sum for 3_gens1.8: 0.07022180501371622
expected_results/3_gens1.9_full.dat:Total Timeouts: 0
expected_results/3_gens1.9_full.dat:Runtime Sum for 3_gens1.9: 0.08328074001474306
expected_results/3_gens_limit10_full.dat:Total Timeouts: 3
expected_results/3_gens_limit10_full.dat:Runtime Sum for 3_gens_limit10: 1236.3654018160887
expected_results/3_gens_limit20_full.dat:Total Timeouts: 0
expected_results/3_gens_limit20_full.dat:Runtime Sum for 3_gens_limit20: 485.51210535137216
expected_results/3_gens_limit30_full.dat:Total Timeouts: 0
expected_results/3_gens_limit30_full.dat:Runtime Sum for 3_gens_limit30: 298.5649667106336
expected_results/3_gens_limit40_full.dat:Total Timeouts: 0
expected_results/3_gens_limit40_full.dat:Runtime Sum for 3_gens_limit40: 224.70798944385024
expected_results/3_gens_limit50_full.dat:Total Timeouts: 0
expected_results/3_gens_limit50_full.dat:Runtime Sum for 3_gens_limit50: 191.50804620899726
expected_results/3_gens_limit60_full.dat:Total Timeouts: 0
expected_results/3_gens_limit60_full.dat:Runtime Sum for 3_gens_limit60: 178.40439782803878
expected_results/3_gens_limit70_full.dat:Total Timeouts: 0
expected_results/3_gens_limit70_full.dat:Runtime Sum for 3_gens_limit70: 173.5992081639124
expected_results/3_gens_limit80_full.dat:Total Timeouts: 0
expected_results/3_gens_limit80_full.dat:Runtime Sum for 3_gens_limit80: 175.740799327672
expected_results/3_gens_limit90_full.dat:Total Timeouts: 0
expected_results/3_gens_limit90_full.dat:Runtime Sum for 3_gens_limit90: 188.68523609795375
expected_results/3_lp0.02_full.dat:Total Timeouts: 0
expected_results/3_lp0.02_full.dat:Runtime Sum for 3_lp0.02: 274.77880966459634
expected_results/3_lp0.04_full.dat:Total Timeouts: 0
expected_results/3_lp0.04_full.dat:Runtime Sum for 3_lp0.04: 371.68102829006966
expected_results/3_lp0.06_full.dat:Total Timeouts: 0
expected_results/3_lp0.06_full.dat:Runtime Sum for 3_lp0.06: 451.52803043840686
expected_results/3_lp0.08_full.dat:Total Timeouts: 0
expected_results/3_lp0.08_full.dat:Runtime Sum for 3_lp0.08: 520.7040306773852
expected_results/3_lp0.1_full.dat:Total Timeouts: 0
expected_results/3_lp0.1_full.dat:Runtime Sum for 3_lp0.1: 577.7438230617554
expected_results/3_lp_full.dat:Total Timeouts: 0
expected_results/3_lp_full.dat:Runtime Sum for 3_lp: 0.09467090503312647
expected_results/3_lpzono_full.dat:Total Timeouts: 0
expected_results/3_lpzono_full.dat:Runtime Sum for 3_lpzono: 0.07483581197448075
expected_results/3_single_bound_full.dat:Total Timeouts: 0
expected_results/3_single_bound_full.dat:Runtime Sum for 3_single_bound: 0.09625580802094191
expected_results/3_single_bound_lpzono_full.dat:Total Timeouts: 26
expected_results/3_single_bound_lpzono_full.dat:Runtime Sum for 3_single_bound_lpzono: 2998.532694309368



== RE-RUNNING ALL MEASUREMENTS (TAKES TWO DAYS) ==

If you want to re-run the measurements, you'll need about two days for everything to run. The results are stored in the "results" folder, so first delete this if it exists if you want to run from scratch". You should be able to stop and re-start measurements without losing progress, as the results/individual folder stores the individual benchmark results and is checked before starting a new measurements.

For running meaure_all.py, first you must install the nnenum tool. You want to use this commit: https://github.com/stanleybak/nnenum/commit/9597fb507950901b4241e582c3038d6381ce7cbd

To do this, clone the project and run:
git checkout 9597fb507950901b4241e582c3038d6381ce7cbd

 
You need python 3.6 and pip3.

Install python packages with "pip3 install -r requirements.txt"

You also may need to install matplotlib-tk (sudo apt install python3-tk).

Once you install the requirements, make sure to add the nnenum folder onto your PYTHONPATH

Once that's done, you should be able to set the folder to "code" and do "python3 measure_all.py". If you get errors on importing the nnenum packages, make sure you set the PYTHONPATH correctly. Mine is: 

$ echo $PYTHONPATH
:/home/stan/repositories/nnenum/nnenum:



== RE-RUNNING A SPECIFIC MEASUREMENT (FAST) ==

You can re-run specific measurements on specific benchmarks, for example, to confirm that the benchmark mentioned in the conclusion really is fast (property 2 and network 4-2). First install and setup nnenum as described about so that measure_all.py is able to run.

Then you can directly run acasxu_single_nnenum.py with the benchmark and optimization level.

For example, in the paper in table 3, the fastest method is "Split Min 70", which has its results printed in expected_results/3_gens_limit70_full.dat. In this file, the line for that benchmark says:
"4_2	2	safe	21.21232216496719". So we expect a result of "safe" and a runtime of 21.2 seconds. Try this out by running:

$ python3 acasxu_single_nnenum.py 4 2 2 3_gens_limit70

You should see output in the terminal as it's running. Note your timing may vary if you use different hardware... generally more cores will run faster.

