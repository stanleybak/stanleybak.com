'''
Stanley Bak, Kerianne Hobbs
Satellite motion simulation in Python

Variable Time-step space debris collision checker
'''

import multiprocessing
import time
import psutil # to get the number of physical CPU cores (not logical)

from util import Timers
import loader
import collision_detection
from occupancy import init_occupancy

def check_bin(param):
    '''checks a single bin

    param is a 3-tuple: (satellites, time_bound_secs, step_secs), where
    satellties is a list of SatelliteData
    time_bound_secs is the simulation time bound
    step_secs is the step size
    '''

    # extact 3-tuple given in param
    satellites, time_bound_secs, step_secs = param

    print_output = False #len(satellites) >= 5000

    # indices get out of order due to binning; fix it
    for i, sat in enumerate(satellites):
        sat.index = i

    init_occupancy(satellites, time_bound_secs, do_print=print_output)

    witness = collision_detection.aabb_4d(satellites, time_bound_secs, step_secs, print_output)

    return witness

def measure(single_threaded=True):
    '''measures the runtime of the 4D AABB method, as we increase the number of satellites'''

    Timers.tic("total")

    max_time = 60.0 * 10 # 10 minutes
    tle_filename = 'TLE_files/TLEFullCatalog3April2018.txt' #'TLE_files/cubesatTLE.txt'

    num_bins = 1 if single_threaded else psutil.cpu_count(logical=False)
    print("num cores = {}".format(num_bins))

    print("$n$ & 4D-AABB (RT-Ratio) \\\\")

    # roughly exponentially increasing with a 1.5 factor
    sats = [100, 100, 150, 225, 350, 500, 750, 1250, 1750, 2500, 4000, 6000, 9000, 12000, 16838,
            20000, 30000, 40000, 50000, 60000, 70000, 80000, 90000]

    step_secs = 1e-4 # LEO is 7800 km / sec, step size of 1e-4 -> .78 meters per step

    name = "single" if single_threaded else "multi"
    outfile = "scalability/{}_{}.dat".format(name, multiprocessing.cpu_count())

    with open(outfile, "w") as f:

        for num_satellites in sats:

            print("{} & ".format(num_satellites), end="", flush=True)
            f.write("{} ".format(num_satellites))

            time_bound_secs = max_time
            satellite_radius = 1e-9

            start = time.perf_counter()

            bins = loader.load_tles_binned(tle_filename, num_satellites, satellite_radius, num_bins, do_print=False)

            params = [(b, max_time, step_secs) for b in bins]

            if single_threaded:
                check_bin(params[0])
            else:
                with multiprocessing.Pool() as p:
                    p.map(check_bin, params)
            
            #satellites = loader.random_satellites(num_satellites, satellite_radius, random_seed=seed, do_print=False)
            #init_occupancy(satellites, time_bound_secs, do_print=False)

            #collision_detection.aabb_4d(satellites, time_bound_secs, step_secs)
            aabb_4d = time.perf_counter() - start
            ratio = time_bound_secs / aabb_4d

            print("{}s ({}x) \\\\".format(round(aabb_4d, 2), round(ratio, 1)))
            f.write("{}\n".format(aabb_4d))

            if ratio < 0.8:
                break

    Timers.toc("total")
    #Timers.print_stats()

def measure_binning(start=1, stop=16):
    'measures the effect of binning on the largest bin size'

    infile = 'TLE_files/TLEFullCatalog3April2018.txt' #'TLE_files/cubesatTLE.txt'
    satellite_radius = 0.001

    divider = 'a' # semi-major axis
    _, a_array, e_array = loader.load_tles(infile, satellite_radius, do_print=True, return_a_e_array=True)

    print("num_partitions max_partition_size")

    with open("num_bins/binning_data.dat", 'w') as f:

        for num_bins in range(start, stop+1):
            _, _, _, bins = loader.orbitBinner_generic(a_array, e_array, divider, num_bins)

            biggest_bin = bins[0]

            for b in bins:
                if len(b) > len(biggest_bin):
                    biggest_bin = b

            s = "{} {}".format(num_bins, len(biggest_bin))
            print(s)
            f.write(s + "\n")

            if num_bins == stop:
                # output the number of satellites in each bin
                with open("num_bins/last_bin.dat", "w") as f2:
                    print("Objects in each partition:")
                    for i, b in enumerate(bins):
                        s = "{} {}".format(i+1, len(b))
                        f2.write(s + "\n")
                        print(s)

def compare_methods():
    ''''compares methods for consistent results

    This compares the results from Brute force, AABB Tree, and 4D AABB Tree for consistency.

    It keeps doubling the satellite radius until a collision a found, and then makes sure all the methods
    find a counterexample at the same time.
    '''

    Timers.tic("total")

    num_trials = 5
    num_sat = 200
    init_satellite_radius = 32.0
    time_bound_secs = 240.0
    step_secs = .5

    for trial in range(num_trials):
        witness = None
        satellite_radius = init_satellite_radius

        while witness is None:
            print("Trying radius: {}".format(satellite_radius))

            filename = 'TLE_files/TLEFullCatalog3April2018.txt' #'TLE_files/cubesatTLE.txt'
            satellites = loader.load_tles(filename, satellite_radius, num_sat=(trial+1)*num_sat)
            satellites = satellites[-num_sat:]

            print(".", end="", flush=True)

            init_occupancy(satellites, time_bound_secs)
            print(".", end="", flush=True)

            witness_list = []

            print_output = False

            #witness_list.append(collision_detection.brute_force(satellites, time_bound_secs, step_secs))
            #print(".", end="", flush=True)
            witness_list.append(collision_detection.aabb_basic(satellites, time_bound_secs, step_secs, print_output))
            print(".", end="", flush=True)
            witness_list.append(collision_detection.aabb_4d(satellites, time_bound_secs, step_secs, print_output))
            print(".")

            for i, w in enumerate(witness_list):
                print("Witness from method #{}: {}".format(i, w))

                if witness_list[0] is None:
                    assert w is None, "witness was not None for method #{}".format(i)
                else:
                    assert w is not None, "witness was None for method #{}".format(i)
                    t1 = witness_list[0][2]
                    t2 = w[2]

                    assert abs(t1 - t2) < 1e-6, "First collision time was different for method #{}".format(i)

            if witness_list[0] is not None:
                t = witness_list[0][2]
                print("First collision at time {}".format(round(t, 4)))

                break

            satellite_radius *= 2

    Timers.toc("total")
    print("\nDone: all methods produced witnesses at the same time step")
    #Timers.print_stats()

def measure_basic_aabb():
    '''measures performance with the basic aabb approach'''

    Timers.tic("total")

    tle_filename = 'TLE_files/TLEFullCatalog3April2018.txt' #'TLE_files/cubesatTLE.txt'

    num_satellites = 100 #16838
    step_secs = 1e-4 # LEO is 7800 km / sec, step size of 1e-4 -> .78 meters per step

    max_time = step_secs * 600

    satellite_radius = 1e-9

    start = time.perf_counter()

    bins = loader.load_tles_binned(tle_filename, num_satellites, satellite_radius, 1, do_print=True)

    start2 = time.perf_counter()

    satellites = bins[0]
    init_occupancy(satellites, max_time, do_print=True)
    collision_detection.aabb_basic(satellites, max_time, step_secs, True)

    total = time.perf_counter() - start
    check = time.perf_counter() - start2

    print(f"Check time {round(total, 4)} ({round(check,4)} in checking)")

    Timers.toc("total")
    #Timers.print_stats()

if __name__ == "__main__": # if the script is run directly, call main
    #measure_binning()
    #measure(single_threaded=True)
    #measure(single_threaded=False)

    # compare methods for correctness
    #compare_methods()
    measure_basic_aabb()
