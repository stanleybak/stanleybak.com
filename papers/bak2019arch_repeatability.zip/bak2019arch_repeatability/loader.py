'''
Stanley Bak
September 2018

Satellite loader implementation

This file contains functions which can either load satellite data from TLEs, orbital elements, or 
generate the data randomly

All functions return a list of SatelliteData objects
'''

import math
import random

from sgp4.io import twoline2rv
from sgp4.earth_gravity import wgs84

from util import Freezable, Timers
from occupancy import OccupancyRegionComputer

class SatelliteData(Freezable):
    'storage objects for satellite parameters'

    def __init__(self, index, radius, e, a, i, big_omega, omega, nu):
        '''
        index           - index in the satellite list for this object
        radius [km]     - infinity norm satelite radius used for collision detection 
        e               - eccentricity (0 <= e <= 1)
        a [km]          - semi-major axis
        i [rad]         - inclination
        big_omega [rad] - right ascension of the ascending node
        omega [rad]     - argument of perigee
        nu [rad]        - true anomaly
        '''

        assert 0 <= e < 1.0, "orbit should be elliptical 0 <= e < 1"

        self.index = index
        self.radius = radius

        self.e = e
        self.a = a
        self.i = i
        self.big_omega = big_omega
        self.omega = omega
        self.nu = nu

        self.occ_computer = None # object for computing the occupancy regions, initialized on init_occupancy

        # current time for the current satellite
        self.t_min = None
        self.t_max = None

        self.freeze_attrs()

    def init_occupancy(self, time_bound_secs, do_print):
        '''
        initialize the occupancy region computer object

        time_bound_secs [sec] - the collision-checking time bound (used for simulation)
        '''

        self.occ_computer = OccupancyRegionComputer(self, time_bound_secs, do_print)

    def occ(self, t_sec):
        '''returns the occupancy region box at the requested time. 

        t_sec [sec] - the time requested for the occupancy box

        returns: a list of lists corresponding to the 3D box occupied at t_sec        
        '''

        return self.occ_computer.occ(t_sec)

    def occ_4d(self):
        '''returns the occupancy region box between this satellite's t_min and t_max. 

        returns: a list of lists corresponding to the 3D box occupied between [t_min, t_max]
        '''

        rv = self.occ_computer.occ_4d()

        return rv

def random_satellites(num_sat, satellite_radius, random_seed=0, do_print=True):
    '''create random satellites
    
    num_sat               - number of satellites to create
    satellite_radius [km] - infinity-norm radius of each satellite, used for collision detection 
    random_seed           - seed for the random number generator to use (for determinism of measurements) 

    returns: a list of SateliteData objects with length num_sat
    '''

    Timers.tic("random_satellites")

    satellites = []

    random.seed(random_seed) # make the random generation deterministic

    for index in range(num_sat):
        if index > 0 and index % 1000 == 0:
            if do_print:
                print("generating sat #{}".format(index))
        
        nu = random.uniform(0, 2*math.pi)
        e = random.uniform(0, 0.05)
        a = random.uniform(6900, 7700) # CONSTANTS.earth_radius_km # LEO (+6371)
        i = random.uniform(0, 2*math.pi * 100 / 360)
        big_omega = random.uniform(0, 2*math.pi)
        omega = random.uniform(0, 2*math.pi)

        satellites.append(SatelliteData(index, satellite_radius, e, a, i, big_omega, omega, nu))

    assert len(satellites) == num_sat

    Timers.toc("random_satellites")

    return satellites

def load_tles_binned(filename, num_satellites, satellite_radius, num_bins, num_sat=None, do_print=True):
    '''
    loads satellites from a TLE file and puts them into bins

    filename              - the TLE filename to load from
    satellite_radius [km] - infinity-norm radius of each satellite, used for collision detection 
    num_bins              - number of bins to use
    do_print              - print occasional output to stdout while loading?

    returns: a list of lists of SateliteData objects
    '''

    divider = 'a' # divide by semi-major axis

    satellites, a_array, e_array = load_tles(filename, satellite_radius, num_sat=num_satellites, do_print=do_print,
                                             return_a_e_array=True)

    _, _, _, bin_list = orbitBinner_generic(a_array, e_array, divider, num_bins)

    rv = []

    for index_list in bin_list:
        sat_list = []

        for index in index_list:
            sat_list.append(satellites[index])

        rv.append(sat_list)

    return rv        

def load_tles(filename, satellite_radius, num_sat=None, do_print=True, return_a_e_array=False):
    '''
    loads satellites from a TLE file

    filename              - the TLE filename to load from
    satellite_radius [km] - infinity-norm radius of each satellite, used for collision detection 
    max_num_sat           - maximum number of satellits to load
    do_print              - print occasional output to stdout while loading?
    return_a_e_erray      - should the a_array and e_array be returned as well

    returns: 
    list of SateliteData objects (if return_a_e_erray is False)
    -or-
    3-tuple: (list of SateliteData objects, a_array, e_array) (if return_a_e_erray is True)
    '''

    Timers.tic("load_tles")
    satellites = []

    max_num_sat = float('inf')

    if num_sat is not None:
        max_num_sat = num_sat
    
    a_array, e_array, nu_array, i_array, big_omega_array, omega_array = TLEtoOrbitalElements( \
        filename, max_num_sat, do_print)

    last = len(a_array) - 1

    if num_sat is not None:
        while len(a_array) < num_sat:
            # generate randomly-sampled satellites up to num_sat
            a_array.append(a_array[random.randint(0, last)])
            e_array.append(e_array[random.randint(0, last)])
            nu_array.append(nu_array[random.randint(0, last)])
            i_array.append(i_array[random.randint(0, last)])
            big_omega_array.append(big_omega_array[random.randint(0, last)])
            omega_array.append(omega_array[random.randint(0, last)])
        
    combined_array = zip(a_array, e_array, nu_array, i_array, big_omega_array, omega_array)

    for index, (a, e, nu, i, big_omega, omega) in enumerate(combined_array):
        satellites.append(SatelliteData(index, satellite_radius, e, a, i, big_omega, omega, nu))

    Timers.toc("load_tles")

    if num_sat is not None:
        assert len(satellites) == num_sat

    if return_a_e_array:
        return satellites, a_array, e_array
    
    return satellites

def TLEtoOrbitalElements(filename, max_num_sat=float('inf'), do_print=True):
    '''
    for a text file containin 3 line TLEs, outputs orbital elements'
    # units: i [degrees], e [-], nu [rad], omega [degrees], Omega [degrees], a [km]

    max_num_sat - maximum number of satellites to load
    '''

    rad2deg = 180.0 / math.pi

    # Initialize   
    line1s = []
    line2s = []
    i = []
    e = []
    n = []
    omega = []
    M = []
    Omega = []
    a= []
    Es = []
    nu = []
    satnum = []
  
    # Open the TLE File, assuming it is a text file in standard format
    tle = open(filename, 'r')

    # Go line by line in the TLE
    lines = [line.split('\n') for line in tle.readlines()]
    num_sat = len(lines)/3
    x = 0

    while x < num_sat and x < max_num_sat:

        if x > 0 and x % 1000 == 0:
            if do_print:
                print("loading from TLE file sat #{}".format(x))
        
        line1s.append((lines[3*x+1])[0])
        line2s.append((lines[3*x+2])[0])
        satnum.append(x + 1)
        satellite = twoline2rv(line1s[x], line2s[x], wgs84) 
        i.append(satellite.inclo * rad2deg) # [degrees] inclination TLE: Degrees, SGP4: Radians
        e.append(satellite.ecco)  #[unitless] eccentricity
        n.append(satellite.no / 60) #[rad/s] mean motion; TLE: [(rev/day)*(day/hr)*(hr/x) = rev/s] SGP4: [(rad/min)]
        omega.append(satellite.argpo * rad2deg) # [degrees] argument of perigee TLE: Degrees, SGP4: Radians
        M.append(satellite.mo * rad2deg) # [degrees] mean anomoly TLE: Degrees, SGP4: Radians
        Omega.append(satellite.nodeo* rad2deg) # [degrees] RAAN TLE: Degrees, SGP4: Radians
        a.append(satellite.a * wgs84.radiusearthkm) #[km] SGP4 uses a as fractions of earth radius 
        #calculate semi major axis from mean motion a = cuberoot(mu/n^2)
        #a.append((mu/(n[x]**2))**(1./3))
        x = x+1

        #calculate true anomaly
        if satellite.ecco < 0.8:
            E = satellite.mo 
        else:
            E = math.pi
            
        F = E - satellite.ecco * math.sin(E) - satellite.mo
        
        Fprime = 1.0 - satellite.ecco * math.cos(E)

        # variables for iterative solution of Eccentric Anomaly
        maxiter = 30
        it = 0
        delta = 0.0000001
        
        while abs(F)>delta and (it<maxiter):
            E = E - F / Fprime
            F = E - satellite.ecco * math.sin(E) - satellite.mo
            Fprime = 1.0 - satellite.ecco * math.cos(E)
            it = it + 1
            
        Es.append(E)
        tanhalfnu = ((1+satellite.ecco)/(1-satellite.ecco))**(1.0/2.0) * math.tan(0.5*E)
        nus = 2 * math.atan(tanhalfnu)
        
        while nus < 0:
            nus += 2 * math.pi

        while nus > 2 * math.pi:
            nus -= 2 * math.pi

        nu.append(nus)
            
    return a, e, nu, i, Omega, omega

def orbitBinner_generic(a_array, e_array, divider, num_bins):
    '''Creates altitude bins. The top and bottom of each bin are found by putting
    the semi-major axis, perigee, or apogee (a) of each satellite in ascending order and choosing the altitude
    at every (total # of satellites/16)th value. 
    INPUTS:
    - a_array: [km] array of semi-major axis values 
    - e_array: array of satellite orbit eccentricities
    - divider: divider method, one of 'a', 'perigee', or 'apogee'
    - num_bins: number of bins
    OUTPUTS:
    - [int] Inital number of semi-major axis (a) values in each bin
    - [array/list] Ordered divider (a/apogee/perigee) values (smallest to largest)
    - [array/list] Set of altitudes that define bin 
    - [list of lists] lists containing satellite indexes for satellites in each bin
    '''


    num_in_bin = math.ceil(len(a_array)/num_bins) # number of spacecraft in each bin

    if divider == 'a':
        h_sorted = sorted(a_array)
    elif divider == 'apogee':
        apo_array = []
        
        for x in range(len(a_array)):
            apogee = a_array[x]*(1+e_array[x])
            apo_array.append(apogee)
            
        h_sorted = sorted(apo_array)
    elif divider == 'perigee':
        peri_array = []
        
        for x in range(len(a_array)):
            peri_array.append(a_array[x]*(1-e_array[x]))
            
        h_sorted = sorted(peri_array)
    else:
        raise RuntimeError("Unknown divider method: {}".format(divider))
    
    h_dividers = [] #initialize
    
    for i in range(num_bins-1):
        h_dividers.append(h_sorted[int(num_in_bin)*(i+1)])

    bin_list = [] # list of lists

    for i in range(num_bins):
        bin_list.append([]) # each element of bin_list is a list

    #find radius at perigee and radius at apogee for each satellite
    for x in range(len(a_array)):
        perigee_km = a_array[x]*(1-e_array[x])
        apogee_km = a_array[x]*(1+e_array[x])

        for bin_num in range(num_bins):
            # find the min and max height for the bin_num
            if bin_num == 0:
                min_height = -float("inf") # first bin: negative infinity min height
            else:
                min_height = h_dividers[bin_num - 1]

            if bin_num == num_bins - 1:
                max_height = float("inf") # last bin: positive infinity max height
            else:
                max_height = h_dividers[bin_num]

            # insert into bin_num if perigee <= max_height and apogee > min_height
            if perigee_km <= max_height and apogee_km > min_height:
                bin_list[bin_num].append(x)
    
    return num_in_bin, h_sorted, h_dividers, bin_list
