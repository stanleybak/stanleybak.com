'''
Stanley Bak
September 2018

AABB Tree Python interface. This makes use of aabb.py (the swig-generated interface to the c++ version)
'''

from heapq import heappop, heappush

from util import Freezable, Timers

import aabb

class AABBTree(Freezable):
    'an axis-aligned bounding box tree with some specific functionality for the collision detection problem'

    DELETED_INDEX = -1

    def __init__(self, dims, num_objects):
        '''create the AABB tree, pre-initializing for the given number of objects

        dims - the number of dimensions in the aabb tree
        num_objects - the number of objects that will be inserted into the tree (an optimization)
        '''

        self.dims = dims
        
        # n-d aabb tree with 0 skin thickness, preallocated for num_objects particles
        self.tree = aabb.Tree(dims, 0, num_objects)

        # preallocated vector objects used in query and insert
        self.lower_bound = aabb.VectorDouble(dims)
        self.upper_bound = aabb.VectorDouble(dims)

        # priority queue for finding the smallest max time object
        # we will insert pairs: [max_time, object_index]
        # if we need to delete objects (due to updates in max time), the 2nd element will be set to DELETED_INDEX
        self.heap = []
        self.index_to_pair = {} # mapping of object index to the pairs object in the heap, used for deleting


    def get_smallest_max_time_object(self):
        '''get the object with the smallest max time in the tree

        returns: the index of the object with the smallest t_max
        '''

        Timers.tic("get_smallest_max_time_object")

        # pop deleted objects from the top of the heap
        while self.heap:
            _, obj_index = self.heap[0]
            
            if obj_index == AABBTree.DELETED_INDEX: # object was deleted
                heappop(self.heap)
            else:
                break

        if not self.heap:
            raise KeyError('pop from an empty priority queue')

        _, obj_index = self.heap[0]

        Timers.toc("get_smallest_max_time_object")

        return obj_index

    def set_max_time(self, obj_index, new_max_time):
        '''
        update the bookkeeping associated with tracking an object's max time

        obj_index    - the index of the object to update
        new_max_time - the new maximum time for the object (or None to delete)
        '''

        Timers.tic("set_max_time")

        # first, mark the item as deleted by updating the existing pair
        if obj_index in self.index_to_pair:
            pair = self.index_to_pair.pop(obj_index)
            pair[1] = AABBTree.DELETED_INDEX

        if new_max_time is not None:
            # construct a new pair and insert it into the heap
            pair = [new_max_time, obj_index]

            heappush(self.heap, pair)

            # add it to the tracker in case we need to update it or delete it later
            self.index_to_pair[obj_index] = pair

        Timers.toc("set_max_time")

    def is_empty(self):
        '''
        is the aabb tree empty?

        returns: True if the aabb tree has no objects in it
        '''

        is_empty = self.tree.nParticles() == 0

        if is_empty:
            assert not self.index_to_pair

        return is_empty

    def query(self, box):
        '''get all the indices which overlap the passed-in box

        box - the query box, a list of pairs of min/max pairs for each dimension

        returns: a list of object indices that intersect box
        '''

        assert len(box) == self.dims

        for i in range(self.dims):
            self.lower_bound[i] = box[i][0]
            self.upper_bound[i] = box[i][1]

        # create an AABB object from the bounds
        aabb_object = aabb.AABB(self.lower_bound, self.upper_bound)

        Timers.tic("query")
        particles = self.tree.query(aabb_object)
        Timers.toc("query")

        return [p for p in particles] # converts particles to a python list

    def query_object(self, index):
        '''get all the indices which overlap the passed-in object, which is already in the tree

        index - the object index we want get collisions with

        returns: a list of object indices that intersect the object with the passed-in index
        '''

        Timers.tic("query")
        particles = self.tree.query(index)
        Timers.toc("query")

        return [p for p in particles] # converts particles to a python list

    def insert(self, index, box):
        '''inserts an object into the aabb tree with the given bounding box

        index - the object index we're inserting
        box   - the object's bounding box, a list of pairs of min/max pairs for each dimension
        '''

        assert len(box) == self.dims

        for i in range(self.dims):
            self.lower_bound[i] = box[i][0]
            self.upper_bound[i] = box[i][1]

        self.tree.insertParticle(index, self.lower_bound, self.upper_bound)

        # if it's a 4-d aabb tree (with a time dimension), keep track of the smallest max time
        if self.dims == 4:
            self.set_max_time(index, box[3][1])

    def update(self, index, box):
        '''update the bounds of an object already in the aabb tree

        index - the object index we're inserting
        box   - the object's new bounding box, a list of pairs of min/max pairs for each dimension
        '''

        for i in range(self.dims):
            self.lower_bound[i] = box[i][0]
            self.upper_bound[i] = box[i][1]

        self.tree.updateParticle(index, self.lower_bound, self.upper_bound, True) # alwaysReinsert = True

        # if it's a 4-d aabb tree (with a time dimension), update the smallest max time
        if self.dims == 4:
            self.set_max_time(index, box[3][1])

    def remove(self, index):
        ''' remove a previously-inserted object from the aabb tree

        index - the object index
        '''

        self.tree.removeParticle(index)

        # if it's a 4-d aabb tree (with a time dimension), keep track of the smallest max time
        if self.dims == 4:
            self.set_max_time(index, None)

def has_intersection(box_a, box_b):
    '''
    is there a non-empty intersection between boxes a and b?

    box_a - a list of 2-tuples (min/max for every dimension)
    box_b - a list of 2-tuples (min/max for every direction)

    returns True if the boxes intersect
    '''

    assert len(box_a) == len(box_b), "boxes should have the name number of dimensions"
    rv = True
    num_dims = len(box_a)
    
    for dim in range(num_dims):
        if box_a[dim][0] > box_b[dim][1] or box_a[dim][1] < box_b[dim][0]:
            rv = False
            break

    return rv
