'''
Stanley Bak
September 2018

Collision detection algorithms

This file contains the implementation of the high-level collision detection algorithms described in the RTAS paper
'''

import math

import numpy as np

from aabb_tree import AABBTree, has_intersection

from util import Timers

def brute_force(satellites, time_bound_secs, step_secs):
    '''brute force collision detection algorithm

    satellites            - list of SateliteData objects
    time_bound_secs [sec] - collision checking time bound (T)
    step_secs [sec]       - collision checkin step size (delta)

    returns: first collision (w_index, v_index, time_secs) or None
    '''

    num_steps = 1 + int(round(time_bound_secs / step_secs))
    n = len(satellites)
    
    for t in np.linspace(0, time_bound_secs, num_steps):
        for i in range(n):
            occ_i = satellites[i].occ(t)
            
            for j in range(i+1, n):
                occ_j = satellites[j].occ(t)

                if has_intersection(occ_i, occ_j):
                    return (i, j, t)

    return None

def aabb_basic(satellites, time_bound_secs, step_secs, do_print=False):
    '''basic aabb tree collision detection algorithm

    satellites            - list of SateliteData objects
    time_bound_secs [sec] - collision checking time bound (T)
    step_secs [sec]       - collision checkin step size (delta)

    returns: first collision (w_index, v_index, time_secs) or None
    '''

    num_steps = 1 + int(round(time_bound_secs / step_secs))
    n = len(satellites)
    
    for t in np.linspace(0, time_bound_secs, num_steps):
        tree = AABBTree(3, n) # 3-d aabb tree with room for n objects preallocated

        if do_print:
            print("Time {}/{}".format(round(t, 8), round(time_bound_secs, 8)))

        for i in range(n):
            occ_i = satellites[i].occ(t)

            collision_list = tree.query(occ_i)

            if collision_list:
                return (collision_list[0], i, t)
            
            tree.insert(i, occ_i)

    return None

def aabb_4d(satellites, time_bound_secs, step_secs, print_times=False):
    '''4D AABB tree collision detection algorithm

    satellites            - list of SateliteData objects
    time_bound_secs [sec] - collision checking time bound (T)
    step_secs [sec]       - collision checkin step size (delta)

    returns: first collision (w_index, v_index, time_secs) or None
    '''

    Timers.tic("aabb_4d")

    rv = None
    n = len(satellites)
    tree = AABBTree(4, n) # 4-d aabb tree with room for n objects preallocated

    collision_pair = initialize_tree(tree, satellites)

    if collision_pair:
        rv = (collision_pair[0], collision_pair[1], 0.0)
    else:
        last_print_time = -1

        Timers.tic("main loop")
        while True:
            v_index = tree.get_smallest_max_time_object()

            # print if t_max has changed
            if print_times and abs(satellites[v_index].t_max - last_print_time) > 1e-6:
                last_print_time = satellites[v_index].t_max
                print("time {} - index {}".format(round(satellites[v_index].t_max, 8), v_index))

            if satellites[v_index].t_max >= time_bound_secs:
            #    tree.remove(v_index)
                break
            
            advance_time(satellites[v_index], time_bound_secs, step_secs)

            tree.update(v_index, satellites[v_index].occ_4d())

            u_index = resolve_collisions(satellites, v_index, tree, step_secs)

            if u_index is not None:
                rv = (v_index, u_index, satellites[v_index].t_min)
                break

        Timers.toc("main loop")
        
    Timers.toc("aabb_4d")
            
    return rv

def initialize_tree(tree, satellites):
    '''4d AABB tree collision detection procedure initializeTree

    inserts all satellits at time 0 into the tree

    tree - an AABBTree object
    satellites - the list of SateliteData objects

    returns pair of indices which collide at time 0, or None
    '''

    Timers.tic("initialize_tree")

    rv = None
    n = len(satellites)

    for i in range(n):
        satellites[i].t_min = 0
        satellites[i].t_max = 0

        box = satellites[i].occ_4d()
        collision_list = tree.query(box)

        if collision_list:
            rv = (collision_list[0], i)
            break

        tree.insert(i, box)

    Timers.toc("initialize_tree")

    return rv

def advance_time(sat, time_bound_secs, step_secs):
    ''' advance the time for the passed-in satellite data object, trying to increase the time step.
    This modifies sat.t_min and sat.t_max

    sat             - the SateliteData object we're advancing
    time_bound_secs - the global time bound
    step_secs       - the computation time step
    '''

    prev_steps = int(round((sat.t_max - sat.t_min) / step_secs))
    next_steps = 1

    if prev_steps > 0:
        next_steps = 2 * prev_steps

    sat.t_min = sat.t_max + step_secs
    sat.t_max = sat.t_min + next_steps * step_secs

    if sat.t_max > time_bound_secs:
        sat.t_max = time_bound_secs

    # in case of accumulated floating point errors, we need to cap t_min as well
    if sat.t_min > time_bound_secs:
        sat.t_min = time_bound_secs
        
def resolve_collisions(satellites, w_index, tree, step_secs):
    '''the passed-in satellite index may have overlaps in 4d space in the tree. Reduce time bounds
    in order to eliminate any overlaps

    satellites - the list of SatelliteData objects
    w_index    - the satellite index that we will eliminate overlaps for
    tree       - the AABB tree
    step_secs  - the computation time step delta

    returns an index of a satellite that collides with w at sat.t_min or None
    '''

    w = satellites[w_index]
    collision_list = tree.query_object(w_index)

    while collision_list:
        for v_index in collision_list:
            v = satellites[v_index]
            
            v_occ = v.occ_4d()
            w_occ = w.occ_4d()

            if has_intersection(v_occ, w_occ):
                steps_v = int(round((v.t_max - v.t_min) / step_secs))
                steps_w = int(round((w.t_max - w.t_min) / step_secs))

                if steps_v == 0 and steps_w == 0:
                    return v_index
                
                if v.t_min < w.t_min:
                    v.t_min = w.t_min
                    tree.update(v_index, v.occ_4d())
                elif steps_w < steps_v:
                    new_steps = int(math.floor(steps_v / 2))
                    v.t_max = v.t_min + new_steps * step_secs
                    tree.update(v_index, v.occ_4d())
                else:
                    new_steps = int(math.floor(steps_w / 2))
                    w.t_max = w.t_min + new_steps * step_secs
                    tree.update(w_index, w.occ_4d())

            collision_list = tree.query_object(w_index)

    return None
