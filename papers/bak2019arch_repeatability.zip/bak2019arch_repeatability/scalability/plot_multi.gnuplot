set terminal pdfcairo enhanced dashed font 'Verdana,20' fontscale 0.45 dl 0.4
set rmargin 4

set output "scalability_multi.pdf"

#set xrange [1:16]
set yrange [0.3:2000]

set grid ytics lc '#606060' lw 0.25 lt 1 dt 3
set grid xtics lc '#606060' lw 0.25 lt 1 dt 3

set boxwidth 0.5

set style fill solid

#set title "Partitioned 4D AABB Scalability" font 'Verdana,30'
set xlabel "Number of Objects (n)"
set ylabel "Computation Time (s)"

set logscale xy

set style line 1 lc rgb "#00bd60" lt 1 lw 3.5 pt 12 ps 0.8
set style line 2 lc rgb "#ff4040" lt 2 lw 3.0 pt 5 ps 0.6 dt 3
set style line 3 lc rgb "#8B008B" lt 6 lw 0.6 pt 3 ps 1.1

set pointintervalbox 0.7
set style line 4 lc "blue" lt 2 lw 2.0 pt 6 ps 0.7 dt 2 pi -1

#### horizontal lines
set style line 5 lc rgb "#808080" lt 2 lw 2.0 pt 13 ps 0.8 dt 2
set arrow from 100, 60 to 70000, 60 nohead ls 5
set label 21 "10x Real Time" at 120,60 font 'Verdana,20' tc rgb "#808080" offset 0, 0.5

set arrow from 100, 600 to 70000, 600 nohead ls 5
set label 22 "1x Real Time" at 120,600 font 'Verdana,20' tc rgb "#808080" offset 0, 0.5

#### vertical line
set style line 6 lc rgb "#ff9933" lt 2 lw 3.0 pt 13 ps 0.8 dt 5
set arrow from 16838, 4.5 to 16838, 2e3 nohead ls 6
set label 23 "Full Catalog" at 16838, 2e3 center font 'Verdana,20' tc "#ff9933" offset 0, 0.5

set key box at 60000,4.5

plot "multi_atom.dat" using 1:2 title "Embedded" with linespoints ls 1, \
     "multi_laptop.dat" using 1:2 title "Laptop" with linespoints ls 2, \
     "multi_workstation.dat" using 1:2 title "Workstation" with linespoints ls 4
