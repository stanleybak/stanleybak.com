'''
Combines the .dat files into a latex table
'''

def main():
    'main entry point'

    files = ["single_atom.dat", "single_laptop.dat", "single_workstation.dat",
             "multi_atom.dat", "multi_laptop.dat", "multi_workstation.dat"]
    f_list = []

    assert len(files) == 6

    with open(files[0], 'r') as f0:
        f_list.append(f0)

        with open(files[1], 'r') as f1:
            f_list.append(f1)

            with open(files[2], 'r') as f2:
                f_list.append(f2)

                with open(files[3], 'r') as f3:
                    f_list.append(f3)

                    with open(files[4], 'r') as f4:
                        f_list.append(f4)

                        with open(files[5], 'r') as f5:
                            f_list.append(f5)

                            write_table(f_list)

def write_table(f_list):
    'f_list is a list of open files to read from'

    sim_time = 600
    outpath = 'scalability_table.txt'
    
    with open(outpath, 'w') as outfile:

        while True:
            lines = [f.readline() for f in f_list]

            if not any(lines):
                break

            # write the number of objects
            for line in lines:
                if not line:
                    continue
                else:
                    print(line.split(' ')[0] + " ", end="")
                    outfile.write(line.split(' ')[0] + " ")
                    break

            # write the time for each method
            for line in lines:
                if line:
                    num = float(line.split(' ')[1])
                    rt_factor = sim_time / num

                    print(f"& {round(num, 1)} ({round(rt_factor, 1)}x) ", end="")
                    outfile.write(f"& {round(num, 1)} ")
                else:
                    print("& - ", end="")
                    outfile.write("& - ")

            print()
            outfile.write("\\\\\n")

if __name__ == "__main__":
    main()
