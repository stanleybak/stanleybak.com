set terminal pdfcairo enhanced dashed font 'Verdana,18' fontscale 0.45 dl 0.4

set output "scalability_single.pdf"

#set xrange [1:16]
set yrange [0.1:5000]

set grid ytics lc '#606060' lw 0.25 lt 1 dt 3
set grid xtics lc '#606060' lw 0.25 lt 1 dt 3

set boxwidth 0.5

set style fill solid

set title "4D AABB Method Scalability" font 'Verdana,30'
set xlabel "Number of Objects" font 'Verdana,24'
set ylabel "Computation Time (s)" font 'Verdana,24'

set logscale xy

set style line 1 lc rgb "#00bd60" lt 1 lw 3.5 pt 12 ps 0.8
set style line 2 lc rgb "#ff4040" lt 2 lw 3.0 pt 5 ps 0.6 dt 3
set style line 3 lc rgb "#8B008B" lt 6 lw 0.6 pt 3 ps 1.1

set pointintervalbox 0.7
set style line 4 lc "blue" lt 2 lw 2.0 pt 6 ps 1.0 dt 2 pi -1

#### horizontal lines
set style line 5 lc rgb "#808080" lt 2 lw 2.0 pt 13 ps 0.8 dt 2
set arrow from 100, 60 to 29617, 60 nohead ls 5
set label 21 "10x Real Time" at 120,60 font 'Verdana,16' tc rgb "#808080" offset 0, 0.5

set arrow from 100, 600 to 29617, 600 nohead ls 5
set label 22 "1x Real Time" at 120,600 font 'Verdana,16' tc rgb "#808080" offset 0, 0.5

#### vertical line
set style line 6 lc rgb "#008f00" lt 2 lw 3.0 pt 13 ps 0.8 dt 5
set arrow from 16840, 1.3 to 16840, 5000 nohead ls 6
set label 23 "Full Catalog" at 16840, 5000 center font 'Verdana,16' tc "#008f00" offset 0, 0.5

set key box at 25000,1.3 font ",16"

plot "single_atom.dat" using 1:2 title "Embedded" with linespoints ls 1, \
    "single_laptop.dat" using 1:2 title "Laptop" with linespoints ls 2, \
     "single_workstation.dat" using 1:2 title "Workstation" with linespoints ls 4
