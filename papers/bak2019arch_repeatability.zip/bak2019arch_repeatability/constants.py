'''
Stores common constant values used by a variety of different spacecraft propogation models.

Numbers for each model come from SGP4 Python Model Propagation File
https://github.com/brandon-rhodes/python-sgp4/blob/master/sgp4/propagation.py

Generic model numbers are from Bate, R., Mueller, D., White, J., "Fundamentals of Astrodynamics",
Dover Publications, Inc, 1971.

Model Options are:
- WGS72OLD
- WGS72
- WGS84
- (empty)

VARIABLES:
- earth_radius_km: radius of the earth in kilometers
- mu_km3s2: geocentric gravitational parameter for earth [km^3 / s^2]
- j2: 

Kerianne Hobbs
September 2018
'''

class Constants():
    'a class containing common constants used in orbital mechanics models'

    def __init__(self,modelversion):
        if modelversion == 'WGS72OLD':
            self.earth_radius_km = 6378.135        #  [km]
            self.mu_km3s2        = 398600.79964    #  [km3/s2]
            self.j2              =   0.001082616
            self.j3              =  -0.00000253881
            self.j4                =  -0.00000165597
            self.j3oj2           =  self.j3 / self.j2
        elif modelversion == 'WGS72': 
            self.earth_radius_km = 6378.135        #  [km]
            self.mu_km3s2        = 398600.8        #  [km3/s2]
            self.j2              =  0.001082616
            self.j3              =  -0.00000253881
            self.j4              =  -0.00000165597
            self.j3oj2           =  self.j3 / self.j2
        elif modelversion == 'WGS84': 
            self.earth_radius_km = 6378.137        #  [km]
            self.mu_km3s2        = 398600.5        #  [km3/s2]
            self.j2              =  0.00108262998905
            self.j3              = -0.00000253215306
            self.j4              = -0.00000253215306
            self.j3oj2           =  self.j3 / self.j2
        else:
            '''radius and gravitation parameter from "Fundamentals of Astrodynamics"
            perturbations from WGS84'''
            self.earth_radius_km = 6378.145        #  [km]
            self.mu_km3s2        = 398601.2        #  [km3/s2]
            self.j2              =  0.00108262998905
            self.j3              = -0.00000253215306
            self.j4              = -0.00000253215306
            self.j3oj2           =  self.j3 / self.j2
                
CONSTANTS = Constants('WGS84')
