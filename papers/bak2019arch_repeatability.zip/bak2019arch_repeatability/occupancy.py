'''
Stanley Bak
September 2018

Occupancy region computer based on simulations and interval arithmetic

Coplanar dynamics taken from the paper:
"Satellite Rendezvos and Collision Avoidance: Case Studies in Verification on Nonlinear Hybrid Systems" by
T. Johnson, J. Green, S. Mitra, R. Dudley, and R. S. Erwin, published in FM 2012

Coplanar dynamics confirmed, and out of plane dynamics derived from:
Wiesel, W. "Spaceflight Dynamics" Third Edition, Aphelion Press, 2010.
'''

import math

from scipy.integrate import RK45

import pyibex # interval arithmetic library

from constants import CONSTANTS
from util import Timers, Freezable

def init_occupancy(satellites, time_bound_secs, do_print=True):
    '''
    Initialize the occupancy region functions for all the satellites. 
    This runs simulations and prepares the interval arithmetic functions.

    satellites            - a list of SatelliteData objects
    time_bound_secs [sec] - the collision-checking time bound (used for simulation)
    '''

    Timers.tic("init_occupancy")

    for sat in satellites:
        sat.init_occupancy(time_bound_secs, do_print)

    Timers.toc("init_occupancy")

class OccupancyRegionComputer(Freezable):
    'object for computing the occupancy regions for a single satellite using simulation and interval arithmetic'

    def __init__(self, sat_data, time_bound_secs, do_print):
        '''
        sat_data              - the SatelliteData object
        time_bound_secs [sec] - the collision-checking time bound (used for simulation)
        '''

        self.do_print = do_print

        self.sat_data = sat_data
        self.time_bound_secs = time_bound_secs

        # p = semi-latus rectum [km]
        self.p = sat_data.a * (1 - sat_data.e**2) # semi-latus rectum computed with p = a(1-e^2) [km]
        self.sqrt_mu_over_p_cubed = math.sqrt(CONSTANTS.mu_km3s2 / self.p**3)

        self.cos_big_omega = math.cos(sat_data.big_omega)
        self.sin_big_omega = math.sin(sat_data.big_omega)

        self.cos_omega = math.cos(sat_data.omega)
        self.sin_omega = math.sin(sat_data.omega)

        self.sin_i = math.sin(sat_data.i)
        self.cos_i = math.cos(sat_data.i)

        self.xyz_pos_func = None # interval arithmetic position function
        
        self.dense_outputs = None # dense output list from the simulation
        self.last_dense_output_min_index = 0
        self.last_dense_output_max_index = 0

        self.make_interval_xyz_function()
        self.simulate()

        self.freeze_attrs()

    def nu_dot(self, _, nu):
        '''derivative function for the angular position nu

        nu [rad] - true anomoly

        returns: time derivative of nu
        '''

        # Equation from Kepler's law of equal areas: math.sqrt(mu / p**3) * (1 + e * math.cos(nu))**2
        return self.sqrt_mu_over_p_cubed * (1 + self.sat_data.e * math.cos(nu)) * (1 + self.sat_data.e * math.cos(nu))

    def make_interval_xyz_function(self):
        'make the interval function for evaluating xyz position'

        ##### construct interval function #####
        p, e = self.p, self.sat_data.e
        cos_big_omega = self.cos_big_omega
        sin_big_omega = self.sin_big_omega

        cos_omega = self.cos_omega
        sin_omega = self.sin_omega

        sin_i = self.sin_i
        cos_i = self.cos_i

        r = "{} / (1 + {} * cos(nu))".format(p, e)

        x_p = "{} * cos(nu)".format(r)
        y_q = "{} * sin(nu)".format(r)

        x_i_x = "{} * {}".format(x_p, (cos_big_omega*cos_omega-sin_big_omega*cos_i*sin_omega))
        x_i_y = "{} * {}".format(y_q, (-cos_big_omega*sin_omega-sin_big_omega*cos_i*cos_omega))
        x_i = "{} + {}".format(x_i_x, x_i_y)

        y_j_x = "{} * {}".format(x_p, (sin_big_omega*cos_omega+cos_big_omega*cos_i*sin_omega))
        y_j_y = "{} * {}".format(y_q, (-sin_big_omega*sin_omega+cos_big_omega*cos_i*cos_omega))
        y_j = "{} + {}".format(y_j_x, y_j_y)

        z_k_x = "{} * {}".format(x_p, sin_omega*sin_i)
        z_k_y = "{} * {}".format(y_q, cos_omega*sin_i)
        z_k = "{} + {}".format(z_k_x, z_k_y)

        self.xyz_pos_func = pyibex.Function("nu", "({}, {}, {})".format(x_i, y_j, z_k))
        
    def simulate(self):
        'simlate this satellite, storing the dense output'

        if self.sat_data.index > 0 and self.sat_data.index % 1000 == 0 and self.do_print: # print every 1000 satellites
            print("simulating sat #{}".format(self.sat_data.index))

        self.dense_outputs = [] #initialize as empty 

        # create the step-by-step integration object for the Runge Kutta 4-5 method
        # inputs: derivative function, initial time, initial nu, timebound, rtol(simulation relative tolerance param)
        rk45 = RK45(self.nu_dot, 0, [self.sat_data.nu], self.time_bound_secs, rtol=1e-6)

        while rk45.status == 'running': #simulation loop 
            rk45.step()

            self.dense_outputs.append(rk45.dense_output())

        assert abs(self.dense_outputs[-1].t_max - self.time_bound_secs) < 1e-6, \
          "last dense output max time != time_bound"

        # used later to speed up the collision checking in lookup_state to increase search speed
        self.last_dense_output_min_index = 0
        self.last_dense_output_max_index = 0

    def lookup_nu(self, time, is_min):
        ''' 
        get the nu values at the passed-in time

        - time [sec]: time you want to look up
        - is_min -  in time, are you looking at minimum or maximum time of the interval

        returns: the nu value at the requested time
        '''

        Timers.tic("lookup_nu")

        assert 0 <= time <= self.dense_outputs[-1].t_max

        # get the last index we used during a lookup for this bound
        index = self.last_dense_output_min_index if is_min else self.last_dense_output_max_index

        while time < self.dense_outputs[index].t_min: # if time is less than previous time, check previous time
            index -= 1

        while time > self.dense_outputs[index].t_max: # if time is greater than previous time, check next time
            index += 1

        # store the index to make the next lookup efficient
        if is_min:
            self.last_dense_output_min_index = index
        else:
            self.last_dense_output_max_index = index

        Timers.tic("interpolate")
        # calls interpolation function to get interpolated state value (nu) for a specific time
        rv = self.dense_outputs[index](time)[0] 
        Timers.toc("interpolate")

        Timers.toc("lookup_nu")
        
        return rv

    def get_pos(self, nu):
        'get the x, y, z position of the satellite, for the given nu'

        nu = float(nu)

        x_of, y_of = self.to_cartesian_of(nu)
        
        return self.to_cartesian_if(x_of, y_of)

    def get_box(self, nu_min, nu_max):
        '''get a 3D box containing the x, y, z position during the passed-in nu interval, 
        computed using interval arithmetic

        nu_min [rad] - the minimum true anomoly in the interval
        nu_max [rad] - the maximum true anomoly in the interval

        returns: a 3D box (list of 2-tuples)
        '''

        Timers.tic('get_box (interval arithmetic)')

        i = pyibex.Interval(nu_min, nu_max)

        result = self.xyz_pos_func.eval(i)

        # tolist() returns a flattened list
        result_list = result.tolist()
        
        r = self.sat_data.radius
        box = [[result_list[2*dim] - r, result_list[2*dim + 1] + r] for dim in range(3)]

        Timers.toc('get_box (interval arithmetic)')

        return box

    def to_cartesian_of(self, nu):
        'convert the angle nu to orbital frame pqw components x(p) and y(q)'

        p, e = self.p, self.sat_data.e

        r = p / (1 + e * math.cos(nu))

        x = r * math.cos(nu)
        y = r * math.sin(nu)

        return x, y

    def to_cartesian_if(self, x_p, y_q):
        'convert the from orbital frame pqw to inertial frame ijk with rotation matrix'

        cos_big_omega = self.cos_big_omega
        sin_big_omega = self.sin_big_omega

        cos_omega = self.cos_omega
        sin_omega = self.sin_omega

        sin_i = self.sin_i
        cos_i = self.cos_i

        # break into the orbital frame x and y contributions and add together for easier debugging
        x_i_x = x_p * (cos_big_omega*cos_omega-sin_big_omega*cos_i*sin_omega)
        x_i_y = y_q * (-cos_big_omega*sin_omega-sin_big_omega*cos_i*cos_omega)
        x_i = x_i_x + x_i_y

        y_j_x = x_p * (sin_big_omega*cos_omega+cos_big_omega*cos_i*sin_omega)
        y_j_y = y_q * (-sin_big_omega*sin_omega+cos_big_omega*cos_i*cos_omega)
        y_j = y_j_x + y_j_y

        z_k_x = x_p * sin_omega*sin_i
        z_k_y = y_q * cos_omega*sin_i
        z_k = z_k_x + z_k_y

        return x_i, y_j, z_k

    def occ(self, t_sec):
        '''returns the 3D occupancy region box at the requested time. 

        t_sec [sec] - the time requested for the occupancy box

        returns: a list of lists corresponding to the 3D box occupied at t_sec        
        '''

        nu = self.lookup_nu(t_sec, True)

        pos = self.get_pos(nu)

        box = []

        for x in pos:
            box.append([x - self.sat_data.radius, x + self.sat_data.radius])

        return box

    def occ_4d(self):
        '''returns the occupancy region box between this satellite's t_min and t_max. 

        returns: a list of lists corresponding to the 4D box occupied at times [t_min, t_max]
        '''

        Timers.tic("occ_4d")

        t_min = self.sat_data.t_min
        t_max = self.sat_data.t_max

        assert t_min is not None and t_max is not None, "t_min and t_max need to be assigned before calling occ_4d"

        nu_min = self.lookup_nu(t_min, True)
        nu_max = self.lookup_nu(t_max, False)

        box = self.get_box(nu_min, nu_max) # returns 3d box

        # add the time dimension to get a 4d box
        box.append([t_min, t_max])

        Timers.toc("occ_4d")

        return box
