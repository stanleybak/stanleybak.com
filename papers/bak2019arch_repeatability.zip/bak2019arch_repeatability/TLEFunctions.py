from sgp4.io import twoline2rv
from sgp4.earth_gravity import wgs72, wgs84
from sgp4.ext import days2mdhms, jday
from numpy import sin, cos, pi #abs, amax, arange, matrix
from math import tan, atan, atan2

from timerutil import Timers
import math

#import math
#from numpy import deg2rad
import numpy as np
#import csv
#import sys

from mpl_toolkits.mplot3d import Axes3D
import matplotlib.animation as animation
import matplotlib.pyplot as plt

from kepler import kepler_propogator

#from scipy.integrate import RK45

#import pyibex # interval arithmetic library
############ Constants ############
# geocentric gravitational parameter for earth [km^3 / s^2]
mu = 398600.5 #WGS 84
earth_radius = 6378.137 #WGS 84
rad2deg = 180.0/pi

def TLEtoRV(filename, YY, M, DD, HH, MM, SS):
    'for a text file containin 3 line TLEs, outputs Position and Velocity at a given time'
    # Initialize r, v vectors, 1st and second line of TLEs
    r_array = []
    v_array = []
    line1s = []
    line2s = []

    tle =open(filename,'r')	
    lines = [line.split('\n') for line in tle.readlines()]
    num_sat = len(lines)/3

    for x in xrange(num_sat):
        line1s.append((lines[3*x+1])[0])
        line2s.append((lines[3*x+2])[0])
        satellite=twoline2rv(line1s[x],line2s[x],wgs84)

        r, v = satellite.propagate(YY, M, DD, HH, MM, SS) #position=r (km), velocity=v(km/s). Date is year, month, day, hour(24hr), minute, second)
        r_array.append(r)
        v_array.append(v)
        
    return r, v

def TLEEpochReader(filename):
    'for a text file containin 3 line TLEs, outputs orbital elements'
    # Initialize   
    line1s = []
    line2s = []
    epochyr = []
    epochdays = []
    satnum = []
    years = []
    months = []
    days = []
    hours = []
    minutes = []
    seconds = []
    

    # Open the TLE File, assuming it is a text file in standard format
    tle = open(filename,'r')

    # Go line by line in the TLE
    lines = [line.split('\n') for line in tle.readlines()]
    num_sat = len(lines)/3
    x = 0
    while x < num_sat:
        line1s.append((lines[3*x+1])[0])
        line2s.append((lines[3*x+2])[0])
        satnum.append(x + 1)
        satellite=twoline2rv(line1s[x],line2s[x],wgs72) 
        epochyr = satellite.epochyr #satrec.epoch = datetime(year, mon, day, hr, minute, int(sec_whole), int(sec_fraction * 1000000.0 // 1.0))
        epochdays = satellite.epochdays
        mon,day,hr,minute,sec = days2mdhms(epochyr, epochdays)
        #sec_whole, sec_fraction = divmod(sec, 1.0) #satrec.epoch = datetime(year, mon, day, hr, minute, int(sec_whole), int(sec_fraction * 1000000.0 // 1.0))
        years.append(epochyr)
        months.append(mon)
        days.append(day)
        hours.append(hr)
        minutes.append(minute)
        seconds.append(sec)
        x = x+1
        
    return years,months,days,hours,minutes,seconds

def TLEtoOrbitalElements(filename):
    'for a text file containin 3 line TLEs, outputs orbital elements'
    '# units: i [degrees], e [-], nu [rad], omega [degrees], Omega [degrees], a [km]'

    # Initialize   
    line1s = []
    line2s = []
    i = []
    e = []
    n = []
    omega = []
    M = []
    Omega = []
    a= []
    Es = []
    nu = []
    satnum = []

    #variables for iterative solution of Eccentric Anomaly
    maxiter = 30
    int = 0
    delta = 0.0000001
  
    # Open the TLE File, assuming it is a text file in standard format
    tle = open(filename,'r')

    # Go line by line in the TLE
    lines = [line.split('\n') for line in tle.readlines()]
    num_sat = len(lines)/3
    x = 0
    while x < num_sat:
        line1s.append((lines[3*x+1])[0])
        line2s.append((lines[3*x+2])[0])
        satnum.append(x + 1)
        satellite=twoline2rv(line1s[x],line2s[x],wgs84) 
        i.append(satellite.inclo * rad2deg) # [degrees] inclination TLE: Degrees, SGP4: Radians
        e.append(satellite.ecco)  #[unitless] eccentricity
        n.append(satellite.no/60) #[rad/s] mean motion; TLE: [(rev/day)*(day/hr)*(hr/x) = rev/s] SGP4: [(rad/min)]
        omega.append(satellite.argpo * rad2deg) # [degrees] argument of perigee TLE: Degrees, SGP4: Radians
        M.append(satellite.mo * rad2deg) # [degrees] mean anomoly TLE: Degrees, SGP4: Radians
        Omega.append(satellite.nodeo* rad2deg) # [degrees] RAAN TLE: Degrees, SGP4: Radians
        a.append(satellite.a*earth_radius) #[km] SGP4 uses a as fractions of earth radius 
        #calculate semi major axis from mean motion a = cuberoot(mu/n^2)
        #a.append((mu/(n[x]**2))**(1./3))
        x = x+1

        #calculate true anomaly
        if satellite.ecco < 0.8:
            E = satellite.mo 
        else:
            E = pi
        F = E - satellite.ecco*sin(E) - satellite.mo
        Fprime = 1.0 - satellite.ecco*cos(E)
        while abs(F)>delta and (int<maxiter):
            E = E-F/Fprime
            F = E - satellite.ecco*sin(E) - satellite.mo
            Fprime = 1.0 - satellite.ecco*cos(E)
            int = int+1
        Es.append(E)
        tanhalfnu = ((1+satellite.ecco)/(1-satellite.ecco))**(1.0/2.0)*tan(0.5*E)
        nus = 2*atan(tanhalfnu)
        if nus < 0: nu.append(2*pi + nus)
        else: nu.append(nus)
    return a, e, nu, i, Omega, omega

def orbitFilter(a_array, e_array, nu_array, i_array, Omega_array, omega_array):
    eccentric = []
    leo_sats = []
    meoa_sats = []
    meob_sats = []
    geo_sats = []
    geoplus_sats = []
    #earth_radius = 6378.137 #[km] WGS 84
    x = 0
    while x < len(a_array):
        if e_array[x] > 0.1:
            eccentric.append(x)
        elif a_array[x] <= (2000 +earth_radius):
            leo_sats.append(x)
        elif 2000+earth_radius <a_array[x] <=20000:
            meoa_sats.append(x)
        elif 20000 < a_array[x] <=35000+earth_radius:
            meob_sats.append(x)
        elif 35000+earth_radius < a_array[x] < 37000+earth_radius:
            geo_sats.append(x)
        else:
            geoplus_sats.append(x)
        x = x+1
    return eccentric, leo_sats, meoa_sats, meob_sats, geo_sats, geoplus_sats

def plotOrbitalElements(a_array, e_array, nu_array, i_array, Omega_array, omega_array):
    ## Initialize
    fig = figure(1)
    satnum = []
    x = 0
    while x < len(nu_array):
        satnum.append(x + 1)
        x = x+1

    # Plot
    plot1 = fig.add_subplot(321)#2 row, 1 column, 1st plot
    aplot = plot1.plot(satnum, a_array,'b.',markersize = 2)
    plot1.set_xlabel('Satellite Number')
    plot1.set_ylabel('Semi Major Axis [km]')

    plot2 = fig.add_subplot(322)#2 row, 1 column, 2nd plot
    eplot = plot2.plot(satnum, e_array,'b.',markersize = 2)
    plot2.set_xlabel('Satellite Number')
    plot2.set_ylabel('Eccentricity ')

    plot3 = fig.add_subplot(323)#2 row, 1 column, 3rd plot
    iplot = plot3.plot(satnum, i_array,'b.',markersize = 2)
    plot3.set_xlabel('Satellite Number')
    plot3.set_ylabel('Inclination [degrees]')

    plot4 = fig.add_subplot(324)#2 row, 1 column, 3rd plot
    Omegaplot = plot4.plot(satnum, Omega_array,'b.',markersize = 2)
    plot4.set_xlabel('Satellite Number')
    plot4.set_ylabel('RAAN [degrees]')

    plot5 = fig.add_subplot(325)#2 row, 1 column, 3rd plot
    omegaplot = plot5.plot(satnum, omega_array,'b.',markersize = 2)
    plot5.set_xlabel('Satellite Number')
    plot5.set_ylabel('Argument of Perigee [degrees]')

    plot6 = fig.add_subplot(326)#2 row, 1 column, 3rd plot
    nuplot = plot6.plot(satnum, nu_array,'b.',markersize = 2)
    plot6.set_xlabel('Satellite Number')
    plot6.set_ylabel('True Anamoly [degrees]')

    show()

####################################################################

def do_plot(times, states, p_list, e_list, i_list, Omega_list, omega_list):
    '''animate the output

    This will do a 3d plot in anticipation of having that eventually... but z will be 0 for all objects
    '''

    num_sat = len(states[0])
    blit = True # blit = True animates faster, but you can't zoom around

    fig = plt.figure(figsize=(6, 5))
    ax = fig.add_subplot(111, projection='3d')
    ax.view_init(37, 73)

    trail_lines = []
    satellites = []
    cartesian_positions = []
    min_pos = 1e9
    max_pos = -1e9

    colors = ['r', 'm', 'c']

    for n in xrange(num_sat):
        line, = ax.plot([], [], [], color=colors[n % len(colors)], lw=1, animated=blit)
        trail_lines.append(line)

        line, = ax.plot([], [], [], color=colors[n % len(colors)], marker='o', ms=8, animated=blit)
        satellites.append(line)

        # compute the x,y positions for each satelite
        nu_list = [state[n] for state in states]

        xs = []
        ys = []
        zs = []

        for nu in nu_list:
            x_of, y_of = to_cartesian_of(nu, p_list[n], e_list[n])
            x_if, y_if, z_if = to_cartesian_if(x_of,y_of,i_list[n],Omega_list[n],omega_list[n])

            min_pos = min(x_if, min_pos)
            min_pos = min(y_if, min_pos)
            min_pos = min(z_if, min_pos)

            max_pos = max(x_if, max_pos)
            max_pos = max(y_if, max_pos)
            max_pos = max(z_if, max_pos)
			
            xs.append(x_if)
            ys.append(y_if)
            zs.append(z_if)
			

        cartesian_positions.append([xs, ys, zs])

    # set axis limits
    ax.set_xlim([min_pos, max_pos])
    ax.set_ylim([min_pos, max_pos])
    ax.set_zlim([min_pos, max_pos])

    # draw sphere (earth)
    rad = 6378.137
    u, v = np.mgrid[0:2*np.pi:40j, 0:np.pi:20j]
    x = rad * np.cos(u)*np.sin(v)
    y = rad * np.sin(u)*np.sin(v)
    z = rad * np.cos(v)
    ax.plot_wireframe(x, y, z, color="b", alpha=0.2, lw=0.5)

    # animated text
    fontsize = 14
    time_text = ax.text2D(0.2, .92, "", transform=ax.transAxes, fontsize=fontsize, animated=blit)
    nu1_text = ax.text2D(0.2, .87, "", transform=ax.transAxes, fontsize=fontsize, animated=blit)
    nu2_text = ax.text2D(0.2, .82, "", transform=ax.transAxes, fontsize=fontsize, animated=blit)
    nu3_text = ax.text2D(0.2, .77, "", transform=ax.transAxes, fontsize=fontsize, animated=blit)

    def anim_func(frame):
        'update the animation objects for the current frame'

        time_text.set_text('t = {:.2f} sec'.format(times[frame]))
        nu1_text.set_text('$\\nu_1$ = {:.2f}'.format(states[frame][0]))
        nu2_text.set_text('$\\nu_2$ = {:.2f}'.format(states[frame][1]))
        nu3_text.set_text('$\\nu_3$ = {:.2f}'.format(states[frame][2]))

        # update the trails up to the current frame
        for n in xrange(num_sat):
            xs, ys, zs = cartesian_positions[n]

            

            trail_lines[n].set_data(xs[:frame+1], ys[:frame+1])
            trail_lines[n].set_3d_properties(zs[:frame+1])

            satellites[n].set_data(xs[frame:frame+1], ys[frame:frame+1])
            satellites[n].set_3d_properties(zs[frame:frame+1])

        #return [time_text, nu1_text, nu2_text, nu3_text] + trail_lines #+ satellites
        return [time_text] + trail_lines #What is plotted

    num_frames = len(times) - 1


    anim_obj = animation.FuncAnimation(fig, anim_func, num_frames, interval=20, blit=blit, repeat=True)
    plt.show()

def plot_orbits(plot_3d):
    'produce a 2d or 3d plot of the orbits for sgp4 and kepler'

    filename = 'TLETestCase.txt'

    # Find Time that the TLE is taken from 
    # Note that each TLE may have a different epoch based on when it was last observed
    YYYY0,M0,D0,HH0,MM0,SS0= TLEEpochReader(filename)

    sat_num = 0 # satellite number you are grabbing values for
    YY = YYYY0[sat_num] 	# 4 digit year
    M = M0[sat_num]		# month
    DD = D0[sat_num] + 0 	# day
    HH = HH0[sat_num]     # hour (24 hour clock)
    MM = MM0[sat_num]    # minute
    SS = SS0[sat_num]     # second

    a_array, e_array, nu_array, i_array, Omega_array, omega_array = TLEtoOrbitalElements(filename)


    ################### init plotting
    fig = plt.figure(figsize=(6, 5))

    if plot_3d:
        ax = fig.add_subplot(111, projection='3d')
        ax.view_init(37, 73)
    else:
        ax = fig.add_subplot(111)

    # set axis limits
    max_pos = 8000
    min_pos = -max_pos

    # plot_3d doesn't zoom / pan, so we'll set it later
    if not plot_3d:
        ax.set_xlim([min_pos, max_pos])
        ax.set_ylim([min_pos, max_pos])

    # draw sphere (earth)
    rad = 6378.137
    u, v = np.mgrid[0:2*np.pi:40j, 0:np.pi:20j]
    x = rad * np.cos(u)*np.sin(v)
    y = rad * np.sin(u)*np.sin(v)

    if plot_3d:
        z = rad * np.cos(v)
        ax.plot_wireframe(x, y, z, color="b", alpha=0.2, lw=0.5)
    else:
        ax.plot(x, y, color="b", alpha=0.2, lw=0.5)

    sgp4_xs = []
    sgp4_ys = []
    sgp4_zs = []

    kepler_xs = []
    kepler_ys = []
    kepler_zs = []

    # 24 / 15.55740938000000 * 60 = 92.5603977389
    for frac in range(1001): # point every 0.1% seconds
        sec = frac * 60 * 92.5603977389 / 1000.0
        
        r_array, _ = TLEtoRV(filename, YY, M, DD, HH, MM, SS + sec)
        sgp4_xs.append(r_array[0])
        sgp4_ys.append(r_array[1])
        sgp4_zs.append(r_array[2])

        pos = kepler_propogator(a_array, e_array, nu_array, i_array, Omega_array, omega_array, sec)

        kepler_xs.append(pos[0][0])
        kepler_ys.append(pos[0][1])
        kepler_zs.append(pos[0][2])

        print "sec {}: sgp4 = {}, kepler = {}".format(sec, r_array, pos[0])

        if frac == 0:
            if plot_3d:
                ax.text(r_array[0], r_array[1], r_array[2], 'Start SGP4', None, color='r')
                ax.text(pos[0][0], pos[0][1], pos[0][2], 'Start Kepler', None, color='b')

                rad = 20
                ax.set_xlim([r_array[0] - rad, r_array[0] + rad])
                ax.set_ylim([r_array[1] - rad, r_array[1] + rad])
                ax.set_zlim([r_array[2] - rad, r_array[2] + rad])
            else:
                ax.annotate('Start SGP4', xy=(r_array[0], r_array[1]), xytext=(r_array[0] + 50, r_array[1] + 20), color='r', arrowprops=dict(fc='r', ec='r', lw=2))
                ax.annotate('Start Kepler', xy=(pos[0][0], pos[0][1]), xytext=(r_array[0] + 50, r_array[1] - 20), color='b', arrowprops=dict(fc='b', ec='b'))
            
            #ax.text(r_array[0], r_array[1], 'Start', fontsize=15, color='r')
            #ax.text(pos[0][0], pos[0][1], 'Start', fontsize=15, color='b')
        elif frac == 1000:
            if plot_3d:
                ax.text(r_array[0], r_array[1], r_array[2], 'End SGP4', None, color='r')
                ax.text(pos[0][0], pos[0][1], pos[0][2], 'End Kepler', None, color='b')
            else:
                ax.annotate('End SGP4', xy=(r_array[0], r_array[1]), xytext=(r_array[0] - 50, r_array[1] + 20), color='r', arrowprops=dict(fc='r', ec='r', lw=1))
                ax.annotate('End Kepler', xy=(pos[0][0], pos[0][1]), xytext=(r_array[0] - 50, r_array[1] - 20), color='b', arrowprops=dict(fc='b', ec='b'))
            
            #ax.text(r_array[0], r_array[1], 'End', fontsize=15, color='r')
            #ax.text(pos[0][0], pos[0][1], 'End', fontsize=15, color='b')

    if plot_3d:
        ax.plot(sgp4_xs, sgp4_ys, 'r-o', zs=sgp4_zs)
        ax.plot(kepler_xs, kepler_ys, 'b-o', zs=kepler_zs)
    else:
        ax.plot(sgp4_xs, sgp4_ys, 'r-o')
        ax.plot(kepler_xs, kepler_ys, 'b-o')

    # plot kepler# Find 6 orbital elements from the TLE file
     

    plt.show()
