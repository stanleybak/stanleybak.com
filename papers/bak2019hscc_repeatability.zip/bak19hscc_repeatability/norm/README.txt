matrix norm computation for 100x100x100 heat 3d system (mentioned below equation 3 in the paper)

a priori bound is:

2 ||v|| (||At||^a e^||At||) / a!

where a is the number of arnoldi iterations, v is the initial vector

The norm computed by the heat_norm.py script is 32771611.0936

with ||v|| = 1, and a = 1000000 this makes the expression:

2 * (32771611.0936^1000000 * e^32771611.0936) / 1000000!

This easily overflows simple calculators, so you something like http://www.wolframalpha.com to evalute it.
