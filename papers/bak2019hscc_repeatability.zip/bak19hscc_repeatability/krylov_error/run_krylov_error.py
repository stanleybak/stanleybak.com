'''
Krylov error computation using 100x100x100 3d Heat Plot
'''

import time
import os
import sys

from heat3d_sym_error import run_hylaa

def main():
    'main entry point'

    stdout = False # print tool stdout as it runs?
    start = time.time()
    size = 100
    use_arnoldi = False

    result = None

    print "\nRunning 100x100x100 Krylov error analysis..."
    sys.stdout.flush()

    try:
        result = run_hylaa(size, stdout, use_arnoldi)

        runtime = result.top_level_timer.total_secs

        runtime_str = runtime_string(runtime)

        print "Hylaa Runtime: {}".format(runtime_str)

    except MemoryError as e:
        print "MemoryError during measurement: {}".format(e)

    diff = time.time() - start
    print "\n\nTotal runtime: {:.2f} min".format(diff / 60.0)

def runtime_string(secs):
    'convert a float of seconds into a string for the table'

    rv = ""

    if secs < 60:
        rv = "{:.1f}s".format(secs)
    elif secs < 60 * 60:
        mins = secs / 60.0
        rv = "{}m{}s".format(int(mins), int(secs) % 60)
    else:
        mins = secs / 60.0
        hours = mins / 60.0
        rv = "{}h{}m".format(int(hours), int(mins) % 60)
        
    return rv

def get_max_temp(poly_data):
    'get the maximum temperature (y axis) from a poly_data object in the computation result'

    max_y = -9999

    # data
    for _, data in poly_data.iteritems():
        _, _, polys = data

        #[-3, 0; -3, 1; -4, 1; -3.5 0.5;-4, 0]
        for poly in polys:
            for pt in poly:
                max_y = max(max_y, pt[1])

    return max_y

if __name__ == '__main__':
    main()
