'''
Krylov error computation test
'''

import numpy as np
import math

from scipy.linalg import expm

def main():
    'main code'

    time_bound = 20.0
    h_mat = np.load('h_mat.npy')
    pv_mat = np.load('pv_mat.npy')

    last_error = None

    for dims in range(10, h_mat.shape[0], 5):
        small_h = h_mat[:dims, :dims] * time_bound * (-1) # unclear: h_mat was negative because -A used in lanczos
        small_pv = pv_mat[:, :dims]

        e0 = np.array([[1.0 if d == 0 else 0 for d in range(dims)]], dtype=float).transpose()

        mat_exp = expm(small_h)
        
        res = np.dot(small_pv, mat_exp[:, 0])[0]

        if last_error is not None:
            # compute relative error
            rel_error, abs_error = compute_rel_error(res, last_error)

            print "{} {} {}".format(dims, rel_error, abs_error)

        last_error = res

def compute_rel_error(correct, estimate):
    'compute the relative error between the correct value and an estimate'

    rel_error = 1.0e16 # large error is returned if it can't be computed due to numerical issues
    abs_error = 0

    try:
        norm = np.linalg.norm(correct)

        if not math.isinf(norm) and not math.isnan(norm):
            if norm < 1e-13: # if norm is small, return absolute error
                rel_error = norm
            else:
                diff = correct - estimate

                abs_error = np.linalg.norm(diff)

                if not math.isinf(abs_error) and not math.isnan(abs_error):
                    rel_error = abs_error / norm
    except FloatingPointError:
        pass

    assert not math.isinf(rel_error) and not math.isnan(rel_error)

    return rel_error, abs_error

if __name__ == '__main__':
    main()
