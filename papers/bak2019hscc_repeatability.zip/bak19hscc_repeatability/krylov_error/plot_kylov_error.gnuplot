set terminal pdfcairo enhanced dashed font 'Verdana,20' fontscale 0.45 dl 0.4

# buffer is 220 on left, 80 on right, 230 total
#set lmargin at screen 220.0/1100
#set rmargin at screen 1020.0/1100

set yrange [5e-9:10]
set xrange [0:570]

set title 'Krylov Error' font 'Verdana,38' offset 0,-1
set xlabel "Number of Arnoldi Iterations (k)"
set ylabel "Error"

set output "krylov_error.pdf"
set style fill solid 1.0 noborder
#unset border
#unset xtics
#unset ytics

set logscale y 
set format y "10^{%T}"

set key top right

set style line 1 lc rgb '#0060ad' lt 1 lw 2 pt 7 ps 0.5
set pointintervalbox 0.6

set style line 5 lc rgb "#808080" lt 2 lw 2.0 pt 13 ps 0.8 dt 2
set arrow from 0, 1e-6 to 569, 1e-6 nohead ls 5
set label 21 "Error Target" at 95,1e-6 font 'Verdana,20' tc rgb "#808080" offset 0, -0.4

plot "bound_full.dat" with lines ls 1 notitle, \
    1/0 with linespoints ls 1 title 'Lemma 4.1 Bound', \
    "bound_sampled.dat" with points ls 1 notitle, \
     "rel_error.dat" with lines ls 2 title 'Relative Error'
