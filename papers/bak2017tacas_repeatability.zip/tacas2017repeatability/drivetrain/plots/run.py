'''Script for generating drivetrain benchmark and running with pysim'''

import os

# make sure hybridpy is on your PYTHONPATH: hyst/src/hybridpy
import hybridpy.hypy as hypy

def main():
    '''main entry point'''

    theta = 1

    gen_drivetrain_pysim(theta)
    gen_drivetrain_hylaa(theta)   

def get_script_path(filename=__file__):
    '''get the path this script'''
    return os.path.dirname(os.path.realpath(filename))
 
def gen_drivetrain_pysim(theta):
    'generate a drivetrain benchmark instance and plot a simulation'

    title = "Drivetrain (Theta={})".format(theta)
    image_path = "pysim_drivetrain_theta{}.png".format(theta)
    output_path = "pysim_drivetrain{}.py".format(theta)
    gen_param = '-theta {} -init_points 10'.format(theta)

    tool_param = "-title \"{}\" -xdim 0 -ydim 2".format(title)

    e = hypy.Engine('pysim', tool_param)
    e.set_generator('drivetrain', gen_param)
    #e.set_output(output_path)
    #e.set_verbose(True)
    
    #e.add_pass("sub_constants", "")
    #e.add_pass("simplify", "-p")
    
    print 'Running ' + title
    res = e.run(print_stdout=True, image_path=image_path)
    print 'Finished ' + title

    if res['code'] != hypy.Engine.SUCCESS:
        raise RuntimeError('Error in ' + title + ': ' + str(res['code']))

def gen_drivetrain_hylaa(theta):
    'generate a drivetrain benchmark instance for hylaa'

    labels = ['unaggregated', 'deaggregated']
    extra_settings = ['settings.aggregation=False settings.deaggregation=False', 'settings.aggregation=True settings.deaggregation=True']

    assert len(labels) == len(extra_settings)

    for i in xrange(len(labels)):
        title = "Drivetrain {} (Theta={})".format(labels[i], theta)
        gen_param = '-theta {}'.format(theta) # -error_guard x3>=85&x1<=0.11

        tool_param = '-python_simplify -xdim x1 -ydim x3 -step 5e-3'

        image_path = "{}/drivetrain_{}.png".format(get_script_path(), labels[i])
        tool_param += ' -settings settings.plot.plot_mode=PlotSettings.PLOT_IMAGE settings.plot.filename=\'{}\''.format(image_path)
        tool_param += ' settings.plot.extend_plot_range_ratio=0.2 settings.plot.max_shown_polys=0'
        tool_param += ' ' + extra_settings[i]
    
        e = hypy.Engine('hylaa', tool_param)
        e.set_generator('drivetrain', gen_param)
        #e.set_output('hylaa_drivetrain{}.py'.format(theta))
    
        print 'Running ' + title
        res = e.run(print_stdout=True)
        print 'Finished ' + title

        if res['code'] != hypy.Engine.SUCCESS:
            raise RuntimeError('Error in ' + title + ': ' + str(res['code']))

if __name__ == '__main__':
    main()


