'''Script for generating drivetrain benchmark and running with pysim'''

import subprocess
import time
import hybridpy.hypy as hypy

def main():
    '''main entry point'''

    step = 5e-4
    thetas = [1, 2, 3, 4, 5, 6, 7, 8]
    files = []
    labels = []
    start = time.time()

    for unaggregated in [False, True]:
        tag = "unaggregated" if unaggregated else "deaggregated"
        labels.append(tag.capitalize())
        filename = 'out/data_{}.dat'.format(tag)
        files.append(filename)

        with open(filename, "w") as f:

            for theta in thetas:
                runtime = run_drivetrain_hylaa(theta, step, unaggregated)
                print "Recorded Tool Runtime as {:.2f}\n".format(runtime)

                dims = 8 + 2 * theta
                f.write('{} {}\n'.format(dims, runtime))

    diff = time.time() - start
    print "Total Measurement Time: {:.2f}".format(diff)

    print "Making plot..."
    make_plot('powertrain', 'Powertrain Scalability', files, labels)


def run_drivetrain_hylaa(theta, step, unaggregated):
    ''''run the drivetrain benchmark instance for hylaa
    returns the runtime
    '''

    title = "Drivetrain (Theta={})".format(theta)

    # use a switch time so that the transition occurs right at a single time instant
    switch_time = 0.2 - 1e-6
    gen_param = '-theta {} -switch_time {}'.format(theta, switch_time)
    tool_param = '-python_simplify -step {}'.format(step)

    if unaggregated:
        tool_param += " -settings settings.aggregation=False settings.deaggregation=False"
    else:
        tool_param += " -settings settings.aggregation=True settings.deaggregation=True"

    e = hypy.Engine('hylaa', tool_param)
    e.set_generator('drivetrain', gen_param)
    output_filename = "models/drivetrain{}_{}.py".format(theta, "unag" if unaggregated else "deag")
    #e.set_output(output_filename)

    print 'Running ' + title
    res = e.run(print_stdout=True)
    print 'Finished ' + title

    if res['code'] != hypy.Engine.SUCCESS:
        raise RuntimeError('Error in ' + title + ': ' + str(res['code']))

    return res['tool_time']

def make_plot(name, title, data_files, file_labels):
    'use gnuplot to plot the results'

    gnuplot_filename = 'out/make_{}.gnuplot'.format(name)
    eps_filename = "{}.eps".format(name)

    with open(gnuplot_filename, "w") as f:
        f.write('set terminal postscript eps enhanced color\n')
        f.write('set output "{}"\n'.format(eps_filename))
        f.write('set autoscale\n')

        f.write('unset label\n')
        f.write('set xtic auto\n')
        f.write('set ytic auto\n')
        f.write('set xlabel "Dimensions"\n')
        f.write('set ylabel "Seconds"\n')
        f.write('set size ratio 0.7\n\n')

        f.write('set style line 1 lc rgb "#00bd60" lt 6 lw 4 pt 6 pi -1 ps 1.5\n')
        f.write('set style line 2 lc rgb "#ef8d00" lt 8 lw 2 pt 3 pi -1 ps 1.5\n')
        f.write('set style line 3 lc rgb "#ff4040" lt 2 lw 3 pt 9 pi -1 ps 1.75\n')
        f.write('set style line 4 lc rgb "#0060ad" lt 1 lw 2 pt 7 pi -1 ps 1.5\n')

        f.write('set pointintervalbox 2\n')
        f.write('set key left top\n')
        f.write('set title "{} Scalability"\n'.format(title))

        line = None

        for i in xrange(len(data_files)):
            filename = data_files[i]
            label = file_labels[i]

            if line is not None:
                line += ", "
            else:
                line = ""

            line += '"{}" with linespoints title "{}" ls {}'.format(filename, label, i+1)

        f.write('plot {}'.format(line))

        f.write('\n\n')

    print "created {}... running gnuplot on it".format(gnuplot_filename)

    try:
        exit_code = subprocess.call(["gnuplot", gnuplot_filename])

        if exit_code != 0:
            raise RuntimeError("Gnuplot errored; exit code: " + str(exit_code))

    except OSError as e:
        raise RuntimeError("Exception while trying to run gnuplot: " + str(e))

    print "Created {}".format(eps_filename)


if __name__ == '__main__':
    main()

