'''
Stanley Bak
September 2016

Make helicopter plots
'''

import time
import os

from hybridpy import hypy

def main():
    'main function'

    run('trim')

def get_script_path(filename=__file__):
    '''get the path this script'''
    return os.path.dirname(os.path.realpath(filename))

def run(name):
    'main execution function'

    tools = ['spaceex', 'flowstar', 'hylaa']
    outputs = ['out_spaceex.xml', 'out_flowstar.model', 'out_hylaa.py']

    # tools.append('flowstar')
    # labels.append('Flowstar')
    # tool_params.append('-order 3-3')

    start = time.time()
    
    for i in xrange(len(tools)):
        tool_name = tools[i]
        params = ''
        

        image_path = "{}/{}_{}.png".format(get_script_path(), name, tool_name)

	if tool_name == 'hylaa':
	    params = '-settings settings.plot.plot_mode=PlotSettings.PLOT_IMAGE settings.plot.filename=\'{}\''.format(image_path)
            image_path = None

        e = hypy.Engine(tool_name, params)

        e.set_output(outputs[i])
        e.set_input('{}.xml'.format(name))

        res = e.run(print_stdout=True, run_tool=True, image_path=image_path)

        if res['code'] != hypy.Engine.SUCCESS:
            raise RuntimeError("Hypy Failed on {}: {}".format(
                tool_name, res['code']))

    dif = time.time() - start
    print "Plots Completed in {:2f} seconds".format(dif)

if __name__ == "__main__":
    main()










