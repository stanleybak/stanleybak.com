'''
Created by Hyst v1.3
Hybrid Automaton in Hylaa
Converted from file: trim.xml
Command Line arguments: -i trim.xml -o out_hylaa.py -tool hylaa ""
'''

import numpy as np
from hylaa.hybrid_automaton import LinearHybridAutomaton, LinearConstraint, HyperRectangle
from hylaa.engine import HylaaSettings
from hylaa.engine import HylaaEngine
from hylaa.plotutil import PlotSettings

def define_ha():
    '''make the hybrid automaton and return it'''

    ha = LinearHybridAutomaton()
    ha.variables = ["x", "y"]


    running = ha.new_mode('running')
    running.a_matrix = np.array([[0, 1], [-1, 0]])
    running.b_vector = np.array([0, 0])
    #running.inv_list.append(LinearConstraint([-0, -1], -0)) # y >= 0
    running.inv_list.append(LinearConstraint([0, 1], 5.1)) # y <= 5.1

    return ha

def define_init_states(ha):
    '''returns a list of (mode, HyperRectangle)'''
    # Variable ordering: [x, y]
    rv = []

    r = HyperRectangle([(-6, -5), (0, 1.0)])
    rv.append((ha.modes['running'], r))

    return rv


def define_settings():
    'get the hylaa settings object'
    plot_settings = PlotSettings()
    plot_settings.plot_mode = PlotSettings.PLOT_NONE
    plot_settings.xdim = 0
    plot_settings.ydim = 1
    
    # Without trim_redundant_inv_constraints / with it
    # step 0.05: 16 / 5
    # step 0.005: 119 / 9
    # step 0.001: 576 / 25
    # step 0.0005  1148 / 45

    settings = HylaaSettings(step=0.01, max_time=3.0, plot_settings=plot_settings)
    settings.trim_redundant_inv_constraints = False
    
    return settings

def run_hylaa(settings):
    'Runs hylaa with the given settings, returning the HylaaResult object.'
    ha = define_ha()
    init = define_init_states(ha)

    engine = HylaaEngine(ha, settings)
    engine.run(init)

    return engine.result

if __name__ == '__main__':
    settings = define_settings()
    run_hylaa(settings)

