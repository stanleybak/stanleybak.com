set terminal pdfcairo enhanced dashed font 'Verdana,18' fontscale 0.45
set output 'img_opt_compare.pdf'

set autoscale
unset label
set xtic auto
set ytic auto
set xlabel "Number of Steps (log scale)" offset 0,0.3
set ylabel "Runtime (seconds)" offset 1,0
set xrange [32:230000]
set yrange [0:15]

set style line 1 lc rgb "#0060ad" lt 8 lw 1.0 pt 13 ps 0.8 dt 3
set style line 2 lc rgb "#ff4040" lt 1 lw 1.5 pt 8 ps 0.8 dt 2
set style line 3 lc rgb "#8B008B" lt 6 lw 1.0 pt 5 ps 0.6 dt 3
set style line 4 lc rgb "#00bd60" lt 1 lw 1.5 pt 6 ps 0.8
set style line 5 lc rgb "#ef8d00" lt 2 lw 1.0 pt 3 ps 0.8 dt 3

set grid
set pointintervalbox 0.8
set key left top box width 0.5 samplen 2 font 'Verdana,16' 
set title "Optimization Comparison" font 'Verdana,32' offset 0,-1.2
set tmargin 2

set logscale x 4

plot \
    "out/result_Basic.dat" using 1:3:4 with filledcurves ls 1 fs transparent solid 0.4 noborder notitle, \
    "out/result_Warm.dat" using 1:3:4 with filledcurves ls 2 fs transparent solid 0.4 noborder notitle, \
    "out/result_Decomp.dat" using 1:3:4 with filledcurves ls 3 fs transparent solid 0.4 noborder notitle, \
    "out/result_Hylaa.dat" using 1:3:4 with filledcurves ls 4 fs transparent solid 0.4 noborder notitle, \
    "out/result_NoInput.dat" using 1:3:4 with filledcurves ls 5 fs transparent solid 0.4 noborder notitle, \
    "out/result_Basic.dat" with linespoints title "Basic" ls 1, \
    "out/result_Warm.dat" with linespoints title "Warm" ls 2 pi -1, \
    "out/result_Decomp.dat" with linespoints title "Decomp" ls 3, \
    "out/result_Hylaa.dat" with linespoints title "Hylaa" ls 4 pi -1, \
    "out/result_NoInput.dat" with linespoints title "NoInput" ls 5, \
