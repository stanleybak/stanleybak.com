'''Script for running the arch benchmark systems with hylaa'''

import os
import time
import sys
import subprocess

# make sure hybridpy is on your PYTHONPATH: hyst/src/hybridpy
import hybridpy.hypy as hypy

def is_safe_result(res):
    '''check a result object and check if the tool's result is safe'''

    return res['safe']

def get_script_path(filename=__file__):
    '''get the path this script'''
    return os.path.dirname(os.path.realpath(filename))

def main():
    '''main entry point'''

    # list of model name (used to define filenames)
    models = []
    models.append('Motor')
    models.append('Building')
    models.append('PDE')
    models.append('Heat')
    models.append('ISS')
    models.append('Beam')
    models.append('MNA1')
    models.append('FOM')

    labels = []
    tools = []
    tool_params = []

    tools.append('hylaa')
    labels.append('Hylaa')
    tool_params.append('-settings settings.simulation.sim_in_memory_mb=4096')

    start = time.time()

    with open('benchmark_results.dat', "w") as f:
        f.write('{\\bf Model} & {\\bf Dims} & {\\bf Unsafe Error Condition} & {\\bf Tool} & {\\bf Time (s)} & ' +
                '{\\bf Safe?} & {\\bf CE Error (Abs/Rel)} & {\\bf CE Time} \\\\\n')
        f.write('\\midrule\n')

        for model_name in models:
            for safe in [True, False]:
                for i in xrange(len(tools)):
                    suffix = "" if safe else "_unsafe"
                    outfile = 'out/{}_{}{}.py'.format(labels[i], model_name, suffix)
                    infile = '{}/{}{}.xml'.format(model_name, model_name, suffix)
                    cfgfile = '{}/{}{}.cfg'.format(model_name, model_name, suffix)
                    trace_file = get_script_path() + '/out/{}_{}{}_counterexample.py'.format(labels[i], model_name, suffix)
                    params = tool_params[i]

                    if tools[i] == 'hylaa':
                        params += " settings.counter_example_filename='{}'".format(trace_file)

                    e = hypy.Engine(tools[i], params)
                    e.set_output(outfile)
                    e.set_input(infile)

                    print "Running '{}' on {}...".format(labels[i], infile)
                    res = e.run(print_stdout=True, run_tool=True, parse_output=True)
                    runtime = "-"
                    safe_checkmark = ""
                    is_safe = False

                    if res['code'] == hypy.Engine.TIMEOUT_TOOL:
                        #reached_timeout[i] = True
                        print "Timeout!"
                    elif res['code'] == hypy.Engine.SUCCESS:
                        runtime = runtime_string(res['tool_time'])
                        is_safe = is_safe_result(res['output'])

                        if is_safe:
                            safe_checkmark = '\\checkmark'

                        print "Completed after {} seconds and result is_safe={}".format(runtime, is_safe)
                    else:
                        raise RuntimeError("Running Tool Failed: {}".format(res['code']))

                    error_condition, dims, step, original_star = extract_model_data(cfgfile)
                    ce_acc = "-"
                    ce_time = "-"
                    
                    if not is_safe and tools[i] == "hylaa":
                        ce_data = get_counter_example_data(trace_file)
                        ce_acc = "${} / {}$".format(ce_data[0], ce_data[1])
                        ce_time = ce_data[2]
                        
                    # overrides for other methods
                    print_model_name = model_name
                    
                    if labels[i] != 'Hylaa':
                        error_condition = "~"
                        dims = "~"
                        print_model_name = "~ {}".format(model_name)

                    f.write('{}{} & {} & {} & {} & {} & {} & {} & {} \\\\\n'.format(
                        print_model_name, original_star, dims, error_condition, labels[i], runtime, safe_checkmark, ce_acc, ce_time))
                    f.flush()

    dif = time.time() - start
    print "Measurement Completed in {:2f} seconds".format(dif)

def runtime_string(secs):
    'convert a float of seconds into a string for the table'
    
    rv = ""
    
    if secs < 60:
        rv = "{:.1f}s".format(secs)
    elif secs < 60 * 60:
        mins = int(secs / 60)
        secs = int(secs - 60 * mins)
        rv = "{}m{}s".format(mins, secs)
    else:
        mins = secs / 60.0
        hours = int(mins / 60)
        mins = int(mins - 60 * hours)
        rv = "{}h{}m".format(hours, mins)
        
    return rv

def get_counter_example_data(trace_file):
    '''
    get the l-2 norm of the absolute / relative error of the counter-example trace
    
    returns a latex string tuple (abs_error, rel_error, final_time)
    '''

    params = [sys.executable, trace_file, 'noplot']
    rv = ["", "", ""]

    try:
        proc = subprocess.Popen(params, stdout=subprocess.PIPE)

        line = proc.stdout.readline()

        while line:
            # process line
            line = line.strip()
            print line

             # max difference (l-infinity norm): 3.75398923058e-08 in dimension 5
            if "Absolute Error (l-2 norm):" in line:
                abs_error = "{:.1E}".format(float(line.split(" ")[4]))
                # convert to latex 
                parts = abs_error.split('E')
                rv[0] = "{} \\mkern1mu{{\\cdot}} 10^{{ {} }}".format(parts[0], int(parts[1]))

                print "Extracted absolute error: {}".format(rv[0])
            elif "Relative Error (l-2 norm):" in line:
                rel_error = "{:.1E}".format(float(line.split(" ")[4]))
                # convert to latex
                parts = rel_error.split('E')
                rv[1] = "{} \\mkern1mu{{\\cdot}} 10^{{ {} }}".format(parts[0], int(parts[1]))

                print "Extracted relative error: {}".format(rv[1])
            elif "Final Time:" in line:
                rv[2] = line.split(" ")[2]

            line = proc.stdout.readline()

        proc.wait()

    except OSError as e:
        raise RuntimeError("Error running counter-example trace: {}".format(e))

    return rv

def extract_model_data(cfgfile):
    'Extract data from the cfg file text. Returns a tuple of strings: (error_condition, dims, step, original_star)'

    error_condition = '-'
    dims = '-'
    step = '-'
    original_star = ''

    with open(cfgfile) as f:
        for line in f:
            line = line.strip()

            if 'dimensions: ' in line:
                dims = line.split(': ')[1]
            elif 'original system: ' in line:
                original_star = '*' if 'true' in line.split(': ')[1] else ''
            elif 'error condition: ' in line:
                error_condition = line.split(': ')[1]
            elif 'sampling-time = ' in line:
                step = line.split('= ')[1]

    return (error_condition, dims, step, original_star)

if __name__ == '__main__':
    main()
