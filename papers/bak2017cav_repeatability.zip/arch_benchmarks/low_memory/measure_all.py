'''Script for running all the arch benchmark measurements'''

import subprocess
import time
import sys

def main():
    'main code'
    
    start = time.time()
    
    
    print "Doing 8/9 Hylaa measurements"
    code = subprocess.call([sys.executable, "measure_hylaa.py"])
    print "\nDone with 8/9 Hylaa measurements. Exit Code: {}\n".format(code)
    assert code == 0, "Exit code of sub-script must be zero."

    
    print "Doing other tool measurements"
    code = subprocess.call([sys.executable, "measure_other_tools.py"])
    print "\nDone with other tool measurements. Exit Code: {}\n".format(code)
    assert code == 0, "Exit code of sub-script must be zero."
    
    print "Completed generation of all .dat files of low-memory models in {:.1f} seconds".format(time.time() - start)
    
if __name__ == '__main__':
    main()
