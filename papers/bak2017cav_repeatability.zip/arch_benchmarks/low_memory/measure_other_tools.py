'''Script for running the examples with flowstar and spaccex'''

import os
import time
import sys
import subprocess

# make sure hybridpy is on your PYTHONPATH: hyst/src/hybridpy
import hybridpy.hypy as hypy

def is_safe_result(res):
    '''check a result object and check if the tool's result is safe'''

    return res['safe']

def get_script_path(filename=__file__):
    '''get the path this script'''
    return os.path.dirname(os.path.realpath(filename))

def main():
    '''main entry point'''
    
    timeout_secs = 60 * 60 * 96

    tools = []
    labels = []
    tool_params = []
    models = []
    
    # alternate settings for hylaa
    unique_models_list = []
    unique_models_list.append('Motor')
    unique_models_list.append('Building')
    #unique_models_list.append('PDE')
    #unique_models_list.append('Heat')
    #unique_models_list.append('ISS')
    #unique_models_list.append('Beam')
    #unique_models_list.append('MNA1')
    #unique_models_list.append('FOM')
    
    # If I use TXT output, SpaceEx crashes on the unsafe motor (single dispatcher call)
    # GEN is slightly slower, since some time is spent outputting the bad states, but it doesn't crash
    
    hylaa_labels = ['Warm', 'Decomp']
    hylaa_params = ['-settings settings.simulation.sim_in_memory_mb=4096 settings.opt_decompose_lp=False',
                    '-settings settings.simulation.sim_in_memory_mb=4096 settings.opt_warm_start_lp=False']
                    
    for index in xrange(len(hylaa_labels)):
        label = hylaa_labels[index]
        params = hylaa_params[index]
        
        for model in unique_models_list:
            tools.append('hylaa')
            labels.append(label)
            tool_params.append(params)
            models.append(model)
    
    tools.append('spaceex')
    labels.append('SpaceEx')
    tool_params.append('-scenario supp -skiptol -flowpipe_tol 0 -step 0.0025 -output-format GEN')
    models.append('Motor')

    tools.append('spaceex')
    labels.append('SpaceEx')
    tool_params.append('-scenario supp -skiptol -flowpipe_tol 0 -output-format GEN')
    models.append('Building')

    #tools.append('flowstar')
    #labels.append('Flowstar')
    #tool_params.append('-plot "gnuplot interval t,x1" -orders 20 -step 0.0002')
    #models.append('Motor')
    
    # try basic on building
    #tools.append('hylaa')
    #labels.append('Basic')
    #tool_params.append('-settings settings.opt_warm_start_lp=False' +\
    #                        ' settings.opt_decompose_lp=False settings.simulation.sim_in_memory_mb=4096')
    #models.append('Motor')
    
    #tools.append('hylaa')
    #labels.append('Basic')
    #tool_params.append('-settings settings.opt_warm_start_lp=False' +\
    #                        ' settings.opt_decompose_lp=False settings.simulation.sim_in_memory_mb=4096')
    #models.append('Building')
    
    #tools.append('hylaa')
    #labels.append('Basic')
    #tool_params.append('-settings settings.opt_warm_start_lp=False' +\
    #                        ' settings.opt_decompose_lp=False settings.simulation.sim_in_memory_mb=4096')
    #models.append('PDE')
    
    #tools.append('hylaa')
    #labels.append('Basic')
    #tool_params.append('-settings settings.opt_warm_start_lp=False' +\
    #                        ' settings.opt_decompose_lp=False settings.simulation.sim_in_memory_mb=4096')
    #models.append('Heat')

    start = time.time()

    with open('benchmark_other_tools_results.dat', "w") as f:

        for i in xrange(len(tools)):
            for safe in [True, False]:
                model_name = models[i]
                tool = tools[i]
                label = labels[i]
                extension = "flowstar" if tool == 'flowstar' else 'xml' if tool == "spaceex" else "py"
                suffix = "" if safe else "_unsafe"
                trace_file = get_script_path() + '/out/{}_{}{}_counterexample.py'.format(label, model_name, suffix)
                
                outfile = 'out/{}_{}{}.{}'.format(label, model_name, suffix, extension)
                infile = '{}/{}{}.xml'.format(model_name, model_name, suffix)
                cfgfile = '{}/{}{}.cfg'.format(model_name, model_name, suffix)
                params = tool_params[i]
                
                if tool == 'hylaa':
                    params += " settings.counter_example_filename='{}'".format(trace_file)

                e = hypy.Engine(tool, params)
                e.set_output(outfile)
                e.set_input(infile)

                print "Running '{}' on {}...".format(tool, infile)
                res = e.run(print_stdout=True, run_tool=True, parse_output=True, timeout=timeout_secs)
                runtime = "-"
                safe_checkmark = ""
                is_safe = False

                if res['code'] == hypy.Engine.TIMEOUT_TOOL:
                    #reached_timeout[i] = True
                    print "Timeout!"
                elif res['code'] == hypy.Engine.SUCCESS:
                    runtime = runtime_string(res['tool_time'])
                    is_safe = is_safe_result(res['output'])

                    if is_safe:
                        safe_checkmark = '\\checkmark'

                    print "Completed after {} seconds and result is_safe={}".format(runtime, is_safe)
                else:
                    raise RuntimeError("Running Tool Failed: {}".format(res['code']))

                error_condition, dims, step, original_star = extract_model_data(cfgfile)
                ce_acc = "-"
                ce_time = "-"
                
                if not is_safe and tool == "hylaa":
                    ce_data = get_counter_example_data(trace_file)
                    ce_acc = "${} / {}$".format(ce_data[0], ce_data[1])
                    ce_time = ce_data[2]
                    
                # overrides for other methods
                print_model_name = model_name
                
                if labels[i] != 'Hylaa':
                    error_condition = "~"
                    dims = "~"
                    print_model_name = "~ {}".format(model_name)

                f.write('{}{} & {} & {} & {} & {} & {} & {} & {} \\\\\n'.format(
                    print_model_name, original_star, dims, error_condition, labels[i], runtime, safe_checkmark, ce_acc, ce_time))
                f.flush()

    dif = time.time() - start
    print "Measurement Completed in {:2f} seconds".format(dif)

def runtime_string(secs):
    'convert a float of seconds into a string for the table'
    
    rv = ""
    
    if secs < 60:
        rv = "{:.1f}s".format(secs)
    elif secs < 60 * 60:
        mins = int(secs / 60)
        secs = int(secs - 60 * mins)
        rv = "{}m{}s".format(mins, secs)
    else:
        mins = secs / 60.0
        hours = int(mins / 60)
        mins = int(mins - 60 * hours)
        rv = "{}h{}m".format(hours, mins)
        
    return rv
    
def extract_model_data(cfgfile):
    'Extract data from the cfg file text. Returns a tuple of strings: (error_condition, dims, step, original_star)'

    error_condition = '-'
    dims = '-'
    step = '-'
    original_star = ''

    with open(cfgfile) as f:
        for line in f:
            line = line.strip()

            if 'dimensions: ' in line:
                dims = line.split(': ')[1]
            elif 'original system: ' in line:
                original_star = '*' if 'true' in line.split(': ')[1] else ''
            elif 'error condition: ' in line:
                error_condition = line.split(': ')[1]
            elif 'sampling-time = ' in line:
                step = line.split('= ')[1]

    return (error_condition, dims, step, original_star)

def get_counter_example_data(trace_file):
    '''
    get the l-2 norm of the absolute / relative error of the counter-example trace
    
    returns a latex string tuple (abs_error, rel_error, final_time)
    '''

    params = [sys.executable, trace_file, 'noplot']
    rv = ["", "", ""]

    try:
        proc = subprocess.Popen(params, stdout=subprocess.PIPE)

        line = proc.stdout.readline()

        while line:
            # process line
            line = line.strip()
            print line

             # max difference (l-infinity norm): 3.75398923058e-08 in dimension 5
            if "Absolute Error (l-2 norm):" in line:
                abs_error = "{:.1E}".format(float(line.split(" ")[4]))
                # convert to latex 
                parts = abs_error.split('E')
                rv[0] = "{} \\mkern1mu{{\\cdot}} 10^{{ {} }}".format(parts[0], int(parts[1]))

                print "Extracted absolute error: {}".format(rv[0])
            elif "Relative Error (l-2 norm):" in line:
                rel_error = "{:.1E}".format(float(line.split(" ")[4]))
                # convert to latex
                parts = rel_error.split('E')
                rv[1] = "{} \\mkern1mu{{\\cdot}} 10^{{ {} }}".format(parts[0], int(parts[1]))

                print "Extracted relative error: {}".format(rv[1])
            elif "Final Time:" in line:
                rv[2] = line.split(" ")[2]

            line = proc.stdout.readline()

        proc.wait()

    except OSError as e:
        raise RuntimeError("Error running counter-example trace: {}".format(e))

    return rv
    
if __name__ == '__main__':
    main()
