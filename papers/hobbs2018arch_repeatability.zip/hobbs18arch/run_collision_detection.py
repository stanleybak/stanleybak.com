'''
Stanley Bak, Kerianne Hobbs
Satellite motion simulation in Python
Feb 2018


Coplanar dynamics taken from the paper:
"Satellite Rendezvos and Collision Avoidance: Case Studies in Verification on Nonlinear Hybrid Systems" by
T. Johnson, J. Green, S. Mitra, R. Dudley, and R. S. Erwin, published in FM 2012

Coplanar dynamics confirmed, and out of plane dynamics derived from:
Wiesel, W. "Spaceflight Dynamics" Third Edition, Aphelion Press, 2010.

NOTE: There is a singularity when the inclination is +/- pi/2 radians

Varaible definition:
VAR   | UNITS      | DESCRIPTION
nu    | [rad]      | true anomaly
e     |   -        | eccentricity (0 <= e <= 1)
h     | [km]       | altitude
a     | [km]       | semi-major axis
p     | [km]       | semi-latus rectum computed using p = a(1-e^2) where a is the semi-major axis
mu    | [km^3/s^2] | geocentric gravitational parameter computed as mass * gravitational constant
i     | [rad]      | inclination
Omega | [rad]      | right ascension of the ascending node
omega | [rad]      | argument of perigee
'''

import math
import random
import numpy as np
import pyibex # interval arithmetic library

from scipy.integrate import RK45

from collision_checker import BruteForceCollisionChecker, AabbTreeCollisionChecker
from timerutil import Timers

def nu_dot(nu, p, e):
    '''parameterized derivative function for the angular position nu'''

    assert e >= 0 and e < 1.0, "orbit should be elliptical 0 <= e < 1"
    mu = 3.986012e5 # geocentric gravitational parameter for earth [km^3 / s^2]

    # Equation from Kepler's law of equal areas
    return math.sqrt(mu / p**3) * (1 + e * math.cos(nu))**2

class SatelliteData(object):
    'storage object for satelite data'

    def __init__(self, e, h, i, big_omega, omega):
        self.e = e
        self.h = h
        self.i = i
        self.big_omega = big_omega
        self.omega = omega

        earth_radius = 6371 # [km]

        self.a = h + earth_radius # semi-major axis
        self.p = self.a + (1 - e**2) # semi-latus rectum is computed with p = a(1-e^2) [km]

        self.cos_big_omega = math.cos(big_omega)
        self.sin_big_omega = math.sin(big_omega)

        self.cos_omega = math.cos(omega)
        self.sin_omega = math.sin(omega)

        self.sin_i = math.sin(i)
        self.cos_i = math.cos(i)

        ##### construct interval function #####
        p, e = self.p, self.e
        cos_big_omega = self.cos_big_omega
        sin_big_omega = self.sin_big_omega

        cos_omega = self.cos_omega
        sin_omega = self.sin_omega

        sin_i = self.sin_i
        cos_i = self.cos_i

        r = "{} / (1 + {} * cos(nu))".format(p, e)

        x_p = "{} * cos(nu)".format(r)
        y_q = "{} * sin(nu)".format(r)

        x_i_x = "{} * {}".format(x_p, (cos_big_omega*cos_omega-sin_big_omega*cos_i*sin_omega))
        x_i_y = "{} * {}".format(y_q, (-cos_big_omega*sin_omega-sin_big_omega*cos_i*cos_omega))
        x_i = "{} + {}".format(x_i_x, x_i_y)

        y_j_x = "{} * {}".format(x_p, (sin_big_omega*cos_omega+cos_big_omega*cos_i*sin_omega))
        y_j_y = "{} * {}".format(y_q, (-sin_big_omega*sin_omega+cos_big_omega*cos_i*cos_omega))
        y_j = "{} + {}".format(y_j_x, y_j_y)

        z_k_x = "{} * {}".format(x_p, sin_omega*sin_i)
        z_k_y = "{} * {}".format(y_q, cos_omega*sin_i)
        z_k = "{} + {}".format(z_k_x, z_k_y)

        self.xyz_pos_func = pyibex.Function("nu", "({}, {}, {})".format(x_i, y_j, z_k))

    def get_box(self, nu_min, nu_max):
        'get a box containing the x, y, z position of the satellite, given a range of nu values'

        i = pyibex.Interval(nu_min, nu_max)

        result = self.xyz_pos_func.eval(i)

        box = np.array([[result[i][0], result[i][1]] for i in xrange(3)], dtype=float)

        return box

    def get_xyz(self, nu):
        'get the x, y, z position of the satellite, given nu'

        assert isinstance(nu, float), "expected float, got {}".format(nu)

        x_of, y_of = self.to_cartesian_of(nu)
        return self.to_cartesian_if(x_of, y_of)

    def to_cartesian_of(self, nu):
        'convert the angle nu to orbital frame pqw components x(p) and y(q)'

        p, e = self.p, self.e

        r = p / (1 + e * math.cos(nu))

        x = r * math.cos(nu)
        y = r * math.sin(nu)

        return x, y

    def to_cartesian_if(self, x_p, y_q):
        'convert the from orbital frame pqw to inertial frame ijk with rotation matrix'

        cos_big_omega = self.cos_big_omega
        sin_big_omega = self.sin_big_omega

        cos_omega = self.cos_omega
        sin_omega = self.sin_omega

        sin_i = self.sin_i
        cos_i = self.cos_i

        # break into the orbital frame x and y contributions and add together for easier debugging
        x_i_x = "{} * {}".format(x_p, (cos_big_omega*cos_omega-sin_big_omega*cos_i*sin_omega))
        x_i_y = "{} * {}".format(y_q, (-cos_big_omega*sin_omega-sin_big_omega*cos_i*cos_omega))
        x_i = "{} + {}".format(x_i_x, x_i_y)

        y_j_x = "{} * {}".format(x_p, (sin_big_omega*cos_omega+cos_big_omega*cos_i*sin_omega))
        y_j_y = "{} * {}".format(y_q, (-sin_big_omega*sin_omega+cos_big_omega*cos_i*cos_omega))
        y_j = "{} + {}".format(y_j_x, y_j_y)

        z_k_x = "{} * {}".format(x_p, sin_omega*sin_i)
        z_k_y = "{} * {}".format(y_q, cos_omega*sin_i)
        z_k = "{} + {}".format(z_k_x, z_k_y)

        return x_i, y_j, z_k

def create_satellites(num_sat, seed=0):
    '''
    Create satellites from random parameters

    returns (nu_list, satellites)
    '''

    satellites = []
    nu_list = []

    random.seed(seed) # make the random generation deterministic

    for _ in xrange(num_sat):
        nu = random.uniform(0, 2*math.pi)
        e = random.uniform(0, 0.004)
        h = random.uniform(580, 850) # LEO (+6371)
        i = random.uniform(0, 2*math.pi)
        big_omega = random.uniform(0, 2*math.pi)
        omega = random.uniform(0, 2*math.pi)

        nu_list.append(nu)
        satellites.append(SatelliteData(e, h, i, big_omega, omega))

    assert len(satellites) == num_sat and len(nu_list) == num_sat

    return nu_list, satellites

def measure(num_sat, method, nu_uncertainty=0.01, time_bound=24*60*60, radius=5, min_step=0.1, dynamic_stepping=True):
    '''measure the collision checking time

    returns (num_collisions, sim_time, to_xyz_time, check_collision_time)
    '''

    Timers.reset()
    Timers.tic("total")
    nu_list, satellites = create_satellites(num_sat)

    # uncertainty comes from nu, which we modify slightly
    # need to duplicate each entry in nu_list
    flatten = lambda l: [item for sublist in l for item in sublist]
    double_nu_list = flatten([(n - nu_uncertainty / 2.0, n + nu_uncertainty / 2.0) for n in nu_list])

    def combined_der(_, state):
        'combined derivative function'

        rv = []

        for i in xrange(len(state)):
            s = satellites[i/2] # since double_nu_list is twice the size of satellites
            nu = state[i]
            rv.append(nu_dot(nu, s.p, s.e))

        return rv

    time_list, dense_output_list = run_simulation(combined_der, double_nu_list, time_bound)

    step = min_step
    cur_time = 0.0

    cur_time_index = 1 # time zero should use dense output between steps [0, 1]
    cur_nu_list, _ = get_nu_list(cur_time, time_list, cur_time_index, dense_output_list)

    while cur_time < time_bound:
        if dynamic_stepping:
            next_time = min(cur_time + step, time_bound)
        else: # static stepping
            next_time = min(cur_time + min_step, time_bound)
            step = min_step

        print "\nTrying time range [{}, {}]".format(cur_time, next_time)

        next_nu_list, next_time_index = get_nu_list(next_time, time_list, cur_time_index, dense_output_list)

        collision = try_step(cur_nu_list, next_nu_list, satellites, method=method, radius=radius)

        if collision is None:
            print "No collisions, advancing time to {}".format(next_time)
            cur_time = next_time
            cur_time_index = next_time_index
            cur_nu_list = next_nu_list
            step *= 2
        else:
            print "Potential Collision between {} and {}... reducing step size".format(collision[0], collision[1])
            step /= 2

            if step < min_step:
                print "Could not advance time at {} sec (collision detected)".format(cur_time)

                xyz1 = satellites[collision[0]].get_xyz(cur_nu_list[2*collision[0]])
                xyz2 = satellites[collision[1]].get_xyz(cur_nu_list[2*collision[1]])
                print_distance(xyz1, xyz2)

                xyz1 = satellites[collision[0]].get_xyz(next_nu_list[2*collision[0]])
                xyz2 = satellites[collision[1]].get_xyz(next_nu_list[2*collision[1]])
                print_distance(xyz1, xyz2)

                break

    Timers.toc("total")

def print_distance(xyz1, xyz2):
    'print info about two satellites'

    xyzs = [xyz1, xyz2]

    for i in xrange(2):
        print "satellite {}: {} {} {}".format(i, xyzs[i][0], xyzs[i][1], xyzs[i][2])

    dif = np.array([xyz1[d] - xyz2[d] for d in xrange(3)], dtype=float)
    print "inf-norm = {}".format(np.linalg.norm(dif, np.inf))

def get_nu_list(cur_time, time_list, time_index, dense_output_list):
    '''get the xyz state of each satellite at cur_time. time_index is a hint of where to start looking in
    time_list

    returns (_list, new_time_index)
    '''

    while time_list[time_index] < cur_time:
        time_index += 1

    Timers.tic('get_dense_output')
    nu_list = dense_output_list[time_index-1](cur_time)
    Timers.toc('get_dense_output')

    return nu_list, time_index

def try_step(cur_nu_list, next_nu_list, satellites, method='brute', radius=5):
    '''given the nu_list at two time instants, is there a potential collision?
    returns a list of None or pair of indices which may have collided'''

    # we are not going to do inter-step optimizations yet due to extra complexity in the implementation
    # plus AA-BB trees may be fast enough

    boxes = make_satellite_boxes(cur_nu_list, next_nu_list, satellites)

    if method == 'brute':
        cc = BruteForceCollisionChecker(radius)
    elif method == 'aabb':
        cc = AabbTreeCollisionChecker(radius)
    else:
        raise RuntimeError('Unknown collision checking method: {}'.format(method))

    Timers.tic('collision check')
    Timers.tic("update_boxes")
    cc.update_boxes(boxes)
    Timers.toc("update_boxes")

    Timers.tic("get_collisions")
    collisions = cc.get_collisions()
    Timers.toc("get_collisions")
    Timers.toc('collision check')

    if len(collisions) > 0:
        rv = (collisions[0][0], collisions[0][1])
    else:
        rv = None

    return rv

def make_satellite_boxes(cur_nu_list, next_nu_list, satellites):
    'make the boxes which contain the satellites'

    Timers.tic('make_satellite_boxes')
    num_sat = len(cur_nu_list) / 2

    boxes = np.zeros((num_sat, 3, 2), dtype=float)

    for sat_index in xrange(num_sat):
        cur_nu = (cur_nu_list[2*sat_index], cur_nu_list[2*sat_index + 1])
        next_nu = (next_nu_list[2*sat_index], next_nu_list[2*sat_index + 1])

        boxes[sat_index] = satellites[sat_index].get_box(min(cur_nu[0], next_nu[0]), max(cur_nu[1], next_nu[1]))

    Timers.toc('make_satellite_boxes')

    return boxes

def run_simulation(combined_der, initial_state, time_bound):
    '''run the simulation using numerical integration and return (time_list, dense_output_list),
    time_list is a list of times which indicate the lower-bound time for index i, index i+1 is the upper bound

    dense_output_list is a list of dense_output objects, which can be queried for the state at a specific time
    (should only be used in the corresponding range)
    '''

    Timers.tic("run_simulation")

    time_list = [0]
    dense_output_list = []

    # create the step-by-step integration object for the Runge Kutta 4-5 method
    rk45 = RK45(combined_der, 0, initial_state, time_bound)

    while rk45.status == 'running':
        rk45.step()

        time_list.append(rk45.t)
        dense_output_list.append(rk45.dense_output())

    Timers.toc("run_simulation")

    return time_list, dense_output_list

def main():
    'main entry point - runs the high-level measurements and prints to stdout'

    #measure(100, 'aabb', nu_uncertainty=0.0001, radius=0.1, time_bound=60*60, min_step=0.1, dynamic_stepping=True)
    #measure(100, 'aabb', nu_uncertainty=0.0001, radius=0.1, time_bound=60*60, min_step=0.1, dynamic_stepping=False)

    #measure(1000, 'aabb', nu_uncertainty=0.0001, radius=0.1, time_bound=60, min_step=0.1, dynamic_stepping=True)
    #measure(1000, 'aabb', nu_uncertainty=0.0001, radius=0.1, time_bound=60, min_step=0.1, dynamic_stepping=False)

    measure(5000, 'aabb', nu_uncertainty=0.0001, radius=0.1, time_bound=10, min_step=0.1, dynamic_stepping=True)


    #box_time = Timers.timers['make_satellite_boxes'].total_secs
    #sim_time = Timers.timers['run_simulation'].total_secs
    #col_time = Timers.timers['collision check'].total_secs

    Timers.print_stats()

    # 500, rad = 5, finds collision at time 1191 between (440, 468)

    # 1700, min_step=0.1, radius=1
    #Potential Collision between 1219 and 1680... reducing step size
    #Could not advance time at 335.7 sec (collision detected)

if __name__ == "__main__": # if the script is run directly, call main
    main()
