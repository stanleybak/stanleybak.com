'''
Stanley Bak

Various collision-checking algorithms
'''

import ctypes
import os

import numpy as np
from numpy.ctypeslib import ndpointer
from scipy.spatial import KDTree

def boxes_collide(box1, box2, rad):
    'check if two boxes are within a collision distance of each other'

    rv = True

    for dim in xrange(3):
        if box1[dim][1] + rad < box2[dim][0] or box2[dim][1] + rad < box1[dim][0]:
            rv = False
            break

    return rv

class Freezable(object):
    'a class where you can freeze the fields (prevent new fields from being created)'

    _frozen = False

    def freeze_attrs(self):
        'prevents any new attributes from being created in the object'
        self._frozen = True

    def __setattr__(self, key, value):
        if self._frozen and not hasattr(self, key):
            raise TypeError("{} does not contain attribute '{}' (object was frozen)".format(self, key))

        object.__setattr__(self, key, value)

class BruteForceCollisionChecker(Freezable):
    'check for collision of satellites using brute force method'

    def __init__(self, radius):
        self.radius = radius
        self.box_list = []

        self.freeze_attrs()

    def update_boxes(self, box_list):
        'update the satellite positions'

        self.box_list = box_list

    def get_collisions(self):
        'check for collisions among satellites (returns tuples of colliding satellite indices)'

        rv = []

        for i in xrange(len(self.box_list)):
            box_i = self.box_list[i]

            for j in xrange(i+1, len(self.box_list)):
                box_j = self.box_list[j]

                if boxes_collide(box_i, box_j, self.radius):
                    rv.append((i, j))

        return rv

class AabbTreeCollisionChecker(Freezable):
    'check for collision of satellites using the aabb-tree method'

    def __init__(self, radius):

        script_path = os.path.dirname(os.path.realpath(__file__))
        lib_path = os.path.join(script_path, 'aabb.so')
        self._lib = ctypes.CDLL(lib_path)

        self._update_boxes = self._lib.updateBoxes
        self._update_boxes.restype = ctypes.c_int
        self._update_boxes.argtypes = [ndpointer(ctypes.c_double, flags="C_CONTIGUOUS"), \
                                       ctypes.c_int, ctypes.c_int, ctypes.c_int]

        self._get_collisions = self._lib.getCollisions
        self._get_collisions.restype = ctypes.py_object
        self._get_collisions.argtypes = []

        self._set_params = self._lib.setParams
        self._set_params.restype = None
        self._set_params.argtypes = [ctypes.c_double]

        self._set_params(radius)

        self.freeze_attrs()

    def update_boxes(self, box_list):
        'update the satellite positions'

        reinserted = self._update_boxes(box_list, box_list.shape[0], box_list.shape[1], box_list.shape[2])

        print "reinserted count: {}".format(reinserted)

    def get_collisions(self):
        '''check for collisions among satellites (returns an empty list, or a list with a single tuple
        (the first collision found)
        '''

        num_collisions, col_index1, col_index2 = self._get_collisions()

        if num_collisions > 0:
            rv = [(col_index1, col_index2)]
        else:
            rv = []

        return rv
