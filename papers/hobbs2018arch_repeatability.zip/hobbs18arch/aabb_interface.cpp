// Stanley Bak
// AA-BB Tree interface

#include <stdio.h>
#include <stdlib.h>
#include <vector>

#include <Python.h>

#include "AABB.hpp"

using namespace std;

class AabbTree
{
   public:
    AabbTree() : rawTree(3, 0.5) {}

    void setParams(double collisionRadius)
    {
        this->collisionRadius = collisionRadius;
        this->objectRadius = collisionRadius / 2.0;
        this->skinThickness = 0;
    }

    int updateBoxes(double* boxList, int num)
    {
        this->num = num;

        // make a new tree every time... for now
        rawTree = aabb::Tree(3, skinThickness);

        int rv = 0;

        for (int i = 0; i < num; ++i)
        {
            std::vector<double> lowerBound({0, 0, 0});
            std::vector<double> upperBound({0, 0, 0});

            for (int d = 0; d < 3; ++d)
            {
                lowerBound[d] = boxList[6 * i + 2 * d] - objectRadius;
                upperBound[d] = boxList[6 * i + 2 * d + 1] + objectRadius;
            }

            rawTree.insertParticle(i, lowerBound, upperBound);
            ++rv;
        }

        return rv;
    }

    void getCollisions(int& numCollisions, int& firstCollisionI, int& firstCollisionJ)
    {
        numCollisions = 0;
        firstCollisionI = -1;
        firstCollisionJ = -1;

        for (int i = 0; i < num; ++i)
        {
            std::vector<unsigned int> particles = rawTree.query(i);

            if (particles.size() > 0)
            {
                // do the more accurate, inf-norm check for each particle
                for (int j = 0; j < (int)particles.size(); ++j)
                {
                    if ((int)particles[j] < i)  // don't double-count symmetric collisions
                        continue;

                    if (firstCollisionI < 0)  // if it hasn't been assigned
                    {
                        firstCollisionI = i;
                        firstCollisionJ = particles[j];
                    }

                    ++numCollisions;
                    // printf("Collision between %d and %d\n", i, (int)particles[j]);
                }
            }
        }
    }

   private:
    aabb::Tree rawTree;
    double objectRadius = 0;
    double collisionRadius = 0;
    double skinThickness = 0;
    int num = 0;
};

AabbTree tree;

extern "C" {
void setParams(double collisionRadius)
{
    tree.setParams(collisionRadius);
}

// returns the number of re-inserted points
int updateBoxes(double* box_list, int num_sat, int dims, int minmax)
{
    if (dims != 3 || minmax != 2)
    {
        printf("Error: Exprected dims=3 and minmax=2 in update_boxes, got dims=%d, minmax=%d\n",
               dims, minmax);
        exit(1);
    }

    return tree.updateBoxes(box_list, num_sat);
}

// returns a tuple (int, int, int), of (numCollisions, i, j), where i, and j are the indices of the
// first collision
PyObject* getCollisions()
{
    int numCollisions = 0;
    int i = -1;
    int j = -1;

    tree.getCollisions(numCollisions, i, j);

    PyObject* tuple = Py_BuildValue("(iii)", numCollisions, i, j);

    return tuple;
}
}  // extern "C"
