'''
Stanley Bak

Plot utilities for van der pol system
'''

import math

import matplotlib.pyplot as plt
from matplotlib.text import Text
import numpy as np

def plot_streamplot():
    '''using matplotlib, plot a streamplot and the barrier certificate
    '''

    _, ax = plt.subplots(figsize=(10, 10))

    ax.add_artist(plt.Rectangle((-1.0, -1.0), 2.0, 2.0, color='0.6', lw=1, fill=True))
    ax.add_artist(Text(-0.2, -0.1, "Init", color='0.0', size=30))

    ax.add_artist(plt.Rectangle((-3.5, 3.1), 7.0, 1.0, color='0.6', lw=1, fill=True))
    ax.add_artist(Text(-0.6, 3.2, "Unsafe", color='0.0', size=30))

    ax.set_xlim((-3.5, 3.5))
    ax.set_ylim((-3.5, 3.5))

    #ax.set_title('Van der Pol System', fontsize=30)
    ax.set_xlabel('$x$', fontsize=30)
    ax.set_ylabel('$y$', fontsize=30)

    plt.tick_params(axis='both', which='major', labelsize=25)
    plt.tight_layout()

    #####
    ys, xs = np.mgrid[-3.5:3.5:100j, -3.5:3.5:100j]
    us = ys
    vs = (1.0 - xs*xs)*ys - xs
    speed = np.sqrt(us*us + vs*vs)

    lw = 1.0 + 1*speed / speed.max()
    ax.streamplot(xs, ys, us, vs, density=0.9, color='k', linewidth=lw, arrowsize=3.0)
    ######

    # sample from 0 to 2pi
    thetas = np.linspace(0, 2*math.pi, num=160, endpoint=False)

    for theta in thetas:
        x = 3.0*math.cos(theta)
        y = 3.0*math.sin(theta)

        # check Lie derivative
        lie = y**2*(2 + -2*x**2)

        col = 'g' if lie < -1e-6 else 'r'
        ms = 10 if lie < -1e-6 else 6

        ax.plot([x], [y], c=col, marker='o', ms=ms, lw=0)

    plt.savefig('streamplot.png', bbox_inches='tight')

def plot_gnuplot_data(data_lists, use_backreach, filename=None):
    '''using matplotlib, plot several lists of rect, gnuplot data

    each element of data_list is a [rect, lol] where:
        rect is the start set
        lol is a list of lists of parsed gnuplot data (see above function)
    '''

    _, ax = plt.subplots(figsize=(10, 10))

    if use_backreach:
        # plot initial states

        ax.add_artist(plt.Rectangle((-1.0, -1.0), 2.0, 2.0, color='0.6', lw=1, fill=True))
        ax.add_artist(Text(-0.2, -0.1, "Init", color='0.0', size=30))
    else:
        # plot unsafe states
        ax.add_artist(plt.Rectangle((-3.5, 3.1), 7.0, 3.0, color='0.6', lw=1, fill=True))
        ax.add_artist(Text(-2.3, 4.0, "Unsafe", color='0.0', size=30))

    ax.set_xlabel('$x$', fontsize=30)
    ax.set_ylabel('$y$', fontsize=30)

    plt.tick_params(axis='both', which='major', labelsize=25)
    plt.tight_layout()

    ax.add_artist(plt.Circle((0, 0), 3, color='k', lw=2, fill=False))

    ax.set_xlim((-3.5, 3.5))

    if use_backreach:
        ax.set_ylim((-3.5, 3.5))
        ys, xs = np.mgrid[-3.5:3.5:100j, -3.5:3.5:100j]
    else:
        ax.set_ylim((-5.0, 5.0))
        ys, xs = np.mgrid[-5.0:5.0:100j, -3.5:3.5:100j]

    #####

    us = ys
    vs = (1.0 - xs*xs)*ys - xs
    speed = np.sqrt(us*us + vs*vs)

    lw = 1.0 + 1*speed / speed.max()
    ax.streamplot(xs, ys, us, vs, density=0.9, color='k', linewidth=lw, arrowsize=3.0)
    ######

    for index in xrange(len(data_lists)):
        lol = data_lists[index][1]

        for polygon in lol:
            xs = [pt[0] for pt in polygon]
            ys = [pt[1] for pt in polygon]

            ax.plot(xs, ys, c='b')

    # after all plots, plot the rects in red
    for index in xrange(len(data_lists)):
        rect = data_lists[index][0]

        xmin, xmax = rect[0]
        ymin, ymax = rect[1]

        xs = [xmin, xmax, xmax, xmin, xmin]
        ys = [ymin, ymin, ymax, ymax, ymin]

        ax.plot(xs, ys, c='r', lw=2)

    if filename is None:
        plt.show()
    else:
        plt.savefig(filename, bbox_inches='tight')
