'''
Stanley Bak

Reachbility functions for t-barrier certificates
'''

from hybridpy import hypy
from hybridpy.args_builder import BuildGenArgsBuilder

from plots import plot_gnuplot_data
import util

def run_backreachability(rect, max_time, barrier, var_list, der_list):
    '''run reachability, splitting the initial rectangle recursively if not safe

    This returns a tuple:
     (1) True/False - is the system safe?
     (2) if safe, a list of tuples, (initial rectangles proven to be safe, reachability oct points)
    '''

    return rec_reach(rect, max_time, barrier, var_list, der_list, True)

def run_reachability(rect, max_time, barrier, var_list, der_list):
    '''run reachability, splitting the initial rectangle recursively if not safe

    This returns a tuple:
     (1) True/False - is the system safe?
     (2) if safe, a list of tuples, (initial rectangles proven to be safe, reachability oct points)
    '''

    return rec_reach(rect, max_time, barrier, var_list, der_list, False)

def rec_reach(rect, max_time, barrier, var_list, der_list, use_backreach):
    '''
    recursive call to reachability computation
    '''

    rv = (False, None)
    safe, reach_oct_pts = run_flowstar(rect, max_time, barrier, var_list, der_list, use_backreach)

    if safe:
        rv = (True, [(rect, reach_oct_pts)])

    if not safe:
        max_width = rect[0][1] - rect[0][0]
        split_dim = 0

        for dim in xrange(1, len(rect)):
            width = rect[dim][1] - rect[dim][0]

            if width > max_width:
                max_width = width
                split_dim = dim

        if max_width < 0.001:
            print "Maximum width < 0.001 and still not safe, giving up on splitting"
        else:
            print "Result was not safe. Splitting along dimension {}".format(split_dim)

            rect1 = []
            rect2 = []

            for dim in xrange(len(rect)):
                if dim == split_dim:
                    mid = (rect[dim][0] + rect[dim][1]) / 2.0
                    rect1.append([rect[dim][0], mid])
                    rect2.append([mid, rect[dim][1]])
                else:
                    rect1.append([rect[dim][0], rect[dim][1]])
                    rect2.append([rect[dim][0], rect[dim][1]])

            safe1, reach_list1 = rec_reach(rect1, max_time, barrier, var_list, der_list, use_backreach)

            if safe1:
                safe2, reach_list2 = rec_reach(rect2, max_time, barrier, var_list, der_list, use_backreach)

                if safe2 is not None:
                    rv = (True, reach_list1 + reach_list2)

    return rv

def run_flowstar(rect, max_time, barrier, var_list, der_list, use_backreach):
    '''create a hybrid automaton, run reachability computation, returns a tuple:

    (1) True/False - is the system safe
    (2) a list of gnuplot oct points (reach set)
    '''

    print "Running {} reachability with initial rectangle: {}".format('backward' if use_backreach else 'forward', rect)

    epsilon = 1e-4
    num_dims = len(var_list)

    if use_backreach:
        inv_str = str(barrier <= epsilon).replace("**", "^")
    else:
        inv_str = str(barrier >= -epsilon).replace("**", "^")

    error_condition_string = "barrier_clock >= {}".format(max_time)

    init_condition = "barrier_clock == 0"
    var_strings = ["barrier_clock"]
    der_strings = ["1"]

    for d in xrange(num_dims):
        var_name = str(var_list[d])
        var_strings.append(var_name)
        der_string = str(der_list[d]).replace("**", "^")

        if use_backreach:
            der_strings.append('-(' + der_string + ')') # negative the derivative for back-reach
        else:
            der_strings.append('('+ der_string + ')')

        bounds = rect[d]

        init_condition += " & {} <= {} <= {}".format(bounds[0], var_name, bounds[1])

    b = BuildGenArgsBuilder(var_strings)
    b.set_time_bound(max_time + epsilon)

    b.add_mode("on", inv_str, der_strings)
    b.add_mode("error", "true", ['0.0'] * (num_dims + 1))

    b.add_transition("on", "error", error_condition_string, None)

    b.add_init_condition("on", init_condition)
    b.add_error_condition("error", "true")

    gen_param = b.get_generator_param()

    # perhaps we should autotune different flow* parameters here...
    flowstar_param = "-step 0.025 -orders 4 -rem 1e-2" # -time max_time ???? was 2.0

    flowstar_param += ' -plot "gnuplot octagon x,y"'

    e = hypy.Engine('flowstar', flowstar_param)
    #e = hypy.Engine('pysim', '-rand 100 -corners True -xdim 1 -ydim 2')
    e.set_generator('build', gen_param)
    #e.set_verbose(True)

    # do pseudo-invariant pass to help reachability along,
    # perhaps we should do this several times...
    #e.add_pass('pi_sim', '-times 0.1')

    e.set_output('generated.model')

    res = e.run(print_stdout=False, parse_output=True)
    safe = False
    code = res['code']
    oct_pts = None

    if code == hypy.Engine.SUCCESS:
        obj = res['output']
        if obj['result'] == 'SAFE': # Flow* result
            safe = True
        else:
            print "Flow* result was not 'SAFE' (it was '{}')".format(obj['result'])

        if 'gnuplot_oct_data' in obj:
            oct_pts = util.parse_gnuplot_text(obj['gnuplot_oct_data'])

    else:
        print "Hypy returned error: {}".format(code)

    return safe, oct_pts









