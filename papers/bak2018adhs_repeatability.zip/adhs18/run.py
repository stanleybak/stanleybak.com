'''
Stanley Bak
August 2016
T-Barrier Certificate w/SAT tool
'''

import math

from sympy import symbols
from z3 import Real, Not, And

from reach import run_backreachability, run_reachability

import util
from plots import plot_streamplot, plot_gnuplot_data

def get_circle_constraint(z3_var_list, z3_rect_constraints, z3_psi_barrier, lie_der, point):
    '''
    find the minimum radius_sq where the there's a point with a negative lie derivative (inward facing)
    returns a z3 constraint that a point is on that circle
    '''

    # minimize the radius_sq where an intersecting point has a negative lie derivative value
    radius_sq = Real('radius_sq')
    dist_sq = 0

    for d in xrange(len(point)):
        dx = z3_var_list[d] - point[d]
        dist_sq += dx * dx

    radius_constraint = dist_sq == radius_sq

    constraints = z3_rect_constraints + [z3_psi_barrier == 0] + [radius_constraint] + [lie_der == 0]

    tol = 1e-4
    model = util.z3_minimize(radius_sq, constraints, tol=tol)

    if model is None:
        raise RuntimeError("Could not find a valid radius where some boundary-intersecting points" +
                           "have inward trajectories.")

    val = util.extract_val(model, dist_sq)
    val += tol # we might be off by the optimization tolerance, enlarge the circle

    print "circle radius:", math.sqrt(val)

    return dist_sq <= val

def get_barrier_holes(z3_var_list, z3_psi_barrier, lie_der):
    'get a list of rectanges which are the holes in the barrier certificate'

    rects = []
    z3_rect_constraints = []

    while True:
        # maximize lie derivative (to see if it's ever greater than 0)
        model = util.z3_maximize(lie_der, z3_rect_constraints + [z3_psi_barrier == 0])

        if model is None:
            break

        val = util.extract_val(model, lie_der)
        point = util.extract_point(model, z3_var_list)
        print "found maximum lie derivative value of {} at point {}".format(val, point)

        if val < 0:
            break

        circle_constraint = get_circle_constraint(z3_var_list, z3_rect_constraints, z3_psi_barrier, lie_der, point)

        # find the min and max for each dimension along the intersection of the barrier and the circle

        rect = []
        rect_constraint = True

        for var in z3_var_list:
            tol = 1e-4
            min_val = util.extract_val(util.z3_minimize(var, [z3_psi_barrier == 0, circle_constraint], tol=tol), var)
            max_val = util.extract_val(util.z3_maximize(var, [z3_psi_barrier == 0, circle_constraint], tol=tol), var)

            # bloat since our limits are approximate
            min_val -= tol
            max_val += tol

            rect.append((min_val, max_val))
            rect_constraint = And(rect_constraint, And(var >= min_val, var <= max_val))

        print "Rect to remove from barrier: {}".format(rect)
        rects.append(rect)
        z3_rect_constraints.append(Not(rect_constraint))

        print "-----------\n"

    print "Found all rectangles to remove (count: {})".format(len(rects))
    return rects



def main():
    'main entry point'

    # dynamics and barrier specification
    sympy_var_list = x, y = symbols("x y")
    sympy_der_list = [y, (1.0 - x*x)*y - x]
    sympy_psi_barrier = x*x+y*y-9 # negative inside, 0 on barrier, positive outside

    # find lie derivative
    z3_var_list, z3_psi_barrier = util.sympy_to_z3(sympy_var_list, sympy_psi_barrier)
    lie_der = util.lie_derivative(sympy_var_list, sympy_der_list, sympy_psi_barrier)
    print "Symbolic lie derivative:", lie_der

    # get a list of rects where the barrier holes are
    rects = get_barrier_holes(z3_var_list, z3_psi_barrier, lie_der)
    time_bound = 5

    plot_list = []
    use_backreach = False # use backwards or forwards reachability check?

    for rect in rects:
        # perform a backward reachability analysis to ensure that all points in rect started outside the barrier

        if use_backreach:
            safe, plot_data = run_backreachability(rect, time_bound, sympy_psi_barrier, sympy_var_list, \
                                                         sympy_der_list)
        else:
            safe, plot_data = run_reachability(rect, time_bound, sympy_psi_barrier, sympy_var_list, \
                                             sympy_der_list)

        if not safe:
            plot_list = None
            print "Error: t-barrier reachability condition not proved from hole {}".format(rect)
            break

        plot_list += plot_data

    if plot_list is not None:
        print "\nt-barrier certificate proved safe"
        plot_gnuplot_data(plot_list, use_backreach, 'plot_{}_all.png'.format('back' if use_backreach else 'forward'))

if __name__ == '__main__':
    plot_streamplot()
    main()
