'''
Stanley Bak
August 2016
T-Barrier w/SAT Utility function
'''

import matplotlib.pyplot as plt
import numpy as np

from z3 import Real, Sqrt, Solver, sat
from z3 import is_int_value, is_rational_value, is_algebraic_value
from sympy.core import Mul, Expr, Add, Pow, Symbol, Number
from sympy import diff
from sympy import simplify

def lie_derivative(var_list, der_list, psi_barrier):
    '''
    compute the lie derivative as a z3 expression

    var list is a list of sympy variables
    der_list is a list of sympy derivaties for each variable
    psi_barrier is a sympy expression for the barrier function

    returns a z3 expression for the lie derivative of psi with respect to the derivatives
    '''

    # derived parameters and initialization
    assert len(der_list) == len(var_list), "all variables must have a derivative"
    num_dims = len(var_list)

    # construct lie derivative of psi
    lie_der = 0

    for d in xrange(num_dims):
        lie_der += diff(psi_barrier, var_list[d]) * der_list[d]

    lie_der = simplify(lie_der)

    _, z3_lie_der = sympy_to_z3(var_list, lie_der)

    return z3_lie_der

def sympy_to_z3(sympy_var_list, sympy_exp):
    'convert a sympy expression to a z3 expression. This returns (z3_vars, z3_expression)'

    z3_vars = []
    z3_var_map = {}

    for var in sympy_var_list:
        name = var.name
        z3_var = Real(name)
        z3_var_map[name] = z3_var
        z3_vars.append(z3_var)

    result_exp = _sympy_to_z3_rec(z3_var_map, sympy_exp)

    return z3_vars, result_exp

def _sympy_to_z3_rec(var_map, e):
    'recursive call for sympy_to_z3()'

    rv = None

    if not isinstance(e, Expr):
        raise RuntimeError("Expected sympy Expr: " + repr(e))

    if isinstance(e, Symbol):
        rv = var_map.get(e.name)

        if rv is None:
            raise RuntimeError("No var was corresponds to symbol '" + str(e) + "'")

    elif isinstance(e, Number):
        rv = float(e)
    elif isinstance(e, Mul):
        rv = _sympy_to_z3_rec(var_map, e.args[0])

        for child in e.args[1:]:
            rv *= _sympy_to_z3_rec(var_map, child)
    elif isinstance(e, Add):
        rv = _sympy_to_z3_rec(var_map, e.args[0])

        for child in e.args[1:]:
            rv += _sympy_to_z3_rec(var_map, child)
    elif isinstance(e, Pow):
        term = _sympy_to_z3_rec(var_map, e.args[0])
        exponent = _sympy_to_z3_rec(var_map, e.args[1])

        if exponent == 0.5:
            # sqrt
            rv = Sqrt(term)
        else:
            rv = term**exponent

    if rv is None:
        raise RuntimeError("Type '" + str(type(e)) + "' is not yet implemented for convertion to a z3 expresion. " + \
                            "Subexpression was '" + str(e) + "'.")

    return rv

def check_sat(condition_list):
    '''
    check the satisfiability of a list of conditions. This returns None if unsat, or
    the satisfying model if sat)
    '''

    rv = None
    s = Solver()

    for c in condition_list:
        s.add(c)

    if s.check() == sat:
        rv = s.model()

    return rv

def z3_num_to_float(n):
    'convert a z3 number to a float value'
    rv = None

    if is_int_value(n):
        rv = float(n.as_long())
    elif is_rational_value(n):
        rv = float(n.numerator_as_long())/float(n.denominator_as_long())
    elif is_algebraic_value(n):
        approx = n.approx(20)
        rv = float(approx.numerator_as_long())/float(approx.denominator_as_long())
    else:
        raise RuntimeError('Cannot convert z3 type to float: {}'.format(n))

    return rv

def extract_point(model, z3_exp_list):
    '''
    extract each of a list of expressions from a model
    '''

    rv = []

    for e in z3_exp_list:
        rv.append(extract_val(model, e))

    return rv

def extract_val(model, z3_exp):
    '''
    get a float value out of a satisfiable z3 model
    '''

    return z3_num_to_float(model.evaluate(z3_exp))

def z3_maximize(exp_to_maximize, constraints, tol=1e-4, stop_val=-1e9, output=False):
    'maximize a z3 expression (see aguments of z3_minimize)'

    return z3_minimize(-exp_to_maximize, constraints, tol=tol, stop_val=stop_val, output=output)

def z3_minimize(exp_to_minimize, constraints, tol=1e-4, stop_val=-1e9, output=False):
    '''
    minimize an expression value through iterative calls to Z3.

    if the exp is unsat, None is returned
    if the exp is unbounded, a RuntimeError is raised
    tol is the tolerance on the answer (min_val - tol is unachievable)
    stop_val is the minimum value before the answer is considered unbounded
    constraints is a list of z3 conditions
    returns the z3 model object
    '''

    rv = None

    z3_calls = 0

    # first find any satisfying assignment
    model = check_sat(constraints)
    z3_calls += 1

    if model != None:
        # first binary search to find a sat <-> unsafe separation
        sat_val = extract_val(model, exp_to_minimize)
        sat_model = model
        unsat_val = None
        step = tol

        while True:
            next_trial_val = sat_val - step

            if next_trial_val < stop_val:
                next_trial_val = stop_val

            model = check_sat(constraints + [exp_to_minimize <= next_trial_val])
            z3_calls += 1

            if model is None:
                unsat_val = next_trial_val
                break

            # model exists, formula is sat
            if next_trial_val == stop_val:
                raise RuntimeError("z3 optimization appears unbounded after {} SMT calls".format(z3_calls))

            sat_val = extract_val(model, exp_to_minimize)

            sat_model = model
            step *= 2

        # at this point, both sat_val and unsat_val have been set

        # if we found unsat_val in a small step, then we're done
        if step == tol:
            rv = sat_model
        else:
            # try a one-off check to see if sat_val is the actual minimum (happens quite often)
            next_trial_val = sat_val - tol
            model = check_sat(constraints + [exp_to_minimize <= next_trial_val])
            z3_calls += 1

        if model is None:
            # sat_val was the minimum, we're done
            rv = sat_model
        else:
            # sat_val was NOT the minimum, do a binary search to the desired tolerance
            sat_val = extract_val(model, exp_to_minimize)
            sat_model = model

            while sat_val - unsat_val > tol:
                next_trial_val = (sat_val + unsat_val) / 2.0

                model = check_sat(constraints + [exp_to_minimize <= next_trial_val])
                z3_calls += 1

                if model is None:
                    # middle was unsat
                    unsat_val = next_trial_val
                else:
                    # middle (or less) was sat
                    sat_val = extract_val(model, exp_to_minimize)
                    sat_model = model

            # binary search completed to the desired tolerance
            rv = sat_model

    if output:
        if rv != None:
            print "z3 minimization found value {} after {} z3 calls".format(sat_val, z3_calls)
        else:
            print "model was unsat after {} z3 calls".format(z3_calls)

    return rv

def parse_gnuplot_text(string):
    'parse gnuplot data (flow* output) from string output to a list of lists'

    rv = []
    parts = string.split('\n\n\n')

    for part in parts:
        if part == '': # blank line at the end
            continue

        lines = part.split('\n')

        oct_pts = []

        for line in lines:
            nums = line.split(' ')

            assert len(nums) == 2, 'expected two numbers per line: {}'.format(line)

            oct_pts.append([float(nums[0]), float(nums[1])])

        rv.append(oct_pts)

    return rv









