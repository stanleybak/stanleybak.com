'''
Unit tests for star.py
Stanley Bak
August 2016
'''

import unittest
from util import z3_maximize, extract_val, parse_gnuplot_text, plot_gnuplot_data
from z3 import Reals

class TestUtil(unittest.TestCase):
    'Unit tests class for util'

    def test_z3_min(self):
        'test z3 minimization'

        places = 2
        x, y = Reals('x y')

        exp = 2*y*y*(1-x*x)

        # force no exact answer with the 'y != 3/-3' conditions
        conds = [x*x+y*y == 9, y != 3, y != -3, exp >= 0]

        model = z3_maximize(exp, conds, output=False)

        val = extract_val(model, exp)

        self.assertAlmostEquals(val, 18, places)

        # first solution
        self.assertAlmostEquals(extract_val(model, x), 0, places)
        self.assertAlmostEquals(extract_val(model, y), 3, places)

    def test_parse_gnuplot_data(self):
        'test splitting the gnuplot data into lists of lists'

        text_data = '0.0 0.0\n1.0 0.0\n0.5 1.0\n\n\n0.0 10.0\n1.0 10.0\n0.5 11.0\n\n\n'

        lol = parse_gnuplot_text(text_data)

        self.assertEquals(len(lol), 2)
        self.assertEquals(len(lol[0]), 3)
        self.assertEquals(len(lol[1]), 3)

        self.assertAlmostEquals(lol[0][0][0], 0)
        self.assertAlmostEquals(lol[0][0][1], 0)

        self.assertAlmostEquals(lol[0][1][0], 1)
        self.assertAlmostEquals(lol[0][1][1], 0)

        self.assertAlmostEquals(lol[0][2][0], 0.5)
        self.assertAlmostEquals(lol[0][2][1], 1.0)

        #
        self.assertAlmostEquals(lol[1][0][0], 0)
        self.assertAlmostEquals(lol[1][0][1], 10)

        self.assertAlmostEquals(lol[1][1][0], 1)
        self.assertAlmostEquals(lol[1][1][1], 10)

        self.assertAlmostEquals(lol[1][2][0], 0.5)
        self.assertAlmostEquals(lol[1][2][1], 11.0)

if __name__ == '__main__':
    unittest.main()
