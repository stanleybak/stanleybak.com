'''
Created by Hyst v1.3
Hybrid Automaton in Hylaa
Converted from file: trim.xml
Command Line arguments: -i trim.xml -o out_hylaa.py -tool hylaa "-settings settings.plot.plot_mode=PlotSettings.PLOT_IMAGE settings.plot.filename='/home/ubuntu/Desktop/HSCC2017/invariant_trim/trim_hylaa.png'"
'''

import numpy as np
from hylaa.hybrid_automaton import LinearHybridAutomaton, LinearConstraint
from hylaa.engine import HylaaSettings
from hylaa.engine import HylaaEngine
from hylaa.containers import PlotSettings, SimulationSettings

def define_ha():
    '''make the hybrid automaton and return it'''

    ha = LinearHybridAutomaton()
    ha.variables = ["x", "y"]


    running = ha.new_mode('running')
    a_matrix = np.array([ \
        [0, 1], \
        [-1, 0], \
        ], dtype=float)
    c_vector = np.array([0, 0], dtype=float)
    running.set_dynamics(a_matrix, c_vector)
    running.inv_list.append(LinearConstraint([-0, -1], -0)) # y >= 0.0
    running.inv_list.append(LinearConstraint([0, 1], 5.1)) # y <= 5.1

    return ha

def define_init_states(ha):
    '''returns a list of (mode, list(LinearConstraint])'''
    # Variable ordering: [x, y]
    rv = []
    
    constraints = []
    constraints.append(LinearConstraint([-1, 0], 6)) # -6.0 <= x
    constraints.append(LinearConstraint([1, 0], -5)) # x <= -5.0
    constraints.append(LinearConstraint([0, -1], 0)) # 0.0 <= y
    constraints.append(LinearConstraint([0, 1], 1)) # y <= 1.0
    rv.append((ha.modes['running'], constraints))
    
    return rv


def define_settings():
    'get the hylaa settings object'
    plot_settings = PlotSettings()
    plot_settings.plot_mode = PlotSettings.PLOT_NONE
    plot_settings.xdim = 0
    plot_settings.ydim = 1

    settings = HylaaSettings(step=0.003, max_time=5.0, plot_settings=plot_settings)

    settings.plot.plot_mode=PlotSettings.PLOT_IMAGE
    settings.plot.filename='/home/ubuntu/Desktop/HSCC2017/invariant_trim/trim_hylaa.png'

    return settings

def run_hylaa(settings):
    'Runs hylaa with the given settings, returning the HylaaResult object.'
    ha = define_ha()
    init = define_init_states(ha)

    engine = HylaaEngine(ha, settings)
    engine.run(init)

    return engine.result

if __name__ == '__main__':
    run_hylaa(define_settings())

