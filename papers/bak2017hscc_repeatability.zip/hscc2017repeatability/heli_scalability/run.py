'''
Stanley Bak
September 2016
Run Hylaa and SpaceEx on the copied helicopter benchmark
'''

import time
import subprocess

from hybridpy import hypy

def main():
    'main function'
    
    start = time.time()

    run('heli_large60', "Helicopter", timeout=60)
    run('heli_large1200', "Helicopter", timeout=1200)
    
    print "Total script runtime: {:.2f} sec".format(time.time() - start)

def run(name, title, timeout=5):
    'main execution function'

    tools = []
    labels = []
    tool_params = []

    tools.append('spaceex')
    labels.append('SpaceEx-stc')
    tool_params.append('-scenario stc -skiptol -flowpipe_tol 0 -output-format INTV')

    tools.append('spaceex')
    labels.append('SpaceEx-supp')
    tool_params.append('-scenario supp -skiptol -flowpipe_tol 0 -output-format TXT')

    tools.append('hylaa')
    labels.append('Hylaa')
    tool_params.append('')

    # flow* doesn't work! (initial states larger than example on website)
    # tools.append('flowstar')
    # labels.append('Flowstar')
    # tool_params.append('-order 3-3')

    assert len(labels) == len(tools)

    heli_copies = xrange(1, 100)
    start = time.time()
    data_files = []
    
    for i in xrange(len(tools)):
        tool_name = tools[i]   
        filename = 'out/data_{}_{}_{}.dat'.format(name, i, labels[i])
        data_files.append(filename)
 
        with open(filename, "w") as f:

            for num_copies in heli_copies:
                num_dims = 28 * num_copies + 1
                print "\nRunning {} with {} {} copies ({} dims)".format(tool_name, num_copies, name, num_dims)
                e = hypy.Engine(tool_name, tool_params[i])
                #e.set_output('out.xml')
                e.set_input('heli_large.xml'.format(name))
                e.add_pass('copy', '-num {} -instance heli'.format(num_copies))

                res = e.run(print_stdout=True, run_tool=True, timeout=timeout)

                if res['code'] != hypy.Engine.SUCCESS:
                    print "Hylaa Failed on {} with {} copies: {}".format(
                        tool_name, num_copies, res['code'])
                    break

                runtime = res['tool_time']

                
                f.write('{} {}\n'.format(num_dims, runtime))

    dif = time.time() - start
    print "Measurement Completed in {:2f} seconds".format(dif)

    make_plot(name, title, data_files, labels)

def make_plot(name, title, data_files, file_labels):
    'use gnuplot to plot the results'

    gnuplot_filename = 'out/make_{}.gnuplot'.format(name)
    eps_filename = "{}.eps".format(name)

    with open(gnuplot_filename, "w") as f:
        f.write('set terminal postscript eps enhanced color\n')
        f.write('set output "{}"\n'.format(eps_filename))
        f.write('set autoscale\n')
        
        f.write('unset label\n')
        f.write('set xtic auto\n')
        f.write('set ytic auto\n')
        f.write('set xlabel "Dimensions"\n')
        f.write('set ylabel "Seconds"\n')
        f.write('set size ratio 0.5\n\n')

        f.write('set style line 1 lc rgb "#00bd60" lt 6 lw 4 pt 6 pi -1 ps 1.5\n')
        f.write('set style line 2 lc rgb "#ff4040" lt 2 lw 3 pt 9 pi -1 ps 1.75\n')
        f.write('set style line 3 lc rgb "#0060ad" lt 1 lw 2 pt 7 pi -1 ps 1.5\n')
        f.write('set style line 4 lc rgb "#ef8d00" lt 8 lw 2 pt 3 pi -1 ps 1.5\n')

        f.write('set pointintervalbox 2\n')
        f.write('set key left top\n')
        f.write('set title "Tool Scalability ({})"\n'.format(title))

        line = None

        for i in xrange(len(data_files)):
            filename = data_files[i]
            label = file_labels[i]

            if line is not None:
                line += ", "
            else:
                line = ""

            line += '"{}" with linespoints title "{}" ls {}'.format(filename, label, i+1)

        f.write('plot {}'.format(line))
        
        f.write('\n\n')

    print "created {}... running gnuplot on it".format(gnuplot_filename)

    try:
        exit_code = subprocess.call(["gnuplot", gnuplot_filename])

        if exit_code != 0:
            raise RuntimeError("Gnuplot errored; exit code: " + str(exit_code))

    except OSError as e:
        raise RuntimeError("Exception while trying to run gnuplot: " + str(e))

    print "Created {}".format(eps_filename)

if __name__ == "__main__":
    main()










