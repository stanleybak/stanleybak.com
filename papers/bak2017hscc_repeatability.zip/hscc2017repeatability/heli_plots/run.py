'''
Stanley Bak
September 2016

Make helicopter plots
'''

import time
import os

from hybridpy import hypy


def get_script_path(filename=__file__):
    '''get the path this script'''
    return os.path.dirname(os.path.realpath(filename))
    
def main():
    'main function'

    run('heli_large')

    #run('heli_large_guard', "Helicopter", timeout=timeout)

def run(name):
    'main execution function'

    tools = []
    labels = []
    tool_params = []

    tools.append('spaceex')
    labels.append('supp')
    tool_params.append('-scenario supp -skiptol -flowpipe_tol 0')

    tools.append('spaceex')
    labels.append('stc')
    tool_params.append('-scenario stc -skiptol -flowpipe_tol 0')

    tools.append('hylaa')
    labels.append('Hylaa')
    image_path = get_script_path() + "/helicopter_hylaa.png" 
    tool_params.append('-settings settings.plot.plot_mode=PlotSettings.PLOT_IMAGE settings.plot.filename=\'{}\''.format(image_path))

    # flow* doesn't work! (initial states larger than example on website)
    # tools.append('flowstar')
    # labels.append('Flowstar')
    # tool_params.append('-order 3-3')

    assert len(labels) == len(tools)

    num_copies = 2
    start = time.time()
    
    for i in xrange(len(tools)):
        tool_name = tools[i]   
        label = labels[i]
 
        num_dims = 28 * num_copies + 1
        print "\nRunning {} with {} {} copies ({} dims)".format(tool_name, num_copies, name, num_dims)
        e = hypy.Engine(tool_name, tool_params[i])

        if tool_name == 'hylaa':
            out_path = 'out_hylaa.py'
        else:
            out_path = "out_{}.xml".format(label)

        e.set_output(out_path)
        e.set_input('{}.xml'.format(name))
        e.add_pass('copy', '-num {} -instance heli'.format(num_copies))

        image_path = "helicopter_{}.png".format(label)
        res = e.run(print_stdout=True, run_tool=True, image_path=image_path)

        if res['code'] != hypy.Engine.SUCCESS:
            raise RuntimeError("Hylaa Failed on {} with {} copies: {}".format(
                tool_name, num_copies, res['code']))

    dif = time.time() - start
    print "Plots Completed in {:2f} seconds".format(dif)

if __name__ == "__main__":
    main()










