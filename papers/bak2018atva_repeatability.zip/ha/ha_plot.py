'''
Harmonic Oscillator (with time) Example in Hylaa-Continuous
'''
import math

import numpy as np
from scipy.sparse import csr_matrix

from hylaa.hybrid_automaton import LinearHybridAutomaton, bounds_list_to_init
from hylaa.engine import HylaaSettings
from hylaa.engine import HylaaEngine
from hylaa.settings import PlotSettings, TimeElapseSettings
from hylaa.star import Star

def define_ha():
    '''make the hybrid automaton'''

    ha = LinearHybridAutomaton()

    # with time and affine variable
    a_matrix = np.array([[0, 1, 0, 0], [-1, 0, 0, 0], [0, 0, 0, 1], [0, 0, 0, 0]], dtype=float)
    a_matrix = csr_matrix(a_matrix, dtype=float)
    #dims = a_matrix.shape[0]

    mode = ha.new_mode('mode')
    mode.set_dynamics(a_matrix)

    #error = ha.new_mode('error')

    # x1 >= 4.0 & x1 <= 4.0
    #mat = csr_matrix(([-1, 1], [0, 0], [0, 1, 2]), dtype=float, shape=(2, dims))
    #rhs = np.array([-4.0, 4.0], dtype=float)
    #trans1 = ha.new_transition(mode, error)
    #trans1.set_guard(mat, rhs)

    return ha

def make_init_star(ha, hylaa_settings):
    '''returns a star'''

    dims = ha.modes.values()[0].a_matrix_csr.shape[0]
    bounds_list = [] # bounds on each dimension

    for dim in xrange(dims):
        if dim == 0: # x == -5
            lb = -5.0
            ub = -5.0
        elif dim == 1: # y in [0, 1]
            lb = 0
            ub = 1
        elif dim == 2: # t == 0
            lb = 0
            ub = 0
        elif dim == 3: # a == 1
            lb = 1
            ub = 1
        else:
            raise RuntimeError('Unknown dimension: {}'.format(dim))

        bounds_list.append((lb, ub))

    init_space, init_mat, init_mat_rhs, init_range_tuples = bounds_list_to_init(bounds_list)

    return Star(hylaa_settings, ha.modes['mode'], init_space, init_mat, init_mat_rhs, \
                init_range_tuples=init_range_tuples)

def define_settings():
    'get the hylaa settings object'
    plot_settings = PlotSettings()
    plot_settings.plot_mode = PlotSettings.PLOT_IMAGE
    plot_settings.xdim_dir = 0
    plot_settings.ydim_dir = 1

    # save a video file instead
    #plot_settings.make_video("vid.mp4", frames=20, fps=5)

    plot_settings.num_angles = 128
    plot_settings.max_shown_polys = 2048
    plot_settings.label.y_label = '$y$'
    plot_settings.label.x_label = '$x$'
    plot_settings.label.title = 'Reachable States'
    plot_settings.plot_size = (12, 7)
    plot_settings.label.big(size=44)
    plot_settings.grid_xtics = np.linspace(-5.0, 5.0, 11)

    plot_settings.reachable_poly_width = 4
    plot_settings.extra_lines = [[(4.0, 10.0), (4.0, -10.0)]]
    plot_settings.extra_lines_color = 'red'
    plot_settings.extra_lines_width = 3

    settings = HylaaSettings(step=math.pi/4, max_time=3 * math.pi / 4, plot_settings=plot_settings)
    #settings.simulation.sim_mode = SimulationSettings.EXP_MULT
    #settings.simulation.sim_mode = SimulationSettings.MATRIX_EXP

    #settings.simulation.guard_mode = SimulationSettings.GUARD_FULL_LP
    #settings.time_elapse.sim_mode = SimulationSettings.KRYLOV
    #settings.simulation.seperate_constant_vars = False
    #settings.simulation.pipeline_arnoldi_expm = False

    settings.time_elapse.check_answer = True

    return settings

def run_hylaa(hylaa_settings):
    'Runs hylaa with the given settings, returning the HylaaResult object.'
    ha = define_ha()
    init = make_init_star(ha, hylaa_settings)

    engine = HylaaEngine(ha, hylaa_settings)
    engine.run(init)

    return engine.result

if __name__ == '__main__':
    run_hylaa(define_settings())
