'''
3d Heat Plot Computation

This file runs the 3d heat diffusion system for various sizes, recording statistics.

The reachable states are printed to a series of .txt files in the plot/data folder,
which can be ploted with gnuplot using the plot/plot_heat.gnuplot script.

The statistics (runtime, arnoldi time, GFLOPs, ect.) are summarized at the end in the terminal.

A summary table is printed to plot/data/heat_summary.dat
'''

import time
import os
import sys

from heat3d_sym import run_hylaa

def main():
    'main entry point'

    stdout = True # print tool stdout as it runs?
    start = time.time()

    directory = './plot/data'

    # make output directory
    if not os.path.exists(directory):
        os.makedirs(directory)

    labels = []
    results = []

    summary_filename = "{}/heat_sym_summary.dat".format(directory)
    print "Writing results to {}".format(summary_filename)

    with open(summary_filename, 'w') as summary:
        for size in [10, 20, 50, 100, 200, 500, 1000]:
            result = None
            lanczos_exception = False
            skip_arnoldi = size > 200

            summary.write('{} & '.format(size))

            for use_arnoldi in [False, True]:
                label = "{} {}^3 ({} dims)".format("Arnoldi" if use_arnoldi else "Krylov", size, size**3)

                print "\nRunning {}...".format(label)
                sys.stdout.flush()

                try:
                    labels.append(label)

                    if use_arnoldi and skip_arnoldi:
                        summary.write('- \\\\\n')
                    else:
                        
                        result = run_hylaa(size, stdout, use_arnoldi)

                        results.append(result)
                        runtime = result.top_level_timer.total_secs

                        runtime_str = runtime_string(runtime)

                        
                        print "Runtime: {}".format(runtime_str)

                        #mem_start = result.krylov_stats['arnoldi_mem_start']
                        #mem_max = result.krylov_stats['arnoldi_mem_choose']
                        #gb_used = (mem_start - mem_max) / 1024.0

                        #print "GB Used: {:.3f} GB".format(gb_used)
                        #if gb_used < 0.1:
                        #    summary.write('<0.1 GB & ')
                        #else:
                        #    summary.write('{:.1f} GB & '.format(gb_used))

                        # t_max and a
                        if not use_arnoldi:
                            poly_data = result.reachable_poly_data
                            summary.write('{:.5f} & '.format(get_max_temp(poly_data)))

                            arnoldi_it = result.krylov_stats['arnoldi_iter'][0]
                            summary.write('{} & '.format(arnoldi_it))

                        summary.write('{}'.format(runtime_str))

                        if not use_arnoldi:
                            summary.write(' & ')
                        else:
                            summary.write(' \\\\\n')

                    summary.flush()

                except MemoryError as e:
                    if use_arnoldi:
                        summary.write('- & - & - & - & ')
                        skip_arnoldi = True
                    else:
                        lanczos_exception = True

                    print "MemoryError during measurement: {}, use_arnoldi = {}".format(e, use_arnoldi)

            if lanczos_exception: # stop measuring
                break

    diff = time.time() - start
    print "\n\nTotal measurement runtime: {:.2f} min".format(diff / 60.0)

def runtime_string(secs):
    'convert a float of seconds into a string for the table'

    rv = ""

    if secs < 60:
        rv = "{:.1f}s".format(secs)
    elif secs < 60 * 60:
        mins = secs / 60.0
        rv = "{}m{}s".format(int(mins), int(secs) % 60)
    else:
        mins = secs / 60.0
        hours = mins / 60.0
        rv = "{}h{}m".format(int(hours), int(mins) % 60)
        
    return rv

def get_max_temp(poly_data):
    'get the maximum temperature (y axis) from a poly_data object in the computation result'

    max_y = -9999

    # data
    for _, data in poly_data.iteritems():
        _, _, polys = data

        #[-3, 0; -3, 1; -4, 1; -3.5 0.5;-4, 0]
        for poly in polys:
            for pt in poly:
                max_y = max(max_y, pt[1])

    return max_y

if __name__ == '__main__':
    main()
