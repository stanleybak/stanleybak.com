'''
3d Heat Plot Computation

This file runs the 3d heat diffusion system for various sizes, recording statistics.

The reachable states are printed to a series of .txt files in the plot/data folder,
which can be ploted with gnuplot using the plot/plot_heat.gnuplot script.

A summary table is printed to plot/data/heat_summary.dat
'''

import time
import os
import sys

from heat3d import run_hylaa

def main():
    'main entry point'

    # expected runtime: <1 hour
    stdout = True # print tool stdout as it runs?
    start = time.time()

    directory = './plot/data'

    # make output directory
    if not os.path.exists(directory):
        os.makedirs(directory)

    labels = []
    results = []

    summary_filename = "{}/heat_summary.dat".format(directory)

    with open(summary_filename, 'w') as summary:

        for size in [50, 100]:
            result = None

            label = "{}x{}x{} ({} dims)".format(size, size, size, size**3)

            print "\nRunning {}...".format(label)
            sys.stdout.flush()

            result = run_hylaa(size, stdout)

            results.append(result)
            labels.append(label)

            runtime = result.top_level_timer.total_secs
            runtime_str = runtime_string(runtime)

            print "Runtime: {} ({:.1f}sec)".format(runtime_str, runtime)

            # print size column
            summary.write('{} & '.format(size))

            # max temp column
            poly_data = result.reachable_poly_data
            summary.write('{:.4f} & '.format(get_max_temp(poly_data)))

            # arnoldi iterations column
            arnoldi_it = result.krylov_stats['arnoldi_iter'][0]
            summary.write('{} & '.format(arnoldi_it))

            # print runtime
            summary.write('{}'.format(runtime_str))

            summary.write(' \\\\\n')
            summary.flush()

    # print all the results
    for i in xrange(len(results)):
        print "{}, total time: {}".format(labels[i], results[i].top_level_timer.total_secs)

    diff = time.time() - start
    print "\n\nTotal measurement runtime: {:.2f} min".format(diff / 60.0)

def runtime_string(secs):
    'convert a float of seconds into a string for the table'

    rv = ""

    if secs < 60:
        rv = "{:.1f}s".format(secs)
    elif secs < 60 * 60:
        mins = secs / 60.0
        rv = "{}m{}s".format(int(mins), int(secs) % 60)
    else:
        mins = secs / 60.0
        hours = mins / 60.0
        rv = "{}h{}m".format(int(hours), int(mins) % 60)

    return rv

def get_max_temp(poly_data):
    'get the maximum temperature (y axis) from a poly_data object in the computation result'

    max_y = -9999

    # data
    for _, data in poly_data.iteritems():
        _, _, polys = data

        #[-3, 0; -3, 1; -4, 1; -3.5 0.5;-4, 0]
        for poly in polys:
            for pt in poly:
                max_y = max(max_y, pt[1])

    return max_y


if __name__ == '__main__':
    main()
