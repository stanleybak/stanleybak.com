set terminal pngcairo size 1100,600 font 'Verdana,26' fontscale 1.0

# buffer is 220 on left, 80 on right, 230 total
set lmargin at screen 220.0/1100
set rmargin at screen 1020.0/1100

set xrange [0:50]

set title '3D Heat Diffusion' font 'Verdana,38' offset 0,-1
set xlabel "Time"
set ylabel "Temperature at Center"

set output "heat_reach.png"
set style fill solid 1.0 noborder
#unset border
#unset xtics
#unset ytics

set key bottom right

red = 100
green = 50

red_filename = sprintf("data/polydata%d.dat", red)
green_filename = sprintf("data/polydata%d.dat", green)

red_title = sprintf("%dx%dx%d grid", red, red, red)
green_title = sprintf("%dx%dx%d grid", green, green, green)

stats red_filename nooutput
blocks_red = STATS_blocks

stats green_filename nooutp
blocks_green = STATS_blocks


plot for [i=0:blocks_green-1] green_filename index i with lines lc rgb "#800ff00" notitle, \
    green_filename index 0 with filledcurves lc rgb "#400ff00" title green_title, \
    for [i=0:blocks_red-1] red_filename index i with lines lc rgb "#8ff00000" notitle, \
    red_filename index 0 with filledcurves lc rgb "#4ff00000" title red_title, 
