'''
Replicated Helicopter Computation

Running this file runs the model for both the i=8h and i=8 cases,
increasing h exponentially, until a time bound is exceeded

The results are printed to a series of .dat files in the plot/data folder,
which can be ploted with gnuplot using the plot/plot_heli.gnuplot script
'''

try:
    from hylaa.settings import TimeElapseSettings
except ImportError:
    raise RuntimeError("Hylaa was not installed or PYTHONPATH didn't include it")

try:
    from hybridpy import hypy
except ImportError:
    raise RuntimeError("Hypy (from Hyst) was not installed or PYTHONPATH didn't include it (needed to run SpaceEx)")

import traceback
import sys
import time
import os
import math

from replicated_heli import run_hylaa

def main():
    'main entry point'

    stdout = False # print tool stdout as it runs?
    timeout = 3600 # max runtime in seconds. For a short run, use a timeout of 15 seconds (should take about 8 mins)
    # long run (timeout = 3600) takes XYZ
    start = time.time()

    plot_directory = './plot/data'
    models_directory = './plot/spaceex_models'

    # summary: Dims & SpaceEx & Basic & RK45 & Krylov
    # individual: Dims \t Runtime

    # make output directories
    for directory in [plot_directory, models_directory]:
        if not os.path.exists(directory):
            os.makedirs(directory)

    tools = ["krylov"] # update manually one by one. Options: 'spaceex', 'hylaa', 'rk45', 'krylov'

    for tool in tools:
        method = None
        full_io_space = False

        if tool == "hylaa":
            full_io_space = True

        if tool == "rk45" or tool == "hylaa":
            method = TimeElapseSettings.SCIPY_SIM
        elif tool == "krylov":
            method = TimeElapseSettings.KRYLOV

        filename = "{}/{}.dat".format(plot_directory, tool)

        if method is not None:
            measure_hylaa(filename, timeout, stdout, method, full_io_space)
        else:
            measure_spaceex(models_directory, filename, timeout, stdout)

    diff = time.time() - start
    print "Total measurement time: {:.2f} min".format(diff / 60.0)

def make_directions(num_copies):
    'make the directions string'

    s = "x8"

    for i in xrange(1, num_copies):
        s += " + copy{}_x8".format(i+1)

    return s

def make_forbidden(num_copies):
    'make the forbidden string'

    s = "x8"

    for i in xrange(1, num_copies):
        s += " + copy{}_x8".format(i+1)

    return s + " >= {}".format(num_copies * 0.45)

def run_spaceex(models_directory, num_copies, stdout, timeout):
    'run spaceex with replicated helicopter and return the runtime'

    tool_param = "-scenario stc -skiptol -output-format none " + \
        '-aggregation none -flowpipe_tol {} -directions "{{ {} <= 0 }}" -forbidden "{}"'.format( \
            num_copies * 0.1188, make_directions(num_copies), make_forbidden(num_copies))

    e = hypy.Engine('spaceex', tool_param)
    filename = models_directory + "/heli_{}.xml".format(num_copies)
    e.set_output(filename)
    e.set_input('heli_large.xml')
    e.add_pass('copy', '-num {} -instance heli'.format(num_copies))

    # use 2*timeout here
    res = e.run(print_stdout=stdout, save_stdout=True, timeout=2*timeout, run_tool=True)

    if res['code'] != hypy.Engine.SUCCESS:
        print "SpaceEx with copies {} had exit code {}".format(num_copies, res['code'])
        runtime = None
    else:
        runtime = res['tool_time']

    return runtime

def measure_spaceex(models_directory, filename, timeout, stdout):
    'run a spaceex measurement with the given settings, outputs .dat file'

    h = 1
    runtime = 0

    with open(filename, "w") as f:
        while runtime < timeout:
            print "\nComputing SpaceEx, with {} helicopters ({} dims)".format(h, 28*h)
            sys.stdout.flush()

            try:
                runtime = run_spaceex(models_directory, h, stdout, timeout)

                if runtime is None:
                    print "SpaceEx error (runtime was None)"
                    break

                print "SpaceEx Runtime: {:.3f} sec".format(runtime)
                sys.stdout.flush()
 
                f.write("{}\t{}\n".format(28*h, runtime))
                f.flush()

            except Exception as e:
                print "SpaceEx has exception during measurement: {}".format(e)

                traceback.print_exc(file=sys.stdout)
                break

            h = int(math.ceil(1.4 * h))

def measure_hylaa(filename, timeout, stdout, method, full_io_space):
    'run a hylaa measurement with the given settings, outputs the .dat file'

    use_safe = True
    runtime = 0
    h = 1

    repeat_trials = 7 # number of trials to take median of if runtime is small
    repeat_time_cutoff = 3.0

    print "\n--------------------\nRunning measurements for {} (timeout={:.1f} min)".format(filename, timeout / 60.0)

    with open(filename, "w") as f:
        while runtime < timeout:
            print "\nComputing {}, with {} helicopters ({} dims)".format(filename, h, 28*h)
            sys.stdout.flush()

            try:
                runtimes = []

                for trial in xrange(repeat_trials):
                    result = run_hylaa(use_safe, h, full_io_space, method, stdout)

                    if result.safe != use_safe:
                        print "ERROR: Incorrect result, expected safe={}".format(use_safe)
                        exit(1)

                    runtime = result.top_level_timer.total_secs
                    arnoldi = 0 if method != TimeElapseSettings.KRYLOV else \
                                    result.top_level_timer.get_children_recursive('arnoldi')[0].total_secs

                    timer_list = result.top_level_timer.get_children_recursive('get_optimized_lp_solution')

                    if len(timer_list) == 0:
                        timer_list = result.top_level_timer.get_children_recursive("lp minimize")

                    lp = timer_list[0].total_secs
                    runtimes.append(runtime)

                    if trial == 0:
                        print "LP Time: {:.2f} sec".format(lp)

                        if method == TimeElapseSettings.KRYLOV:
                            print "Used Arnoldi Iter: {}, Arnoldi Time: {:.2f} sec".format(\
                                result.krylov_stats['arnoldi_iter'][0], arnoldi)

                    if h > 1 and trial == 0 and runtime > repeat_time_cutoff: # runtime is large enough, don't average
                        break

                    print "Runtime ({}/{}): {:.3f} sec".format(trial+1, repeat_trials, runtime)
                    sys.stdout.flush()

                if len(runtimes) > 4:
                    runtimes.sort()
                    runtimes = runtimes[2:-2] # pop off first two and last two

                avg_runtime = sum(runtimes) / float(len(runtimes))

                print "Averaged Runtime: {:.3f} sec".format(avg_runtime)
                sys.stdout.flush()
     
                f.write("{}\t{}\n".format(28*h, avg_runtime))
                f.flush()

            except Exception as e:
                print "Exception during measurement: {}".format(e)

                traceback.print_exc(file=sys.stdout)
                break

            h = int(math.ceil(1.4 * h))

if __name__ == '__main__':
    main()
