'''
Modal Analysis System Computation

Running this file runs both the safe and unsafe versions of the MNA5 system,
processes the result and both prints it to the terminal as well as to result_safe.txt and result_unsafe.txt.
'''

from mna5 import run_hylaa

def main():
    'main entry point'

    print "Running MNA5 measurements (expected time: <30 seconds)"

    safe_result = run_hylaa(safe=True)
    unsafe_result = run_hylaa(safe=False)

    print "\n\nDone, printing results..."

    print_result(safe_result, 'result_safe.txt')
    print_result(unsafe_result, 'result_unsafe.txt')

def print_result(result, filename):
    'print a verification result object to the screen and the given filename'

    print "\nWriting results to {}".format(filename)

    with open(filename, 'w') as f:

        line = "Verification Result: {}\n".format("safe" if result.safe else "unsafe")
        f.write(line)
        print line,

        line = "Total Time: {:.3f} secs\n".format(result.top_level_timer.total_secs)
        f.write(line)
        print line,

        line = "Arnoldi Iterations: {}\n".format(result.krylov_stats['arnoldi_iter'][1])
        f.write(line)
        print line,

        if not result.safe:
            from counterexample import check_instance

            print "Checking Counter-example..."
            trace_data = check_instance(stdout=False, skip_plot=True)

            line = "Counter-example Time: {}\n".format(trace_data.sim_time)
            f.write(line)
            print line,

            line = "Counter-example Rel-Error: {}\n".format(trace_data.rel_error)
            f.write(line)
            print line,

if __name__ == '__main__':
    main()










