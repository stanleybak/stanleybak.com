
ymax = 800
unset label
set xtic auto
set ytic auto
set xlabel "Number of Instances Verified" offset 0,0.5

set style line 1 lc rgb "#ff4040" lw 4.5 dt 2
set style line 2 lc rgb "#0000FF" lw 2.0 dt 4

set style line 3 lc rgb "#00E0E0" lw 2.0 dt 6
set style line 4 lc rgb "#00A000" lw 5.5 dt 8
set style line 5 lc rgb "#ef8d00" lw 3.0 dt 5

set style line 8 lc rgb "#000000" lw 2.0
set style line 9 lc rgb "#808080" lw 2.0 pt 13 ps 0.8 dt 2

set key on bottom right

#set logscale x
set logscale y
#set format x "10^{%L}"

outputs = 'other_tools14.pdf other_tools24.pdf prefilter.pdf eager.pdf contract.pdf dfs_bfs.pdf'

input_list = "'marabou nnv-exact multibfs reluval' 'marabou24 nnv-exact24 multibfs24 reluval24' 'copy bounds sim zono zonosim' 'zonosim eager' 'eager contractlp contract' 'bfs copy'"

pretty_input_list = "\"'Marabou' 'NNV (Exact)' 'Our Method' Neurify\" \"'Marabou' 'NNV (Exact)' 'Our Method' Neurify\" 'Copy Bounds Sim Zono-Bounds Zono-Sim' 'Noneager Eager' '\"No Contract\" \"Contract-LP\" \"Contract-Simple\"' '\"Breadth-First Search\" \"Depth-First Search\"'"

title_list = "'Properties 1-4' 'Properties 2-4' 'Prefilter Type' 'Eager vs Noneager Bounds' 'Zonotope Domain Contraction' 'Local Search Type'"

xmax_list = '180 135 180 180 180 180'
ymin_list = '0.02 0.02 0.5 0.5 0.5 0.5'

all_instances_y_list = '55 20 510 55 55 55'

ratio_list = '0.7 0.7 0.5 0.7 0.7 0.5'
sizex_list = '3.8 3.8 5 3.8 3.8 5'
sizey_list = '3 3 3 3 3 3'

time_label_offset_list = '2.7 2.7 1.5 2.7 2.7 1.5'

do for [index=1:words(outputs)] {
	
input_str = word(input_list, index)
pretty_input_str = word(pretty_input_list, index)
num_inputs = words(input_str)
title_str = word(title_list, index)
xmax_str = word(xmax_list, index)
ymin_str = word(ymin_list, index)
all_instances_y_str = word(all_instances_y_list, index)
ratio_str = word(ratio_list, index)
size_xstr = word(sizex_list, index)
size_ystr = word(sizey_list, index)
time_label_offset_str = word(time_label_offset_list, index)

set terminal pdfcairo enhanced dashed font 'Verdana,18' fontscale 0.45 dl 0.4 size size_xstr, size_ystr
set lmargin at screen 0.12
set bmargin at screen 0.15
set tmargin at screen 0.9
set rmargin at screen 0.98
set size ratio ratio_str

set ylabel "Time (sec)" offset time_label_offset_str,0

xmax = int(xmax_str)
xmax_plot = xmax + 4
set xrange [0:xmax_plot]

set yrange [ymin_str:ymax]

# outfile = sprintf('animation/bessel%03.0f.png',t)
set output word(outputs, index)

set title title_str font 'Verdana,28' offset 0,-1

set arrow 50 from 0, 60 to xmax, 60 nohead ls 9
set label 21 "One Minute" at 3,60 font 'Verdana,14' tc rgb "#808080" offset 0, -0.4

set arrow 51 from 0, 600 to xmax, 600 nohead ls 9
set label 22 "Ten Minutes" at 3,600 font 'Verdana,14' tc rgb "#808080" offset 0, -0.4

set arrow 52 from xmax, ymin_str to xmax, ymax nohead ls 8 
all_instances_y = int(all_instances_y_str)
set label 24 "All Instances" at xmax,all_instances_y font 'Verdana,14' tc rgb "#000000" offset -1, 0 rotate right

set grid ytics lc '#606060' lw 0.25 lt 1 dt 3
set grid xtics lc '#606060' lw 0.25 lt 1 dt 3

plot for [i=1:num_inputs] "results/".word(input_str, i)."_accumulated.dat" using 2:1 title word(pretty_input_str, i) with lines ls (i)
    
unset arrow 50
unset arrow 51
unset arrow 52
    
}

