'''
Computation Settings. Change settings by assigning directly to the class attributes.

For example:
Settings.TIMEOUT = 10
'''

import os

from nnstar.util import FreezableMeta
from nnstar.lpinstance import SwigArray

class Settings(metaclass=FreezableMeta):
    '''enumeration settings. Access these using, for example, Settings.TIMEOUT

    These get initialized by the metaclass to the values in the reset() class method.
    '''

    @classmethod
    def reset(cls):
        'assign default settings'

        # settings / optimizations
        cls.NUM_PROCESSES = len(os.sched_getaffinity(0)) # use multiple cores
        cls.TIMEOUT = None # verification timeout, in seconds (None = no timeout)

        cls.PRINT_OUTPUT = True # print to stdout?

        cls.RESULT_SAVE_POLYS = False # save 2-d projections of output polygons to Result.polys?
        cls.RESULT_SAVE_POLYS_DIMS = (0, 1) # (x_dim, y_dim) of 2-d projections, used if RESULT_SAVE_POLYGONS is True

        cls.RESULT_SAVE_CONCRETE_INPUTS = False # save concrete input points that go down each branch to Result.cinputs?

        cls.RESULT_SAVE_OUTPUT_RANGES = False # save min/max of each output to Result.output_min and output_max?

        cls.RESULT_SAVE_STARS = False # save LpStar objects in result?

        cls.RESULT_SAVE_TIMERS = [] # list of timers to record in Result.output_timers; TIMING_STATS must be True

        #########################
        ### advanced settings ###
        cls.PRINT_INTERVAL = 0.1 # print interval in seconds (0 = no printing)
        cls.TIMING_STATS = False # compute and print detailed timing stats

        cls.UPDATE_SHARED_VARS_INTERVAL = 0.05 # interval for each thread to update shared state

        cls.USE_PRESOLVER = True # try overapprox analysis first when doing verification?
        cls.PRESOLVER_ONLY = False # only use the presolver (skip enumeration)?

        # prefilter logic can speed up decisions on whether to split (for example, in ReLU layers)
        cls.TYPE_COPY_PREFILTER, cls.TYPE_NO_PREFILTER, cls.TYPE_SIM_PREFILTER, cls.TYPE_ZONO_PREFILTER = range(4)
        # Prefilter types:
        # copy prefilter: copy star lp, add constraints, and check for feasibility
        # no prefilter: compute lower and upper bounds
        # sim prefilter: keep track of simulation, and compute one of lower or upper bound first based on sim
        # zono prefilter: keep track of zonotope, and use sim or no prefilter only when zono detects splits
        
        cls.PREFILTER_TYPE = cls.TYPE_ZONO_PREFILTER # the prefilter type to use (a TYPE_ constant)

        cls.PREFILTER_EAGER_BOUNDS = True # compute all the bounds before enumerating outputs and splitting stars?

        cls.ZONO_PREFILTER_USE_SIM = True # when using zono prefiler, should the exact analysis use sim prefilter?

        cls.USE_SIMULATION_TO_PICK_DFS_BRANCH = False # when splitting, pick the branch closest to violation?

        cls.COMPRESS_INPUTS = True # removes constant inputs from lp solving
        
        cls.CONTRACT_ZONOTOPE = True # try domain contraction on zonotopes (more accurate prefilter, but slower)
        cls.CONTRACT_ZONOTOPE_LP = False # contract zonotope using LPs (even more accurate prefilter, but even slower)

        cls.PRESOLVER_BEST_AREA_ZONO = True # use best area zonotope
        cls.PRESOLVER_INTERVAL_ZONO = True # use interval zonotope
        cls.PRESOLVER_YBLOAT_ZONO = True # use y-direction zonotope
        cls.PRESOLVER_USE_LAYER_BOUNDS_OPT = True # best layer bounds for tightening instead of individual zono bounds
        cls.PRESOLVER_LP = False # use lp at intermediate steps for ranges (slower, more accurate)

        cls.RESULT_SAVE_POLYS_EPSILON = 1e-7 # accuracy of vertices when projecting polygons for Kamenev method

        cls.LOCAL_DFS = True # locally, explore states using a depth-first search
        cls.OFFLOAD_CLOSEST_TO_ROOT = True # when offloading work to other threads, use stars closest to root of search

        cls.SPLIT_TOLERANCE = 1e-8 # small outputs get rounded to zero when deciding if splitting is possible
        cls.TEST_FUNC_BEFORE_ASSIGNMENT = None # function to call before eager assignement, used for unit testing

        # default leak memory limits for SwigArray
        SwigArray.WARN_MEMORY_SWIGLPK_LEAK_GB = 4.0
        SwigArray.ERROR_MEMORY_SWIGLPK_LEAK_GB = 8.0
