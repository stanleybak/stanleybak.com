'''
neural network verification tests

Stanley Bak
'''

import math
from math import sin, cos

import matplotlib.pyplot as plt

import numpy as np
from nnstar.settings import Settings
from nnstar.network import weights_biases_to_nn, FullyConnectedLayer, NeuralNetwork
from nnstar.enumerate import enumerate_network
from nnstar import network
from nnstar import util
from nnstar.specification import Specification

def setup_function(_):
    '''setup method for each test'''

    Settings.reset()
    Settings.NUM_PROCESSES = 1 # don't use parallelism during tests unless explicitly stated

def test_identity_single():
    'test identity neural network'

    input_box = [[1, 2], [3, 4]]

    weights = [[[1, 0], [0, 1]]]
    biases = [[0, 0]]

    nn = weights_biases_to_nn(weights, biases)

    Settings.RESULT_SAVE_POLYS = True
    result = enumerate_network(input_box, nn)

    assert result.result_str != 'error'
    assert len(result.polys) == 1
    
    util.assert_verts_equals(result.polys[0], [[1, 3], [2, 3], [1, 4], [2, 4]])

def test_identity_2layer():
    'test 2-layer identity neural network'

    input_box = [[1, 2], [3, 4]]

    weights = np.array([[[1, 0], [0, 1]], [[1, 0], [0, 1]]], dtype=float)
    biases = np.array([[0, 0], [0, 0]], dtype=float)

    nn = weights_biases_to_nn(weights, biases)
    Settings.RESULT_SAVE_STARS = True
    result = enumerate_network(input_box, nn)
    assert len(result.stars) == 1
    lp_star = result.stars[0]

    verts = lp_star.verts()

    util.assert_verts_equals(verts, [[1, 3], [2, 3], [1, 4], [2, 4]])

def test_bias():
    'test bias w/ identity network'

    input_box = [[1, 2], [3, 4]]

    weights = np.array([[[1, 0], [0, 1]], [[1, 0], [0, 1]]], dtype=float)
    biases = np.array([[0.1, 0], [0.5, 1]], dtype=float)

    nn = weights_biases_to_nn(weights, biases)
    Settings.RESULT_SAVE_STARS = True
    result = enumerate_network(input_box, nn)
    assert len(result.stars) == 1
    lp_star = result.stars[0]

    verts = lp_star.verts()

    util.assert_verts_equals(verts, [[1.6, 4], [2.6, 4], [1.6, 5], [2.6, 5]])

def test_converge():
    'test 2-1 converging sum network'

    input_box = [[1, 2], [3, 4], [0, 0]]

    layer1 = [[1.0, 1.0, 0.0]]
    layer2 = [[1.0]]
    weights = [layer1, layer2]
    biases = [[0.0], [0.0]]

    nn = weights_biases_to_nn(weights, biases)
    Settings.RESULT_SAVE_STARS = True
    result = enumerate_network(input_box, nn)
    assert result.result_str == "none"
    assert len(result.stars) == 1
    lp_star = result.stars[0]

    verts = lp_star.verts(xdim=0, ydim=0)

    util.assert_verts_equals(verts, [[4, 4], [6, 6]])

def test_relu1_single():
    'test single relu behavior'

    input_box = [[-10, 10]]

    layer1 = [[1.0]]
    layer2 = [[1.0]] # output layer (no relu)
    weights = [layer1, layer2]
    biases = [[0.0], [0.0]]

    nn = weights_biases_to_nn(weights, biases)
    Settings.RESULT_SAVE_STARS = True
    result = enumerate_network(input_box, nn)
    assert len(result.stars) == 2

    util.assert_verts_equals(result.stars[0].verts(xdim=0, ydim=0), [[0, 0], [10, 10]])
    util.assert_verts_equals(result.stars[1].verts(xdim=0, ydim=0), [[0, 0]])

def test_relu_negative_midpoint():
    'test relu with a negative midpoint'

    input_box = [[-3, 1]]

    layer1 = [[1.0]]
    layer2 = [[1.0]] # output layer (no relu)
    weights = [layer1, layer2]
    biases = [[0.0], [0.0]]

    nn = weights_biases_to_nn(weights, biases)
    Settings.RESULT_SAVE_STARS = True
    result = enumerate_network(input_box, nn)
    assert result.result_str != "error"
    assert len(result.stars) == 2
    lp_star = result.stars[0]

    verts = lp_star.verts(xdim=0, ydim=0)

    util.assert_verts_equals(verts, [[0, 0], [1, 1]])

def test_bias_chain():
    'test behavior with chained bias (no splits)'

    input_box = [[1, 2]]

    layer1 = [[1.0]]
    layer2 = [[2.0]] # output layer (no relu)
    weights = [layer1, layer2]
    biases = [[5.0], [10.0]]

    nn = weights_biases_to_nn(weights, biases)
    Settings.RESULT_SAVE_STARS = True
    result = enumerate_network(input_box, nn)
    assert len(result.stars) == 1
    lp_star = result.stars[0]

    verts = lp_star.verts(xdim=0, ydim=0)

    util.assert_verts_equals(verts, [[22, 22], [24, 24]])

def test_relu1_bias():
    'test single relu behavior with bias'

    input_box = [[0, 1]]

    layer1 = [[1.0]]
    layer2 = [[1.0]] # output layer (no relu)
    weights = [layer1, layer2]
    biases = [[-0.5], [0.0]]

    nn = weights_biases_to_nn(weights, biases)
    Settings.RESULT_SAVE_STARS = True
    result = enumerate_network(input_box, nn)
    assert len(result.stars) == 2
    lp_star = result.stars[0]

    verts = lp_star.verts(xdim=0, ydim=0)

    util.assert_verts_equals(verts, [[0, 0], [0.5, 0.5]])

def test_verify_with_compressed():
    'test verification with compressed input'

    init_box = [[-2.1, -2.1], [0, 1], [2, 2]]

    layer1 = [[0.0, 1.0, 0.0]]
    layer2 = [[1.0]] # output layer (no relu)
    weights = [layer1, layer2]
    biases = [[-0.5], [0.0]]

    nn = weights_biases_to_nn(weights, biases)
    Settings.RESULT_SAVE_STARS = True
    result = enumerate_network(init_box, nn)
    assert len(result.stars) == 2
    lp_star = result.stars[0]

    verts = lp_star.verts(xdim=0, ydim=0)

    util.assert_verts_equals(verts, [[0, 0], [0.5, 0.5]])

def test_compress_inputs():
    'test compression of inputs for low-dimensional input space'

    input_box = [[2, 2], [0.5, 1], [3, 3]]

    cur_bm, cur_bias, new_input_box = util.compress_init_box(input_box)

    assert np.allclose(new_input_box, np.array([0.5, 1], dtype=float)), f"new_input_box: {new_input_box}"
    assert np.allclose(cur_bias, np.array([2, 0, 3], dtype=float))
    assert np.allclose(cur_bm, np.array([[0], [1], [0]], dtype=float))

def test_relu_equal():
    'test a single layer with an active relu and a postive value'

    init_box = [[0, 1]]

    layer1 = [[1.0], [1.0]]
    weights = [layer1, np.identity(2)]
    biases = [[-0.5, 1.0], np.zeros(2,)]

    nn = weights_biases_to_nn(weights, biases)
    Settings.RESULT_SAVE_STARS = True
    result = enumerate_network(init_box, nn)
    assert len(result.stars) == 2
    lp_star = result.stars[0]

    # test plot
    lp_star.plot()

    verts = lp_star.verts(xdim=0, ydim=1)
    # x should be [0, 0.5], y should be [1.5, 2]

    util.assert_verts_equals(verts, [[0, 1.5], [0.5, 2]])

def test_enum_mirco_no_offset():
    '''test enumerative (exact) formulation

    This uses Mirco's example"
    '''

    init_box = [[-1, 1], [-1, 1]]
    theta = math.pi/4.0
    
    layer1 = [[cos(theta), -sin(theta)], [sin(theta), cos(theta)]]
    weights = [layer1, np.identity(2)]
    biases = [[0, 0], [0, 0]]

    nn = weights_biases_to_nn(weights, biases)
    Settings.RESULT_SAVE_STARS = True
    result = enumerate_network(init_box, nn)
    assert result.result_str == "none"
    assert len(result.stars) == 4

    sqrt2 = math.sqrt(2)
    
    # first one should be x >= 0 and y >= 0
    util.assert_verts_equals(result.stars[0].verts(), [[0, 0], [sqrt2, 0], [0, sqrt2]])

    # second one should be x >= 0 and y <= 0
    util.assert_verts_equals(result.stars[1].verts(), [[0, 0], [sqrt2, 0]])

    # third one should be x <= 0 and y >= 0
    util.assert_verts_equals(result.stars[2].verts(), [[0, 0], [0, sqrt2]])

    # fourth one should be x <= 0 and y <= 0    
    util.assert_verts_equals(result.stars[3].verts(), [[0, 0]])


def test_enum_mirco_offset():
    'test from mirco discussion'

    for pf in [Settings.TYPE_COPY_PREFILTER, Settings.TYPE_NO_PREFILTER, Settings.TYPE_SIM_PREFILTER, \
               Settings.TYPE_ZONO_PREFILTER]:
        Settings.PREFILTER_TYPE = pf

        for eager in [True, False]:
            Settings.PREFILTER_EAGER_BOUNDS = eager

            init_box = [[-1, 1], [-1, 1]]
            theta = math.pi/4.0

            layer1 = [[cos(theta), -sin(theta)], [sin(theta), cos(theta)]]
            weights = [layer1, np.identity(2)]
            biases = [[-0.5, -0.5], [0, 0]]

            nn = weights_biases_to_nn(weights, biases)
            Settings.RESULT_SAVE_STARS = True
            result = enumerate_network(init_box, nn)
            assert result.result_str == "none"
            assert len(result.stars) == 4

            # expected output, x = -1 -> 1, y = 0 -> 1

            # axis
            plt.plot([-2, 2], [0, 0], 'k-')
            plt.plot([0, 0], [-2, 2], 'k-')

            for lp_star in result.stars:
                lp_star.plot('r-', lw=3)

    #plt.show()

def _disabled_test_enum_conv2d():
    'test enumeration for a single convultional2d layer'

    # example from:
    # https://medium.com/apache-mxnet/multi-channel-convolutions-explained-with-ms-excel-9bbf8eb77108

    input1 = [[1, 0, 1, 0, 2],
              [1, 1, 3, 2, 1],
              [1, 1, 0, 1, 1],
              [2, 3, 2, 1, 3],
              [0, 2, 0, 1, 0]]

    input2 = [[1, 0, 0, 1, 0],
              [2, 0, 1, 2, 0],
              [3, 1, 1, 3, 0],
              [0, 3, 0, 3, 2],
              [1, 0, 3, 2, 1]]

    input3 = [[2, 0, 1, 2, 1],
              [3, 3, 1, 3, 2],
              [2, 1, 1, 1, 0],
              [3, 1, 3, 2, 0],
              [1, 1, 2, 1, 1]]

    inputs = np.array([input1, input2, input3], dtype=float)

    # convert to y, x, z
    inputs = inputs.transpose((1, 2, 0))

    kernel1 = [[0, 1, 0], [0, 0, 2], [0, 1, 0]]
    kernel2 = [[2, 1, 0], [0, 0, 0], [0, 3, 0]]
    kernel3 = [[1, 0, 0], [1, 0, 0], [0, 0, 2]]
    kernels = np.array([[kernel1, kernel2, kernel3]], dtype=float)

    # one bias per output
    biases = np.zeros((1, ), dtype=float)
    prev_layer_output_shape = (5, 5, 3)

    layer = network.Convolutional2dLayer(0, kernels, biases, True, prev_layer_output_shape, mode='valid')

    nn = network.NeuralNetwork([layer])

    min_image = inputs
    max_image = inputs.copy()
    max_image[2, 2, 0] += 0.1 # y, x, z (channel=0)
    max_image[0, 0, 2] += 0.1 # y, x, z (channel=2)
    max_image[0, 1, 2] += 0.5 # y, x, z (channel=2)

    init_box = network.images_to_init_box(min_image, max_image)

    Settings.RESULT_SAVE_OUTPUT_RANGES = True
    res = enumerate_network(init_box, nn)

    assert res.result_str == "none"
    assert not res.result_from_presolver

    # intermediate output for first filter at max should be
    # 7   5.1 3
    # 4.2 7   5
    # 7   2.1 8

    # intermediate output for last filter at max should be
    # 7.1  5.5  2
    # 11   8    2
    # 9    4    6
    
    expected = [(19, 19.1), (28, 28.2), (23, 23),
                (13, 13.6), (16, 16), (18, 18.1),
                (15, 15), (20, 20), (25, 25)]

    #print("output ranges:")

    for i, (low, high) in enumerate(zip(res.output_min, res.output_max)):
        #print(f"{i}: [{low}, {high}]")

        assert np.allclose((low, high), expected[i]), f"expected index {i} to be {expected[i]}"

def test_with_spec():
    'test with specification'

    init_box = [[0, 1], [0, 1]]

    Settings.USE_PRESOLVER = False
    Settings.CONTRACT_ZONOTOPE = False
    Settings.PREFILTER_TYPE = Settings.TYPE_SIM_PREFILTER
    layer1 = FullyConnectedLayer(0, [[1, 1], [0, 1]], [-1, 0], True)

    # output1 will be [0, 1]
    # output2 will be [-0.5, 1.5]

    nn = NeuralNetwork([layer1])

    Settings.RESULT_SAVE_STARS = True

    # spec x + y >= 0.5
    spec = Specification([[-1, -1]], [-1.1])
    
    result = enumerate_network(init_box, nn, spec)

    assert result.result_str == "unsafe"
