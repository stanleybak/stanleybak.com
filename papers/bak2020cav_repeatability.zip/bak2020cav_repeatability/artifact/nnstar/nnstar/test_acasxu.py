'''
Full network tests using the acasxu networks
'''

from scipy.io import loadmat
import numpy as np

from nnstar.network import weights_biases_to_nn, FullyConnectedLayer
from nnstar.specification import Specification, DisjunctiveSpec
from nnstar.enumerate import enumerate_network
from nnstar.settings import Settings

def setup_function(_):
    '''setup method for each test'''

    Settings.reset()
    Settings.NUM_PROCESSES = 1 # don't use parallelism during tests unless explicitly stated

def get_init_box(property_num):
    'get lb, ub lists for the given property'

    prop_map = {} # maps prop_num -> lb_list, ub_list

    init_lb = [55947.691, -3.141593, -3.141593, 1145, 0]
    init_ub = [60760, 3.141593, 3.141593, 1200, 60]
    prop_map[1] = (init_lb, init_ub)
    prop_map[2] = (init_lb, init_ub)
        
    init_lb = [1500, -0.06, 3.1, 980, 960]
    init_ub = [1800, 0.06, 3.141593, 1200, 1200]
    prop_map[3] = (init_lb, init_ub)
    
    init_lb = [1500, -0.06, 0, 1000, 700]
    init_ub = [1800, 0.06, 0, 1200, 800]
    prop_map[4] = (init_lb, init_ub)

    init_lb = [0, -3.141593, -3.141593, 100, 0]
    init_ub = [60760, 3.141593, 3.141593, 1200, 1200]
    prop_map[7] = (init_lb, init_ub)

    return prop_map[property_num]

def get_spec(property_num):
    'get the specification'

    #labels = ['Clear of Conflict (COC)', 'Weak Left', 'Weak Right', 'Strong Left', 'Strong Right']
    spec_map = {} # maps prop_num -> Specification

    # unsafe if COC >= 1500

    # Output scaling is 373.94992 with a bias of 7.518884
    # (1500 - 7.518884) / 373.94992 = 3.991125
    spec = Specification([[-1, 0, 0, 0, 0]], [-3.991125])
    spec_map[1] = spec
        
    # unsafe if COC is maximal:
    # y0 > y1 and y0 > y1 and y0 > y2 and y0 > y3 and y0 > y4
    spec = Specification([[-1, 1, 0, 0, 0],
                          [-1, 0, 1, 0, 0],
                          [-1, 0, 0, 1, 0],
                          [-1, 0, 0, 0, 1]], [0, 0, 0, 0])
    spec_map[2] = spec
    
    # unsafe if COC is minimal score
    spec = Specification([[1, -1, 0, 0, 0],
                          [1, 0, -1, 0, 0],
                          [1, 0, 0, -1, 0],
                          [1, 0, 0, 0, -1]], [0, 0, 0, 0])
    spec_map[3] = spec
    spec_map[4] = spec
    
    # unsafe if strong left is minimial or strong right is minimal
    spec_left = Specification([[-1, 0, 0, 1, 0],
                               [0, -1, 0, 1, 0],
                               [0, 0, -1, 1, 0]], [0, 0, 0])

    spec_right = Specification([[-1, 0, 0, 0, 1],
                                [0, -1, 0, 0, 1],
                                [0, 0, -1, 0, 1]], [0, 0, 0])

    spec = DisjunctiveSpec([spec_left, spec_right])
    spec_map[7] = spec

    return spec_map[property_num]

def load_init_network(net_pair, property_num):
    '''load the network / spec and return it

    the network is based on the net_pair, using specification spec

    returns (init_box, network, spec)
    '''

    # load the network and prepare input / output specs
    n1, n2 = net_pair
    matfile = loadmat(f'../examples/networks/acasxu/ACASXU_run2a_{n1}_{n2}_batch_2000.mat')

    weights = matfile['W'][0]
    biases = matfile['b'][0]

    for b in biases:
        b.shape = (len(b),)

    range_for_scaling = matfile['range_for_scaling'][0]
    means_for_scaling = matfile['means_for_scaling'][0]

    num_inputs = weights[0].shape[1]
    init_lb, init_ub = get_init_box(property_num)

    # normalize input
    for i in range(num_inputs):
        init_lb[i] = (init_lb[i] - means_for_scaling[i]) / range_for_scaling[i]
        init_ub[i] = (init_ub[i] - means_for_scaling[i]) / range_for_scaling[i]

        #print(f"Input {i}: {init_lb[i], init_ub[i]}")

    spec = get_spec(property_num)
    
    init_box = list(zip(init_lb, init_ub))
    
    network = weights_biases_to_nn(weights, biases)

    scale_outputs = False

    if scale_outputs:
        # add one more layer to the network for the output scaling
        output_mult, output_bias = range_for_scaling[-1], means_for_scaling[-1]
        output_mult_mat = np.identity(5) * output_mult
        output_bias_vec = np.array([output_bias] * 5, dtype=float)
        layer_num = len(network.layers)
        network.layers.append(FullyConnectedLayer(layer_num, output_mult_mat, output_bias_vec, False))

    return init_box, network, spec

def test_verify_acasxu_presolver174():
    'verify acasxu network 1-7 on property 4 using presolver'

    init_box, network, spec = load_init_network((1, 7), 4)
    res = enumerate_network(init_box, network, spec)
    
    assert res.result_str == "unsafe"
    assert res.result_from_presolver

def test_verify_acasxu_enum174():
    'verify acasxu network 1-7 on property 4 using enumeration'

    init_box, network, spec = load_init_network((1, 7), 4)
    Settings.USE_PRESOLVER = False
    Settings.CONTRACT_ZONOTOPE = False
    Settings.COMPRESS_INPUTS = False
    Settings.PREFILTER_TYPE = Settings.TYPE_SIM_PREFILTER

    res = enumerate_network(init_box, network, spec)
    
    assert res.result_str == "unsafe"
    assert not res.result_from_presolver

def test_verify_acasxu_234():
    'verify acasxu network 2-3 on property 4'

    ## safe: 2-3-4 works with presolver star
    init_box, network, spec = load_init_network((2, 3), 4)
    res = enumerate_network(init_box, network, spec)
    assert res.result_str == "safe"
    assert res.result_from_presolver

def test_verify_acasxu_574():
    'verify acasxu network 5-7 on property 4'

    Settings.PREFILTER_TYPE = Settings.TYPE_ZONO_PREFILTER
    Settings.PREFILTER_EAGER_BOUNDS = False
    Settings.CONTRACT_ZONOTOPE = False
    Settings.COMPRESS_INPUTS = False

    init_box, network, spec = load_init_network((5, 7), 4)
    res = enumerate_network(init_box, network, spec)
    assert res.result_str == "safe"
    assert not res.result_from_presolver
