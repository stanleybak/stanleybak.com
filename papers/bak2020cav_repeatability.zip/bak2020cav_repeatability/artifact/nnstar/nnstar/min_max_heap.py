'''
Implementation of heap were you can pop either the largest or smallest element efficiently.

This is done using two normal heaps and a flag if an element has been removed. 
Alternatively an ordered tree could work, but python doesn't seem to have anything built in for doing this.

Stanley Bak
Dec 2019
'''

import heapq

from nnstar.util import Freezable
from nnstar.timerutil import Timers

class MinMaxHeap(Freezable):
    'heap-like data structure where min or max item can be popped efficiently'

    def __init__(self):

        # the heaps will store shallow copies of 2-lists: (item, was_popped)
        # when an item is popped, was_popped is set to true
        self.min_heap = []
        self.max_heap = []

        self.count = 0

        self.freeze_attrs()

    def push(self, item):
        'add an item'
        
        Timers.tic('min_max_heap.push')

        two_list = [item, False]

        # add it to both heaps
        heapq.heappush(self.min_heap, two_list)
        heapq.heappush(self.max_heap, MaxItem(two_list))

        self.count += 1
        Timers.toc('min_max_heap.push')

    def pop(self, want_max):
        '''pop min or max item, returns IndexError on empty'''

        Timers.tic('min_max_heap.pop')

        rv = None

        if not want_max:
            # min
            
            while rv is None:
                two_list = heapq.heappop(self.min_heap)

                if two_list[1]: # was popped already
                    continue

                two_list[1] = True # mark it as popped
                rv = two_list[0]
        else:
            # max
            
            while rv is None:
                wrapped_two_list = heapq.heappop(self.max_heap)
                two_list = wrapped_two_list.val

                if two_list[1]: # was popped already
                    continue

                two_list[1] = True # mark it as popped
                rv = two_list[0]
        
        self.count -= 1
        Timers.toc('min_max_heap.pop')

        return rv

    def __len__(self):
        'get num items'

        return self.count

class MaxItem(Freezable):
    'wrapper max heap, with <= and >= operations reversed'
    
    def __init__(self, val):
        self.val = val
        self.freeze_attrs()

    def __lt__(self, other):
        return self.val > other.val

    def __eq__(self, other):
        return self.val == other.val
