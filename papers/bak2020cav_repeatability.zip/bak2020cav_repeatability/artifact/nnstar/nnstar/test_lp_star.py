'''
tests for milp_star
'''

import numpy as np

from lp_star import LpStar
from lp_star_state import LpStarState
import util
from nnstar.settings import Settings
from nnstar.network import FullyConnectedLayer

def setup_function(_):
    '''setup method for each test'''

    Settings.reset()
    Settings.NUM_PROCESSES = 1 # don't use parallelism during tests unless explicitly stated

def test_basic_plot():
    'test basic construction and verts'

    a_mat = np.array([[1, 0], [0, 1]], dtype=float)
    a_mat_rhs = np.array([1, 0], dtype=float)

    box_bounds = [[0, 2], [0, 2]]

    lp_star = LpStar(a_mat, a_mat_rhs, box_bounds)

    _, _ = lp_star.minimize_vec(None, return_io=True)

    lp_star.plot()

    # printing should work too
    print(lp_star)

def test_no_a_mat():
    'no a matrix'

    # unit box
    box_bounds = [[0, 1], [0, 1]]

    star = LpStar(np.identity(2), np.array([0, 0], dtype=float), box_bounds)

    verts = star.verts()

    expected = [[0, 0], [0, 1], [1, 0], [1, 1]]
    util.assert_verts_equals(verts, expected)

    star.plot() # no failure

def test_lp_neg():
    '''
    tests with negative range, no zono prefilter
    '''

    box_bounds = [[-12, -10]]

    Settings.PREFILTER_TYPE = Settings.TYPE_SIM_PREFILTER
    state = LpStarState(box_bounds)

    # test string
    assert str(state) == "LpStateState at layer 0 on neuron -1 with star.a_mat.shape (1, 1)"

    assert np.allclose(state.prefilter.simulation[0], (-11, ))
    assert np.allclose(state.prefilter.simulation[1], (-11, ))

    # test heap item
    assert state.heap_item() == (0, -1, id(state), state)

    layer = FullyConnectedLayer(0, [[1], [1]], [0, -1], True)

    def test_ranges():
        'test funciton for ranges before assigning negatives to zero'

        expected_bias = [0, -1]
        assert np.allclose(state.star.bias, expected_bias)

        assert state.star.a_mat.shape == (2, 1)

        # check prefilter bounds

        expected_lb = [-np.inf, -np.inf]
        expected_ub = [-10, -11]

        assert np.allclose(state.prefilter.output_bounds.lb_min, expected_lb)
        assert np.allclose(state.prefilter.output_bounds.ub_max, expected_ub)

    Settings.TEST_FUNC_BEFORE_ASSIGNMENT = test_ranges
    
    state.transform_fully_connected(layer)

    assert np.allclose(state.prefilter.simulation[0], (-11, ))
    assert np.allclose(state.prefilter.simulation[1], (0, 0)) # sim gets zeroed if no branching

    new_star = state.execute_relus()
    
    assert new_star is None
    assert state.star.a_mat.shape == (2, 1)

    assert state.heap_item() == (1, -1, id(state), state)

    # simulation stays the same (no splitting occured)
    assert np.allclose(state.prefilter.simulation[1], (0, 0))

def test_no_relu():
    'test mult with no relu'

    box_bounds = [[-12, -10]]

    state = LpStarState(box_bounds)

    # test heap item
    assert state.heap_item() == (0, -1, id(state), state)

    layer = FullyConnectedLayer(0, [[1], [1]], [0, -1], False)
    state.transform_fully_connected(layer)

    assert state.cur_layer == 1 and state.next_neuron_index == -1

def test_simple_relu():
    'test simple relu case'

    for pf in [Settings.TYPE_SIM_PREFILTER, Settings.TYPE_ZONO_PREFILTER]:
        Settings.PREFILTER_TYPE = pf

        for eager in [True, False]:
            Settings.PREFILTER_EAGER_BOUNDS = eager

            box_bounds = [[-2, 1]]

            state = LpStarState(box_bounds)

            layer = FullyConnectedLayer(0, [[2]], [0], True)
            state.transform_fully_connected(layer)

            assert np.allclose(state.prefilter.simulation[0], (-0.5))

            if eager:
                # eager will apply relu after transformation
                assert np.allclose(state.prefilter.simulation[1], (0))
            else:
                assert np.allclose(state.prefilter.simulation[1], (-1))

            new_state = state.execute_relus()

            assert new_state is not None

            assert np.allclose(state.prefilter.simulation[0], (1, )) # positive case
            assert np.allclose(state.prefilter.simulation[1], (2, )) # positive case

            assert np.allclose(new_state.prefilter.simulation[0], (-0.5,)) # negative case
            assert np.allclose(new_state.prefilter.simulation[1], (0,)) # negative case

def test_relu_weights():
    'test more complex relu case'

    input_box = [[0, 1], [-10, 10]]
    
    ss = LpStarState()
    ss.from_init_box(input_box)

    layer = FullyConnectedLayer(0, [[2.0, 0.5], [2.0, 0.5]], [0.1, 0.1], True)
    ss.transform_fully_connected(layer)

    lb_list = ss.prefilter.output_bounds.lb_min
    ub_list = ss.prefilter.output_bounds.ub_max

    assert np.allclose(lb_list, [-4.9, -4.9])
    assert np.allclose(ub_list, [7.1, 7.1])

    ss.next_neuron_index = 0
    new_stars = ss.execute_relus()

    assert new_stars is not None
    assert ss.cur_layer == 0
    assert ss.next_neuron_index == 1

    lb_list = ss.prefilter.output_bounds.lb_min
    ub_list = ss.prefilter.output_bounds.ub_max

    assert np.allclose(lb_list, [0, 0])
    assert np.allclose(ub_list, [7.1, 7.1])

    new_stars = ss.execute_relus() 
    assert new_stars is None
    assert ss.cur_layer == 1
    assert ss.next_neuron_index == -1

    verts = ss.star.verts(xdim=0, ydim=1)
    
    assert len(verts) == 2, f"verts was {verts}"

    # negative range
    util.assert_verts_equals(verts, [[0, 0], [7.1, 7.1]])
