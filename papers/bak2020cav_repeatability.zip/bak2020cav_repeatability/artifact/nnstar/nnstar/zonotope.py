'''
Zonotope performance tests

Stanley Bak
'''

import matplotlib.pyplot as plt

import numpy as np

from nnstar.util import Freezable
from nnstar.timerutil import Timers
from nnstar import kamenev

def zono_from_compressed_init_box(init_bm, init_bias, init_box):
    '''create a Zonotope from a compressed init box (deep copy)

    parameters are those obtained from nnstar.util.compress_init_box()
    '''

    center = init_bias.copy()

    generators = []
    init_bounds = []

    for index, (lb, ub) in enumerate(init_box):
        vec = np.array([1 if d == index else 0 for d in range(len(init_box))], dtype=float)
        generators.append(vec)
        init_bounds.append((lb, ub))

    generators = np.array(generators, dtype=float)
    generators.shape = (len(init_box), len(generators))

    gen_mat_t = np.dot(init_bm, generators.transpose())

    return Zonotope(center, gen_mat_t, init_bounds)

class Zonotope(Freezable):
    'zonotope class'

    def __init__(self, center, gen_mat_t, init_bounds=None):
        '''
        gen_mat_t has one generator per COLUMN

        init_bounds for a traditional zonotope is [-1, 1]
        '''

        assert isinstance(center, np.ndarray)
        assert len(center.shape) == 1 or center.shape[0] == 1, f"Expected 1-d center, got {center.shape}"
        assert len(gen_mat_t.shape) == 2, f"expected 2-d gen_mat_t, got {gen_mat_t.shape}"
        assert isinstance(gen_mat_t, np.ndarray), f"gen_mat_t was {type(gen_mat_t)}"

        self.center = center # note: shallow copy

        if gen_mat_t.size > 0:
            assert len(self.center) == gen_mat_t.shape[0], f"center has {len(self.center)} dims but " + \
                f"gen_mat_t has {gen_mat_t.shape[0]} entries per column (rows)"

            if init_bounds is None:
                init_bounds = [(-1, 1) for _ in range(gen_mat_t.shape[0])]

            assert isinstance(init_bounds[0], tuple) # immutable

        self.mat_t = gen_mat_t # note: shallow copy

        self.pos1_gens = None #np.array(self.mat_t.shape[1] * [1.0], dtype=float)
        self.neg1_gens = None

        self.init_bounds = init_bounds # no copy either, done externally

        self.freeze_attrs()

    def __str__(self):
        return f"[Zonotope with center {self.center} and generator matrix_t:\n{self.mat_t}" + \
            f" and init_bounds: {self.init_bounds}"

    def update_init_bounds(self, i, new_bounds, skip_check=False):
        'update init bounds in the zonotope'
        
        assert isinstance(new_bounds, tuple)
        assert new_bounds[0] <= new_bounds[1], f"new bounds was: {new_bounds}"

        ep = 1e-4

        if skip_check:
            lb = new_bounds[0]
        elif new_bounds[0] != -np.inf:
            assert new_bounds[0] + ep >= self.init_bounds[i][0], f"new lower bound ({new_bounds[0]} was worse " + \
                                                             f"then before {self.init_bounds[i][0]}"

            lb = max(self.init_bounds[i][0], new_bounds[0])
        else:
            lb = self.init_bounds[i][0]

        if skip_check:
            ub = new_bounds[1]
        elif new_bounds[1] != np.inf:
            assert new_bounds[1] - ep <= self.init_bounds[i][1], f"new upper bound ({new_bounds[1]}) was worse" + \
                                                                 f"then before {self.init_bounds[i][1]}"

            ub = min(self.init_bounds[i][1], new_bounds[1])
        else:
            ub = self.init_bounds[i][1]

        if lb > ub:
            lb = ub = (lb + ub) / 2.0

        self.init_bounds[i] = (lb, ub)

        # update these
        if self.neg1_gens is not None:
            self.neg1_gens[i] = lb
            self.pos1_gens[i] = ub

    def maximize(self, vector):
        'get the maximum point of the zonotope in the passed-in direction'

        Timers.tic('zonotope.maximize')

        rv = self.center.copy()

        # project vector (a generator) onto row, to check if it's positive or negative
        res_vec = np.dot(self.mat_t.transpose(), vector) # slow? since we're taking transpose

        for res, row, ib in zip(res_vec, self.mat_t.transpose(), self.init_bounds):
            factor = ib[1] if res >= 0 else ib[0]

            rv += factor * row

        Timers.toc('zonotope.maximize')

        return rv

    def box_bounds(self):
        'compute box bounds for the zonotope'

        dims = len(self.center)

        # these are outer bounds, so they start out pessimistic
        lb_list = [-np.inf] * dims
        ub_list = [np.inf] * dims

        self.update_output_bounds(lb_list, ub_list, 0)

        return list(zip(lb_list, ub_list))

    def get_single_output_bounds(self, index):
        'get the lb and ub for a single output'

        lb = ub = self.center[index]

        if self.mat_t.size > 0:
            for col in range(self.mat_t.shape[1]):
                val = self.mat_t[index, col]

                option1 = val * self.init_bounds[col][0]
                option2 = val * self.init_bounds[col][1]

                if option1 < option2:
                    lb += option1
                    ub += option2
                else:
                    lb += option2
                    ub += option1

        return lb, ub

    def update_output_bounds(self, lb_list, ub_list, start_index, end_index=None):
        '''
        update the passed-in bounds using the zonotope outer approximation. 

        this will only update outputs >= start_index where this only updates where
        the existing bounds overlap zero. 
        '''

        Timers.tic('zono.update_output_bounds')

        assert isinstance(start_index, int)

        size = self.center.size

        if end_index is None:
            assert len(lb_list) == size
            assert len(ub_list) == size

        if self.mat_t.size == 0:
            # no generators
            for i in range(start_index, size):
                if i == end_index:
                    break
                
                lb_list[i] = ub_list[i] = self.center[i]
        else:

            # pos_1_gens may need to be updated if matrix size changed due to assignment
            if self.pos1_gens is None or self.pos1_gens.shape[0] != self.mat_t.shape[1]:
                self.neg1_gens = np.array([i[0] for i in self.init_bounds], dtype=float)
                self.pos1_gens = np.array([i[1] for i in self.init_bounds], dtype=float)

                assert self.pos1_gens.shape[0] == self.mat_t.shape[1]

            mat_t = []
            row_numbers = []

            for i in range(start_index, size):
                if i == end_index:
                    break
                
                if lb_list[i] < 0 < ub_list[i]:
                    mat_t.append(self.mat_t[i])
                    row_numbers.append(i)

            mat_t = np.array(mat_t, dtype=float)

            if mat_t.shape[0] > 0:
                expected_shape = (len(row_numbers), self.mat_t.shape[1])
                assert mat_t.shape == expected_shape, f"mat_t.shape = {mat_t.shape}, expected {expected_shape}"

                pos_mat = np.clip(mat_t, 0, np.inf)
                neg_mat = np.clip(mat_t, -np.inf, 0)

                pos_pos = np.dot(self.pos1_gens, pos_mat.T)
                neg_neg = np.dot(self.neg1_gens, neg_mat.T)
                pos_neg = np.dot(self.pos1_gens, neg_mat.T)
                neg_pos = np.dot(self.neg1_gens, pos_mat.T)

                for i, pp_row, nn_row, pn_row, np_row in zip(row_numbers, pos_pos, neg_neg, pos_neg, neg_pos):
                    ub = pp_row + nn_row
                    lb = pn_row + np_row
                    c = self.center[i]

                    # these are outer bounds, so take the tighest one possible
                    lb_list[i] = c + lb
                    ub_list[i] = c + ub
                    #lb_list[i] = max(lb_list[i], c + lb)
                    #ub_list[i] = min(ub_list[i], c + ub)

        Timers.toc('zono.update_output_bounds')

    def contract_domain(self, hyperplane_vec, rhs):
        'this adjusts bounds based on contract-simple strategy'

        tuple_list = self.contract_domain_new(hyperplane_vec, rhs)

        for d, lb, ub in tuple_list:
            self.update_init_bounds(d, (lb, ub))

    def contract_domain_new(self, hyperplane_vec, rhs):
        '''intersect the initial box with the given halfspace, trying to shrink it

        returns a list of 3-tuples for each of the bounds that was adjusted:
        (dim, lb, ub)
        '''

        rv = []

        Timers.tic('contract domain')

        if not isinstance(hyperplane_vec, np.ndarray):
            hyperplane_vec = np.array(hyperplane_vec, dtype=float)

        dims = len(self.init_bounds)

        assert len(hyperplane_vec) == dims, f"dims in init_bounds is {dims}, hyperplane dims is {len(hyperplane_vec)}"
        ib = self.init_bounds

        sat_corner_list = [ib[d][0] if hyperplane_vec[d] > 0 else ib[d][1] for d in range(dims)]
        #sat_corner = np.array(sat_corner_list, dtype=float)
        unsat_corner_list = [ib[d][1] if hyperplane_vec[d] > 0 else ib[d][0] for d in range(dims)]
        #unsat_corner = np.array(unsat_corner_list, dtype=float)

        # construct matrix of sat corners
        sat_corner_matrix = np.array([sat_corner_list] * dims, dtype=float)

        for d in range(dims):
            sat_corner_matrix[d, d] = unsat_corner_list[d]

        # do it as matrix-vec mult
        dot_res = sat_corner_matrix.dot(hyperplane_vec)
        
        for d in range(dims):
            # make sure it's nonzero

            # todo: test the effect of removing this? division by k... better to keep here
            if abs(hyperplane_vec[d]) < 1e-6:
                continue

            #old_sat_corner_d = sat_corner[d]
            #sat_corner[d] = unsat_corner[d]

            # sat_corner is now potentially unsat
            #lhs = np.dot(sat_corner, hyperplane_vec)
            lhs = dot_res[d]
            
            if lhs > rhs:
                # constraint is tighter! find the new bound
                #sat_corner[d] = 0
                #tot = np.dot(sat_corner, hyperplane_vec)
                tot = lhs - unsat_corner_list[d] * hyperplane_vec[d]

                k = hyperplane_vec[d]
                solved_rhs = (rhs - tot) / k

                if k > 0:
                    # change ub to solved_rhs
                    rv.append((d, ib[d][0], solved_rhs))
                else:
                    # change lb to solved_rhs
                    rv.append((d, solved_rhs, ib[d][1]))

            # restore sat_corner[d]
            #sat_corner[d] = old_sat_corner_d
                        
        Timers.toc('contract domain')

        return rv

    def verts(self, xdim=0, ydim=1, epsilon=1e-7):
        'get verts'

        dims = len(self.center)

        assert 0 <= xdim < dims, f"xdim was {xdim}, but num zonotope dims was {dims}"
        assert 0 <= ydim < dims, f"ydim was {ydim}, but num zonotope dims was {dims}"

        def max_func(vec):
            'projected max func for kamenev'

            max_vec = [0] * dims
            max_vec[xdim] += vec[0]
            max_vec[ydim] += vec[1]
            max_vec = np.array(max_vec, dtype=float)

            res = self.maximize(max_vec)

            return np.array([res[xdim], res[ydim]], dtype=float)

        return kamenev.get_verts(2, max_func, epsilon=epsilon)

    def plot(self, color='k-o', lw=1, xdim=0, ydim=1, epsilon=1e-7):
        'use matplotlib to plot this lp_star'

        verts = self.verts(xdim=xdim, ydim=ydim, epsilon=epsilon)

        xs, ys = zip(*verts)
        plt.plot(xs, ys, color, lw=lw)
