'''
Stanley Bak

Enmeration functions for Neural Network Analysis

the method you probably want to use is enumerate_network()
'''

import multiprocessing
import time
import queue
import traceback
import math

import numpy as np

from nnstar.timerutil import Timers
from nnstar.lp_star_state import LpStarState
from nnstar.util import Freezable, FakeQueue
from nnstar.settings import Settings
from nnstar.result import Result
from nnstar.network import NeuralNetwork
from nnstar.min_max_heap import MinMaxHeap
from nnstar import presolver

def enumerate_network(init_box, network, spec=None):
    '''enumerate the branches in the network

    settings are controlled by assigning directly to the class Settings, for example "Settings.timeout = 10"
    if spec is not None, a verification problem will be considered for the provided Specification object

    the output is an instance of Result
    '''

    assert not Settings.RESULT_SAVE_TIMERS or Settings.TIMING_STATS, \
        "RESULT_SAVE_TIMERS cannot be used if TIMING_STATS is False"

    if not Settings.TIMING_STATS:
        Timers.disable()

    Timers.tic('enumerate_network')
    start = time.perf_counter()

    rv = None

    # only use presolver if it's a verification query
    if spec is not None and Settings.USE_PRESOLVER:
        
        rv = presolver.verify(init_box, network, spec)
        rv.result_from_presolver = True

        if rv.result_str == "none" and not Settings.PRESOLVER_ONLY:
            rv = None # do full analysis, reinitializes the result object

    if rv is None:
        num_workers = 1 if Settings.NUM_PROCESSES < 1 else Settings.NUM_PROCESSES

        shared = SharedState(network, spec, num_workers)
        shared.push_init_box(init_box)

        Timers.tic('run workers')

        if num_workers == 1:
            if Settings.PRINT_OUTPUT:
                print(f"Running single-threaded")
                
            worker_func(0, shared)
        else:
            processes = []

            if Settings.PRINT_OUTPUT:
                print(f"Running in parallel with {num_workers} processes")

            for index in range(Settings.NUM_PROCESSES):
                p = multiprocessing.Process(target=worker_func, args=(index, shared))
                p.start()
                processes.append(p)

            for p in processes:
                p.join()

        Timers.toc('run workers')

        rv = shared.result

    rv.total_secs = time.perf_counter() - start

    Timers.toc('enumerate_network')

    if Settings.TIMING_STATS and Settings.PRINT_OUTPUT:
        Timers.print_stats()

    if not rv.result_from_presolver:
        process_result(shared)

    return rv

class SharedState(Freezable):
    'shared computation state across processes'

    def __init__(self, network, spec, num_workers):
        assert isinstance(network, NeuralNetwork)
        
        # process-local copies
        self.network = network
        self.spec = spec
        self.num_workers = num_workers
        self.multithreaded = num_workers > 1

        self.init_bm = None
        self.init_bias = None
        
        # master -> worker
        # this lock should be used whenever modifying shared variables or consistency is needed,
        # except for the more_work_queue since that manages its own locks
        self.mutex = multiprocessing.Lock()
        
        if self.multithreaded:
            self.more_work_queue = multiprocessing.Queue()
        else:
            self.more_work_queue = FakeQueue() # use deque for single-threaded, faster

        # queue size is unreliable since multithreaded, use this instead
        self.stars_in_progress = multiprocessing.Value('i', 0)

        # used for load balancing
        self.heap_sizes = multiprocessing.Array('i', num_workers)

        # statistics worker -> master
        self.num_lps = multiprocessing.Value('i', 0)
        self.num_lps_enum = multiprocessing.Value('i', 0)
        self.num_offloaded = multiprocessing.Value('i', 0)
        self.finished_stars = multiprocessing.Value('i', 0)
        self.finished_work_frac = multiprocessing.Value('f', 0) # completed work fraction

        num_timers = len(Settings.RESULT_SAVE_TIMERS)
        self.timer_secs = multiprocessing.Array('f', num_timers) # seconds, in same order as timers in Settings
        self.timer_counts = multiprocessing.Array('i', num_timers)

        self.cur_layers = multiprocessing.Array('i', num_workers)
        self.cur_neurons = multiprocessing.Array('i', num_workers)

        # set if an exception occurs so everyone exits
        self.had_exception = multiprocessing.Value('i', 0)

        # set if a timeout occured so everyone exits
        self.had_timeout = multiprocessing.Value('i', 0)

        # general flag if we should exit
        self.should_exit = multiprocessing.Value('i', 0)

        # result data
        self.result = Result(network)

        self.freeze_attrs()

    def push_init_box(self, init_box):
        'put the initial init_box on the work queue'

        network_inputs = self.network.get_num_inputs()
        assert len(init_box) == network_inputs, f"network expected {network_inputs} inputs, got {len(init_box)} inputs"

        if self.spec is not None:
            network_outputs = self.network.get_num_outputs()
                    
            assert network_outputs == self.spec.get_num_expected_variables(), \
                f"spec expected {self.spec.get_num_expected_variables()} outputs; network had {network_outputs} outputs"

        ss = LpStarState(init_box)

        # without the mutex here, if the threads start quickly, they may exit before finding the first piece of work
        # since the queue can be asynchronous
        ##############################
        self.mutex.acquire()

        # store the init bm and init_bias for generating concrete counterexamples
        self.init_bm = ss.star.a_mat.copy()
        self.init_bias = ss.star.bias.copy()        
        
        self.put_queue(ss)
        self.stars_in_progress.value = 1
        self.mutex.release()
        ##############################

    def to_full_input(self, compressed_input):
        'convert possibly compressed input to full input'

        rv = np.dot(self.init_bm, compressed_input) + self.init_bias

        return rv

    def put_queue(self, ss):
        'put a starstate on the queue'

        Timers.tic('put_queue')

        if self.multithreaded:
            ss.star.lpi.serialize()

        self.more_work_queue.put(ss)

        Timers.toc('put_queue')    

    def get_global_queue(self, block=True, timeout=None, skip_deserialize=False):
        '''pop a starstate from the global queue

        returns None on timeout
        '''

        Timers.tic('get_global_queue')

        try:
            rv = self.more_work_queue.get(block=block, timeout=timeout)

            if self.multithreaded and not skip_deserialize:
                rv.star.lpi.deserialize()

        except queue.Empty:
            rv = None

        Timers.toc('get_global_queue')

        return rv

class PrivateState(Freezable):
    'private state for work processes'

    def __init__(self, worker_index):
        self.worker_index = worker_index

        # ss is the current StarState being computed
        self.ss = None # pylint: disable=invalid-name
        #self.work_list = [] # list of tuples: (layer, neuron, id(ss), ss)

        if Settings.LOCAL_DFS:
            self.work_list = []
        else:
            self.work_list = MinMaxHeap()

        # local copies of statistics
        self.finished_stars = 0
        self.num_offloaded = 0
        self.num_lps = 0
        self.num_lps_enum = 0

        self.stars_in_progress = 0

        self.next_shared_var_update = time.time() + Settings.UPDATE_SHARED_VARS_INTERVAL
        self.shared_update_urgent = False # used when work is popped to make sure we update heap sizes

        # fullfullment time stats
        self.fulfillment_requested_time = None
        self.total_fulfillment_time = 0
        self.total_fulfillment_count = 0

        # for updating shared stats
        self.update_stars = 0
        self.update_work_frac = 0.0
        self.update_stars_in_progress = 0

        # stats recorded by worker 0
        self.start_time = time.time()
        self.next_stats_time = self.start_time
        # stats is a list of timestamps, each timestamp is tuple (time, [stars_0, stars_1, ... stars_n])
        self.stats = []

        # used by worker 0 for periodic printing
        self.start_time = None
        self.last_print_time = None
        self.num_prints = 0

        # was there an exception (in another process)
        self.had_exception = 0

        self.freeze_attrs()

class Worker(Freezable):
    'local data for a worker process'

    def __init__(self, shared, worker_index):

        self.shared = shared
        self.priv = PrivateState(worker_index)

        self.freeze_attrs()
        
    def main_loop(self):
        'main worker loop'

        should_exit = False

        if Settings.LOCAL_DFS:
            local_pop_func = self.priv.work_list.pop
        else:
            local_pop_func = lambda: self.priv.work_list.pop(want_max=False)[-1]

        while not should_exit:

            if self.priv.ss is not None:
                self.advance_star()

            # pop queue before updating shared variables so it doesn't look like there's no work if queue is nonempty
            if self.priv.ss is None:
                if self.priv.work_list: # pop from local
                    self.priv.ss = local_pop_func()
                else: # pop from global (shared)
                    self.priv.ss = self.shared.get_global_queue(timeout=0.01)

                    if self.priv.ss is not None:
                        # make sure we tell other people we have work now
                        self.priv.shared_update_urgent = True

                        if self.priv.fulfillment_requested_time is not None:
                            diff = time.time() - self.priv.fulfillment_requested_time
                            self.priv.fulfillment_requested_time = None
                            self.priv.total_fulfillment_time += diff
                            self.priv.total_fulfillment_count += 1

            # after processing a star
            should_exit = self.update_shared_variables()
            self.print_progress()

        Timers.tic('post_loop')
        self.update_final_stats()
        self.clear_remaining_work()
        Timers.toc('post_loop')

    def update_shared_variables(self):
        '''update shared variables among workers periodically

        returns should_exit
        '''

        should_exit = False

        if self.shared.should_exit.value:
            self.priv.shared_update_urgent = True

        # don't need to update shared varaibles every iteration as it can take nontrivial time
        now = time.time()

        if self.priv.shared_update_urgent or (self.priv.work_list and now > self.priv.next_shared_var_update):
            Timers.tic('update_shared_variables')
            
            windex = self.priv.worker_index

            #######################################
            Timers.tic('get mutex')
            should_block = self.priv.shared_update_urgent
            did_lock = self.shared.mutex.acquire(should_block)
            Timers.toc('get mutex')

            if did_lock:
                self.priv.shared_update_urgent = False

            self.priv.next_shared_var_update = now + Settings.UPDATE_SHARED_VARS_INTERVAL

            # non-blocking
            if did_lock:
                # update in progress counts
                self.shared.stars_in_progress.value += self.priv.stars_in_progress
                self.priv.stars_in_progress = 0

                # update heap info
                self.shared.heap_sizes[windex] = len(self.priv.work_list)

                if self.priv.ss:
                    self.shared.heap_sizes[windex] += 1

                num_zeros = 0

                for i, size in enumerate(self.shared.heap_sizes):
                    if i != self.priv.worker_index:
                        if size == 0:
                            num_zeros += 1
                            self.shared.heap_sizes[i] = 0 # temp marker so other people don't give them work
                    
                #heap_sizes = list(self.shared.heap_sizes) # was comprehension

                # update finished counts (these get set in finalized_star)
                self.shared.finished_stars.value += self.priv.update_stars
                self.shared.finished_work_frac.value += self.priv.update_work_frac
                self.shared.stars_in_progress.value += self.priv.update_stars_in_progress

                self.priv.update_stars = 0
                self.priv.update_work_frac = 0
                self.priv.update_stars_in_progress = 0

                # check if completed
                if self.is_finished_with_lock():
                    should_exit = True

                self.shared.mutex.release()
                #########################################

                Timers.tic('load_balancing')
                self.do_load_balancing(num_zeros)
                Timers.toc('load_balancing')

            Timers.toc('update_shared_variables')

        return should_exit

    def print_progress(self):
        'periodically print progress (worker 0 only)'

        if self.priv.worker_index == 0 and (Settings.PRINT_INTERVAL > 0 or Settings.TIMEOUT is not None):
            now = time.time()

            if self.priv.last_print_time is None:
                self.priv.start_time = now
                self.priv.last_print_time = now - Settings.PRINT_INTERVAL - 1 # force a print at start

            if Settings.TIMEOUT is not None:
                cur_time = now - self.priv.start_time

                if cur_time >= Settings.TIMEOUT:
                    ##############################
                    self.shared.mutex.acquire()
                    self.shared.had_timeout.value = 1
                    self.shared.mutex.release()
                    ##############################

            if now - self.priv.last_print_time > Settings.PRINT_INTERVAL and Settings.PRINT_OUTPUT:
                Timers.tic("print_progress")
                
                # print stats
                self.priv.last_print_time = now
                self.priv.num_prints += 1

                ##############################
                self.shared.mutex.acquire()
                
                in_progress = self.shared.stars_in_progress.value
                finished = self.shared.finished_stars.value

                layers = list(self.shared.cur_layers)
                neurons = list(self.shared.cur_neurons)

                qsize = self.shared.more_work_queue.qsize()

                finished_frac = self.shared.finished_work_frac.value

                self.shared.mutex.release()
                ##############################
                elapsed = now - self.priv.start_time
                time_str = to_time_str(elapsed)

                status = ""

                for layer, neuron in zip(layers, neurons):
                    if status:
                        status += " "

                    status += f"{layer}-{neuron}".rjust(7)

                status += "       "
                total_stars = in_progress + finished

                eta = '-'

                delta_time = now - self.priv.start_time

                if finished_frac > 0:
                    estimated_total = delta_time / finished_frac
                    eta = max(estimated_total - elapsed, 0)
                    eta = to_time_str(eta)

                # don't divide by 0
                expected_stars = round(1 if finished_frac < 1e-9 else finished / finished_frac)

                print(f"({time_str}) Q: {qsize}, Sets: {finished}/{total_stars} " + \
                      f" ({round(finished_frac * 100, 3)}%) ETA: {eta} (expected {expected_stars} stars)   ", end="\r")

                log_prints = math.log(self.priv.num_prints, 2)
                
                if abs(log_prints - round(log_prints)) < 1e-7:
                    # save snapshot
                    print("") # newline
                
                Timers.toc("print_progress")

    def is_finished_with_lock(self):
        '''is the computation finished (should workers exit?)

        call with mutex locked
        '''
        
        rv = self.shared.stars_in_progress.value == 0

        if not rv:
            rv = self.shared.result.found_confirmed_counterexample.value == 1

        if not rv and self.shared.had_exception.value == 1:

            if Settings.PRINT_OUTPUT:
                print(f"Worker {self.priv.worker_index} quitting due to exception in another worker")
                
            self.priv.had_exception = 1
            rv = True

        if not rv and self.shared.had_timeout.value == 1:
            rv = True

        if rv and not self.shared.should_exit.value:
            self.shared.should_exit.value = 1

        return rv
                        
    def clear_remaining_work(self):
        'sometimes we quit early, make sure the work queue is empty so processes exit as expected'

        if self.priv.ss is not None or self.priv.stars_in_progress > 0:
            #######################################
            self.shared.mutex.acquire()

            if self.priv.ss:
                self.shared.stars_in_progress.value -= 1
                self.priv.ss = None

            self.shared.stars_in_progress.value += self.priv.stars_in_progress
            self.priv.stars_in_progress = 0
                
            self.shared.mutex.release()
            ########################################

        should_exit = False
        count = len(self.priv.work_list)

        while not should_exit:
            
            # pop as many as possible
            while True:
                ss = self.shared.get_global_queue(False, skip_deserialize=True)

                if ss:
                    count += 1
                else:
                    break

            self.shared.mutex.acquire()
            self.shared.stars_in_progress.value -= count
            count = 0

            if self.shared.stars_in_progress.value <= 0:
                assert self.shared.stars_in_progress.value == 0, \
                    f"stars in progress should be 0, was {self.shared.stars_in_progress.value}"
                should_exit = True

            self.shared.mutex.release()

            # don't busy wait
            if not should_exit:
                time.sleep(0.01)

    def update_final_stats(self):
        'all processes finished, update global stats'

        self.shared.mutex.acquire()

        self.shared.num_lps.value += self.priv.num_lps
        self.shared.num_lps_enum.value += self.priv.num_lps_enum
        
        self.shared.num_offloaded.value += self.priv.num_offloaded

        for tindex, timer_name in enumerate(Settings.RESULT_SAVE_TIMERS):
            timer_list = Timers.top_level_timer.get_children_recursive(timer_name)
            
            for t in timer_list:
                self.shared.timer_secs[tindex] += t.total_secs
                self.shared.timer_counts[tindex] += t.num_calls

        self.shared.mutex.release()

    def do_load_balancing(self, num_zeros):
        '''balance work across threads using a work-stealing strategy
        '''

        while num_zeros > 0 and self.priv.work_list:
            # push some work onto the queue

            # min item is heaviest (closest to root)
            if isinstance(self.priv.work_list, MinMaxHeap):
                new_ss = self.priv.work_list.pop(want_max=not Settings.OFFLOAD_CLOSEST_TO_ROOT)[-1]

                print(f" new_ss: {new_ss}")
                assert new_ss.star is not None
            else:
                assert Settings.LOCAL_DFS
                # heaviest will be first item on list
                new_ss = self.priv.work_list.pop(0)
                
            self.priv.num_offloaded += 1
            num_zeros -= 1

            self.shared.put_queue(new_ss)

    def save_cinput(self):
        'save the concrete input for the current, finished star into result.cinputs'

        Timers.tic('save_cinput')

        ss = self.priv.ss

        res = self.find_concrete_io(ss.star, ss.branch_tuples)

        if res is not None:
            cinput, _ = res
            self.shared.result.cinputs.append(cinput)

        Timers.toc('save_cinput')

    def save_output_range(self):
        'compute the output range for the current, finished star, and update result.output_min / output_max if needed'

        Timers.tic('save_output_range')

        ss = self.priv.ss

        dims = ss.star.a_mat.shape[0]
        box = []
        update_shared_bounds = False

        for i in range(dims):
            minimize_vec = np.array([1 if d == i else 0 for d in range(dims)], dtype=float)
            maximize_vec = -1 * minimize_vec

            min_output = ss.star.minimize(minimize_vec)
            min_value = min_output[i]

            max_output = ss.star.minimize(maximize_vec)
            max_value = max_output[i]

            # check if these bounds exceed the global bounds without mutex first
            if min_value < self.shared.result.output_min[i] or max_value > self.shared.result.output_max[i]:
                update_shared_bounds = True

            box.append((min_value, max_value))

        if update_shared_bounds:
            #########################
            self.shared.mutex.acquire()

            for i in range(dims):
                min_value, max_value = box[i]

                # re-check if these bounds exceed the global bounds (maybe there was an update)
                if min_value < self.shared.result.output_min[i]:
                    self.shared.result.output_min[i] = min_value

                if max_value > self.shared.result.output_max[i]:
                    self.shared.result.output_max[i] = max_value

            self.shared.mutex.release()
            #########################

        Timers.toc('save_output_range')

    def save_star(self):
        '''save the lp_star to the result

        this has the effect of serializing the current star's lpi if multithreaded
        '''

        self.priv.ss.star.lpi.serialize()
        self.shared.result.stars.append(self.priv.ss.star)

    def save_poly(self):
        'save the polygon verts for the current, finished star into result.polys'

        Timers.tic('save_poly')

        ss = self.priv.ss
        xdim, ydim = Settings.RESULT_SAVE_POLYS_DIMS

        # save polygon
        verts = ss.star.verts(xdim, ydim, epsilon=Settings.RESULT_SAVE_POLYS_EPSILON)
        self.shared.result.polys.append(verts)
        
        Timers.toc('save_poly')

    def find_concrete_io(self, star, branch_tuples):
        'try to find a concrete input and output in star, that explores the passed-in branch_tuples'

        Timers.tic('find_concrete_io')
        rv = None

        # solve lp to get the input/output
        res = star.minimize_vec(None, return_io=True)

        if res is not None:
            cinput, _ = res

            # try to confirm the counter-example
            full_cinput = self.shared.to_full_input(cinput)
            exec_output, exec_branch_list = self.shared.network.execute(full_cinput, save_branching=True)

            if branch_list_in_branch_tuples(exec_branch_list, branch_tuples):
                rv = full_cinput, exec_output
            else:

                # try to make each of the constraints a little tighter
                star_copy = star.copy()

                rhs_original = star_copy.lpi.get_rhs()
                rhs = rhs_original.copy()

                # tighten by this factor
                tighten_factor = 1e-16

                while tighten_factor < 1e16:
                    
                    # tighten the constraints a little
                    for i, val in enumerate(rhs_original):
                        rhs[i] = val - tighten_factor

                    star_copy.lpi.set_rhs(rhs)

                    res = star_copy.minimize_vec(None, return_io=True)

                    if res is None:
                        # infeasible
                        break

                    cinput, _ = res

                    full_cinput = self.shared.to_full_input(cinput)
                    exec_output, exec_branch_list = self.shared.network.execute(full_cinput, save_branching=True)

                    if branch_list_in_branch_tuples(exec_branch_list, branch_tuples):
                        rv = full_cinput, exec_output
                        break

                    # for next loop, tighten even more
                    tighten_factor *= 10

        Timers.toc('find_concrete_io')
                        
        return rv
    
    def finished_star(self):
        'finished with a concrete star state'

        Timers.tic('finished_star')

        ss = self.priv.ss
        assert ss is not None

        ################
        #print(f"todo: remove debug, finished star with {ss.num_splits} splits")
        #print(f"finished star with depth {-math.log(ss.work_frac, 2)}")

        #tree_splits = [item[-1].num_splits
        
        #total_splits = self.shared.finished_splits.value + ss.num_splits
        #expected_splits = self.shared.finished_stars.value + 1 + ss.num_splits

        #assert total_splits == expected_splits, f"total_splits: {total_splits}, expected_splits: {expected_splits}"
        #############

        # update enumeration num lps before checking
        self.priv.num_lps_enum += ss.star.num_lps

        if Settings.RESULT_SAVE_POLYS:
            self.save_poly()

        if Settings.RESULT_SAVE_CONCRETE_INPUTS:
            self.save_cinput()

        if Settings.RESULT_SAVE_OUTPUT_RANGES:
            self.save_output_range()

        if self.shared.spec is not None:
            confirmed_counterexample = False
            
            violation_star = self.shared.spec.get_violation_star(ss.star)

            # check if it's a confirmed counter-example
            # it's okay to do this unconditionally, as when a confirmed counter-example is found, we will quit
            if violation_star is not None:
                res = self.find_concrete_io(violation_star, ss.branch_tuples)

                if res is not None:
                    confirmed_counterexample = True
                    cinput, coutput = res
                    
                    print(f"\nWorker {self.priv.worker_index} found a confirmed counterexample")
                else:
                    print(f"\nWorker {self.priv.worker_index} found a counterexample, but it wasn't reproduced by " + \
                          "a concrete execution.")
        else:
            violation_star = None

        # accumulate stats
        self.priv.finished_stars += 1
        self.priv.num_lps += ss.star.num_lps

        # do this last as it will serialize the star's lpi if multithreaded
        if Settings.RESULT_SAVE_STARS:
            self.save_star()

        self.priv.ss = None

        # local stats that get updates in update_shared_variables
        self.priv.update_stars += 1
        self.priv.update_work_frac += ss.work_frac
        self.priv.update_stars_in_progress -= 1

        if not self.priv.work_list:
            # urgently update shared variables to try to get more work
            self.priv.shared_update_urgent = True
            self.priv.fulfillment_requested_time = time.time()

        # only update shared here if found counterexample or out of work
        if violation_star is not None:
            #########################
            Timers.tic('update_shared')
            self.shared.mutex.acquire()

            self.shared.result.found_counterexample.value = 1

            if confirmed_counterexample:
                self.shared.result.found_confirmed_counterexample.value = 1
                self.shared.should_exit.value = True

                for i, val in enumerate(cinput):
                    self.shared.result.cinput[i] = val

                for i, val in enumerate(coutput):
                    self.shared.result.coutput[i] = val

            self.shared.mutex.release()
            Timers.toc('update_shared')
            #########################

        Timers.toc('finished_star')

    def advance_star(self):
        'advance a single star'

        ss = self.priv.ss
        assert ss is not None

        assert ss.cur_layer < len(self.shared.network.layers)

        Timers.tic('advance')
        new_star = ss.advance(self.shared.network)
        Timers.toc('advance')

        if new_star:
            self.priv.stars_in_progress += 1
            #self.push_work(new_star)

            if isinstance(self.priv.work_list, MinMaxHeap):
                self.priv.work_list.push(new_star.heap_item())
            else:                    
                self.priv.work_list.append(new_star)

        if self.priv.ss.cur_layer >= len(self.shared.network.layers):
            self.finished_star() # this clears self.ss
        else:

            if not Settings.LOCAL_DFS:
                if isinstance(self.priv.work_list, MinMaxHeap):
                    self.priv.work_list.push(self.priv.ss.heap_item())
                else:                    
                    self.priv.work_list.append(self.priv.ss)
                    
                self.priv.ss = None
                
            # for dfs, just keep ss as is
                
        return new_star

def process_result(shared):
    'process a verification result'

    # save timing information
    if shared.had_exception.value:
        shared.result.result_str = "error"
    elif shared.had_timeout.value == 1:
        shared.result.result_str = "timeout"
    elif shared.result.found_confirmed_counterexample.value:
        shared.result.result_str = "unsafe"
    elif shared.result.found_counterexample.value:
        shared.result.result_str = "unsafe (unconfirmed)"
    elif shared.spec is not None:
        shared.result.result_str = "safe"

    # save num lps to result
    shared.result.total_lps = shared.num_lps.value

    # save num lps enum to result
    shared.result.total_lps_enum = shared.num_lps_enum.value

    # save num stars to result
    shared.result.total_stars = shared.finished_stars.value

    if Settings.PRINT_OUTPUT:
        if shared.had_exception.value == 1:
            print("Exception occured during execution")
        else:
            print(f"Total Stars: {shared.finished_stars.value}")
            
            suffix = "" if shared.result.total_secs < 60 else f" ({round(shared.result.total_secs, 2)} sec)"
            print(f"Runtime: {to_time_str(shared.result.total_secs)}{suffix}")
            print(f"Completed work frac: {shared.finished_work_frac.value}")
            print(f"Num Stars Copied Between Processes: {shared.num_offloaded.value}")
            print(f"Num Lps During Enumeration: {shared.num_lps_enum.value}")
            print(f"Total Num Lps: {shared.num_lps.value}")
            print("")

            if shared.had_timeout.value == 1:
                print(f"Timeout ({Settings.TIMEOUT}) reached during execution")
            elif shared.result.found_confirmed_counterexample.value:
                print(f"Result: network is UNSAFE, confirmed counterexample:")
                print(f"Input: {list(shared.result.cinput)}")
                print(f"Output: {list(shared.result.coutput)}")
            elif shared.result.found_counterexample.value:
                print(f"Result: network seems UNSAFE, but not confirmed counterexamples (possible numerial " + \
                      "precision issues)")
            elif shared.spec is not None:
                print(f"Result: network is SAFE") # safe subject to numerical accuracy issues

        if shared.result.polys:
            print(f"Result contains {len(shared.result.polys)} sets of polygons")

        if shared.result.cinputs:
            print(f"Result contains {len(shared.result.cinputs)} concrete inputs")


        enum_ended_early = shared.result.result_from_presolver or shared.result.result_str not in ["none", "safe"]
        
        if enum_ended_early and (shared.result.polys or shared.result.cinputs):
            print(f"Warning: result polygons / concrete inputs /stars is incomplete, since the enumeration ended early")

    # deserialize stars if saved
    if shared.result.stars:
        shared.result.stars = list(shared.result.stars) # convert to normal list

        Timers.tic('deserialize result stars')

        for s in shared.result.stars:
            s.lpi.deserialize()

        Timers.toc('deserialize result stars')

    # save timers if requested
    for timer_name, count, secs in zip(Settings.RESULT_SAVE_TIMERS, shared.timer_counts, shared.timer_secs):
        shared.result.timers[timer_name] = (count, secs)

def worker_func(worker_index, shared):
    'worker function during verification'

    if shared.multithreaded:
        Timers.stack.clear() # reset inherited Timers
        tag = f" (Process {worker_index})"
    else:
        tag = ""

    timer_name = f'worker_func{tag}'

    Timers.tic(timer_name)

    w = Worker(shared, worker_index)

    try:
        w.main_loop()

        if worker_index == 0 and Settings.PRINT_OUTPUT:
            print("\n")
        
        Timers.toc(timer_name)

        if shared.multithreaded and not shared.had_exception.value:
            if worker_index != 0 and Settings.PRINT_OUTPUT and Settings.TIMING_STATS:
                time.sleep(0.2) # delay to try to let worker 0 print timing stats first

            ##############################
            shared.mutex.acquire()
            # use mutex so printing doesn't get interrupted

            # computation time is sum of advance_star and finished_star
            if Settings.TIMING_STATS:
                as_timer_list = Timers.top_level_timer.get_children_recursive('advance')
                fs_timer_list = Timers.top_level_timer.get_children_recursive('finished_star')

                if as_timer_list and fs_timer_list:
                    as_timer = as_timer_list[0]
                    fs_timer = fs_timer_list[0]
                    secs = as_timer.total_secs + fs_timer.total_secs

                    percent = 100 * secs / Timers.top_level_timer.total_secs

                    if Settings.PRINT_OUTPUT:
                        if w.priv.total_fulfillment_count > 0:
                            t = w.priv.total_fulfillment_time
                            c = w.priv.total_fulfillment_count
                            avg = t / c
                        else:
                            c = t = avg = 0

                        print(f"Worker {worker_index}: {w.priv.finished_stars} stars; " + \
                              f"advance_star: {round(percent, 1)}%; " + \
                              f"Fulfillment Count: {c}, Tot: {round(t, 2)}s, Avg: {round(1000*avg, 3)}ms ")
            shared.mutex.release()
            ##############################

            if Settings.PRINT_OUTPUT and Settings.TIMING_STATS and \
               Settings.NUM_PROCESSES > 1 and worker_index == 0:
                time.sleep(0.4)
                print("")
                Timers.print_stats()
                print("")
    except:
        if Settings.PRINT_OUTPUT:
            print("\n")
            traceback.print_exc()

        shared.mutex.acquire()
        shared.had_exception.value = True
        shared.should_exit.value = True
        shared.mutex.release()

        print(f"\nWorker {worker_index} had exception") 
        w.clear_remaining_work()

        # fix timers
        while Timers.stack and Timers.stack[-1].name != timer_name:
            Timers.toc(Timers.stack[-1].name)

        Timers.toc(timer_name)

def to_time_str(secs):
    'return a string representation of the number of seconds'

    divisors = [1, 60, 60*60, 24*60*60, 7*24*60*60, 365*24*60*60, np.inf]
    labels = ["sec", "min", "hr", "days", "weeks", "years"]
    bounds = divisors[1:]
    digits = [1, 2, 3, 4, 4, 4]
    time_str = ""

    for divisor, digit, label, bound in zip(divisors, digits, labels, bounds):
        if secs < bound:
            time_str = f"{round(secs / divisor, digit)} {label}"
            break

    return time_str

def branch_list_in_branch_tuples(branch_list, branch_tuples):
    'does the passed in concrete-execution (branch_list) go down the same branches as the star (branch_tuples)?'

    rv = True

    for layer, neuron, branch_type in branch_tuples:
        exec_type = branch_list[layer][neuron]

        #print(f"layer {layer}, neuron {neuron}, star branch type {branch_type}, exec_type: {exec_type}")

        if isinstance(exec_type, list):
            rv = branch_type in exec_type
        else:
            rv = branch_type == exec_type

        if not rv:
            break

    return rv
