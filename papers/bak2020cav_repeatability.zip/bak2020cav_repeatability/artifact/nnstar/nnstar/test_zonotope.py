'''
Tests for zonotopes
'''

import numpy as np

#import matplotlib.pyplot as plt

from nnstar.settings import Settings
from nnstar.zonotope import Zonotope, zono_from_compressed_init_box
from nnstar import util

def setup_function(_):
    '''setup method for each test'''

    Settings.reset()
    Settings.NUM_PROCESSES = True # don't use parallelism

def test_maximize():
    'test maximize zono'

    # x in [9, 11], y in [-2, 2]
    z = Zonotope(np.array([10.0, 0.0]), np.array([[1.0, 0.0], [0.0, 2.0]]))
    # center (10, 0), gen1 = (1, 0), gen2 = (0, 2)

    assert z.maximize([0, 1])[1] == 2
    assert z.maximize([0, -1])[1] == -2
    assert z.maximize([1, 0])[0] == 11
    assert z.maximize([-1, 0])[0] == 9

    assert np.allclose(z.maximize([1, 1]), [11, 2])
    assert np.allclose(z.maximize([1, -1]), [11, -2])
    assert np.allclose(z.maximize([-1, -1]), [9, -2])

    # change init bounds
    z.update_init_bounds(0, (-1, 0.5))
    assert z.maximize([1, 0])[0] == 10.5

    z.update_init_bounds(0, (-1, -0.5))
    assert z.maximize([1, 0])[0] == 9.5

def test_single_output_bounds():
    'test single output bounds'

    # x in [9, 11], y in [-2, 2]
    z = Zonotope(np.array([10.0, 0.0]), np.array([[1.0, 0.0], [0.0, 2.0]]))
    # center (10, 0), gen1 = (1, 0), gen2 = (0, 2)

    bounds = z.get_single_output_bounds(0)

    assert np.allclose(bounds[0], 9)
    assert np.allclose(bounds[1], 11)

    bounds = z.get_single_output_bounds(1)

    assert np.allclose(bounds[0], -2)
    assert np.allclose(bounds[1], 2)


def test_box_bounds():
    'test box_bounds'

    g1 = [1.0, 1.0]
    g2 = [1.0, -1.0]
    gen_mat_t = np.array([g1, g2]).transpose()
    z = Zonotope(np.array([2.0, 2.0]), gen_mat_t)

    assert np.allclose(z.box_bounds(), [[0, 4], [0, 4]])

    expected = [(4, 2), (0, 2), (2, 4), (2, 0)]
    util.assert_verts_equals(z.verts(), expected)

    z.update_init_bounds(0, (0, 0))
    util.assert_verts_equals(z.verts(), [(3, 1), (1, 3)])

    assert np.allclose(z.box_bounds(), [[1, 3], [1, 3]])

    z.update_init_bounds(0, (-1, -0.5), skip_check=True)
    
    expected = [(2.0 - g1[0] - g2[0], 2.0 - g1[1] - g2[1]),
                (2.0 - 0.5 * g1[0] - g2[0], 2.0 - 0.5 * g1[1] - g2[1]),
                (2.0 - g1[0] + g2[0], 2.0 - g1[1] + g2[1]),
                (2.0 - 0.5 * g1[0] + g2[0], 2.0 - 0.5 * g1[1] + g2[1])]

    #xs, ys = zip(*z.verts())
    #plt.plot(xs, ys)
    #plt.show()
    
    util.assert_verts_equals(z.verts(), expected)

    assert np.allclose(z.box_bounds(), [[0, 2.5],
                                        [0, 2.5]])

def test_domain_contraction_simple():
    'test for intersect zono with linear constraints'

    # x in [-1, 1], y in [-2, 2]
    z = Zonotope(np.array([0.0, 0.0]), np.array([[1.0, 0.0], [0.0, 1.0]]))
    z.update_init_bounds(1, (-2, 2), skip_check=True)

    assert np.allclose(z.box_bounds(), [[-1, 1], [-2, 2]])

    # x <= 0
    z.contract_domain([1, 0], 0)
    assert np.allclose(z.box_bounds(), [[-1, 0], [-2, 2]])

    ##################
    z = Zonotope(np.array([0.0, 0.0]), np.array([[1.0, 0.0], [0.0, 1.0]]))
    z.update_init_bounds(1, (-2, 2), skip_check=True)

    # y >= 0
    z.contract_domain([0, -1], 0)
    assert np.allclose(z.box_bounds(), [[-1, 1], [0, 2]])
    #############################

    # x - y <= 0.1  AKA x <= y + 0.1)
    z = Zonotope(np.array([0.0, 0.0]), np.array([[1.0, 0.0], [0.0, 1.0]]))
    z.update_init_bounds(1, (-2, 2), skip_check=True)
    z.contract_domain([1, -1], 0.1)
    assert np.allclose(z.box_bounds(), [[-1, 1], [-1.1, 2]])

    # try the other way
    z = Zonotope(np.array([0.0, 0.0]), np.array([[1.0, 0.0], [0.0, 1.0]]))
    z.update_init_bounds(1, (-2, 2), skip_check=True)

    # y >= x
    z.contract_domain([-1, 1], -0.1)
    assert np.allclose(z.box_bounds(), [[-1, 1], [-2, 0.9]])

    # try x <= -0.2
    z = Zonotope(np.array([0.0, 0.0]), np.array([[1.0, 0.0], [0.0, 1.0]]))
    z.update_init_bounds(1, (-2, 2), skip_check=True)
    
    z.contract_domain([1, 0], -0.2)
    assert np.allclose(z.box_bounds(), [[-1, -0.2], [-2, 2]])

def test_contract_5d():
    'test domain contraction on a 5-d example from acasxu'

    box = [(-0.30353115613746867, -0.29855281193475053),
           (-0.009549296585513092, 0.009549296585513092),
           (0.4933803235848431, 0.4997465213085185),
           (0.3, 0.5), (0.3, 0.5)]

    init_bm, init_bias, init_box = util.compress_init_box(box)
    z = zono_from_compressed_init_box(init_bm, init_bias, init_box)

    ib = z.init_bounds
    assert np.allclose(box, ib)

    hp = np.array([6.56524e-01, 1.65052e-02, -6.12824e-04, 5.13311e-01, -1.09330e-01], dtype=float)
    rhs = -0.0886957

    z.contract_domain(hp, rhs)    

    assert np.allclose(ib[0], [-0.30353115613746867, -0.29855281193475053])
    assert np.allclose(ib[1], [-0.009549296585513092, 0.009549296585513092])
    assert np.allclose(ib[2], [0.4933803235848431, 0.4997465213085185])
    assert np.allclose(ib[3], [0.3, 0.32282311983217404])
    assert np.allclose(ib[4], [0.39284406417110507, 0.5])

def test_single_bound():
    'test compute bound of single output for rotated square'

    center = np.array([-0.5, -0.5], dtype=float)
    gen_mat_t = np.array([[0.70710678, -0.70710678], [0.70710678, 0.70710678]], dtype=float)
    z = Zonotope(center, gen_mat_t)

    lb, ub = z.get_single_output_bounds(0)
    expected_lb = center[0] - gen_mat_t[0, 0] + gen_mat_t[0, 1]
    expected_ub = center[0] + gen_mat_t[0, 0] - gen_mat_t[0, 1]

    assert abs(lb - expected_lb) < 1e-6, f"got lb {lb}, expected {expected_lb}"
    assert abs(ub - expected_ub) < 1e-6, f"got ub {ub}, expected {expected_ub}"
