'''
LP star implementation

Stanley Bak
'''

import random
import sys

import matplotlib.pyplot as plt

import numpy as np

from nnstar.lpinstance import LpInstance, get_lp_params
from nnstar.util import Freezable
from nnstar.timerutil import Timers
from nnstar import kamenev

#import matplotlib
#matplotlib.use('TkAgg') # matplotlib 3.1 has ugly default backend

class LpStar(Freezable):
    '''generalized star set with lp constraints

    this is set up to efficiently encode: 
    linear transformation (using a_mat, a_rhs),
    constraints on initial variables (using csr / rhs)
    '''

    def __init__(self, a_mat, bias, box_bounds=None):

        assert isinstance(a_mat, np.ndarray)
        assert isinstance(bias, np.ndarray)
        
        self.a_mat = a_mat
        self.bias = bias

        # initialize lpi with no constraints
        self.lpi = None

        # cached lp result
        self.last_lp_result = None

        self.num_lps = 0 # stat, number of lps solved

        if box_bounds is not None:
            self.lpi = LpInstance()

            for i, (lb, ub) in enumerate(box_bounds):
                self.lpi.add_double_bounded_cols([f"i{i}"], lb, ub)

        self.freeze_attrs()

    def __str__(self):
        rv = "LpStar with a_mat:\n"

        for i, row in enumerate(self.a_mat):
            rv += f"a_mat row {i}: {row}\n"

        rv += "bias:\n"

        for i, val in enumerate(self.bias):
            rv += f"bias {i}: {val}\n"

        rv += "and LP:\n"
        rv += str(self.lpi)

        return rv

    def copy(self):
        'return a copy of this lpstar'

        rv = LpStar(a_mat=self.a_mat.copy(), bias=self.bias.copy())

        rv.lpi = LpInstance(self.lpi)

        return rv

    def input_box_bounds(self, cur_box, count_lps=True):
        '''get input box bounds on this set, compared with the current bounds using lp

        returns a list of 3-tuples for each of the bounds that was adjusted:
        (dim, lb, ub)
        '''

        dims = self.lpi.get_num_cols()
        rv = []
        tol = 1e-8

        Timers.tic("star.box_bounds")

        for dim in range(dims):
            # adjust lb
            vec = np.array([1 if i == dim else 0 for i in range(dims)], dtype=float)
            res = self.lpi.minimize(vec)

            if count_lps:
                self.num_lps += 1

            if abs(res[dim] - cur_box[dim][0]) >= tol:
                rv.append([dim, res[dim], np.inf])

            # adjust ub
            vec = np.array([-1 if i == dim else 0 for i in range(dims)], dtype=float)
            res = self.lpi.minimize(vec)

            if count_lps:
                self.num_lps += 1

            if abs(res[dim] - cur_box[dim][1]) >= tol:
                if not rv or rv[-1][0] != dim:
                    rv.append([dim, -np.inf, res[dim]])
                else:
                    rv[-1][2] = res[dim]

        Timers.toc("star.box_bounds")

        return rv

    def minimize_output(self, output_index, maximize=False):
        '''
        get the output value when one of the outputs is minimized (or maximized)

        if stop_at_zero is set, this will terminate the search once zero is crossed

        if you want the (input, output) pair to produce this output, use consutrct_last_io()
        '''

        Timers.tic('minimize_output')

        if self.a_mat.size == 0:
            value = self.bias
        else:
            row = self.a_mat[output_index]

            if maximize:
                row = -1 * row

            self.last_lp_result = lp_result = self.lpi.minimize(row)
            self.num_lps += 1

            num_init_vars = self.a_mat.shape[1]
            assert len(lp_result) == num_init_vars

            # single row
            value = self.a_mat[output_index].dot(lp_result) + self.bias[output_index]

        Timers.toc('minimize_output')

        return value

    def construct_last_io(self):
        '''construct the last concrete input/output pair from the optimization performed when minimize_output was called

        note that the input will be the compressed input if input space is not full dimensional
        '''

        Timers.tic('construct_last_io')
        
        i = self.last_lp_result
        o = np.dot(self.a_mat, i) + self.bias

        Timers.toc('construct_last_io')

        return [i, o]

    def minimize_vec(self, vec, return_io=False):
        '''optimize over this set

        vec is the vector of outputs we're optimizing over, None means use zero vector

        if return_io is true, returns a tuple (input, output); otherwise just output
        note that the cinput will be the compressed input if input space is not full dimensional

        returns all the outputs (coutput) if return_io=False, else (cinput, coutput)
        '''

        Timers.tic('star.minimize_vec')

        if self.a_mat.size == 0:
            rv = self.bias
            lp_result = np.array([], dtype=float)
        else:
            assert len(self.a_mat.shape) == 2, f"a_mat shape was {self.a_mat.shape}"

            if vec is None:
                vec = np.zeros((self.a_mat.shape[0],), dtype=float)

            assert len(vec) == self.a_mat.shape[0], f"minimize called with vector with {len(vec)} elements, " + \
                f"but set has {self.a_mat.shape[0]} outputs"

            #Timers.tic('setup')
            assert isinstance(vec, np.ndarray)

            lp_vec = np.dot(self.a_mat.T, vec)
            #lp_vec = vec.T.dot(self.a_mat).T

            num_init_vars = self.a_mat.shape[1]
            lp_vec.shape = (len(lp_vec),)
            #Timers.toc('setup')

            #Timers.tic('lpi.minimize')
            lp_result = self.lpi.minimize(lp_vec)
            
            self.num_lps += 1
            #Timers.toc('lpi.minimize')
            assert len(lp_result) == num_init_vars

            #print("--------")
            #print(f"lp_result: {lp_result}")

            #Timers.tic('a_mat mult')
            rv = np.dot(self.a_mat, lp_result) + self.bias
            #Timers.toc('a_mat mult')

        # return input as well
        if return_io:
            rv = (lp_result, rv)

        Timers.toc('star.minimize_vec')

        return rv

    def verts(self, xdim=0, ydim=1, epsilon=1e-7):
        'get a 2-d projection of this lp_star'

        dims = self.a_mat.shape[0]

        assert 0 <= xdim < dims, f"xdim {xdim} out of bounds for star with {dims} dims"
        assert 0 <= ydim < dims, f"ydim {ydim} out of bounds for star with {dims} dims"

        dims = self.a_mat.shape[0]

        def supp_point_func(vec2d):
            'maximize a support function direction'

            Timers.tic('supp_point_func')

            lpdir = np.zeros(dims, dtype=float)
            # -1 because we want to maximize for support function
            lpdir[xdim] = -1 * vec2d[0]
            lpdir[ydim] = -1 * vec2d[1]

            res = self.minimize_vec(lpdir)

            Timers.toc('supp_point_func')

            return np.array([res[xdim], res[ydim]], dtype=float)

        Timers.tic('kamenev.get_verts')
        verts = kamenev.get_verts(2, supp_point_func, epsilon=epsilon)
        Timers.toc('kamenev.get_verts')
        
        return verts

    def plot(self, color='k-o', lw=1, xdim=0, ydim=1, epsilon=1e-7):
        'use matplotlib to plot this lp_star'

        verts = self.verts(xdim=xdim, ydim=ydim, epsilon=epsilon)

        xs, ys = zip(*verts)
        plt.plot(xs, ys, color, lw=lw)
