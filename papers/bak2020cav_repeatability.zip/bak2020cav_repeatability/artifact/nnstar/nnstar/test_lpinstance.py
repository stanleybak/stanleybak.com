'''
tests for lp_instance
'''

from scipy.sparse import csr_matrix
import numpy as np

import swiglpk as glpk

from nnstar.lpinstance import LpInstance, UnsatError, get_lp_params, SwigArray

import pytest

def setup_function(_):
    '''setup method for each test'''

    SwigArray.WARN_MEMORY_SWIGLPK_LEAK_GB = 4.0
    SwigArray.ERROR_MEMORY_SWIGLPK_LEAK_GB = 8.0

def make_lpi():
    'make a sample lpi'

    lpi = LpInstance()

    # add init vars
    lpi.add_double_bounded_cols(['one'], 0, 1)
    lpi.add_cols(['two'])
    lpi.add_positive_cols(['longthree', 'delta'])

    lpi.add_rows_less_equal([1]) # <= 1
    lpi.add_rows_less_equal([10]) # <= 10

    # add constraints on initial conditions, offset by <cur_time_dims> rows
    mat = [[1, 0, 0, 5], [0, 1, 1.5, 0]]

    csr = csr_matrix(mat, dtype=float)
    glpk_indices = [int(i + 1) for i in csr.indices]
    data = [i for i in csr.data] # list needed
    
    lpi.set_constraints_csr(data, glpk_indices, csr.indptr, csr.shape)

    return lpi

def test_get_constaints():
    'test get contraints and rhs'

    lpi = make_lpi()

    mat = [[1, 0, 0, 5], [0, 1, 1.5, 0]]
    csr = csr_matrix(mat, dtype=float)

    rhs = [1, 10]

    assert np.allclose(lpi.get_rhs(), rhs)
    assert np.allclose(csr.toarray(), lpi.get_constraints_csr().toarray())

def test_str():
    'test string representation'

    lpi = make_lpi()
    assert lpi.minimize([1, -1, 0, 0]) is not None

    got = lpi.__str__(plain_text=True)

    expected = \
        'Lp has 4 columns (variables) and 2 rows (constraints)\n' + \
        '     *one    two *longt *delta \n' + \
        'min   1.0   -1.0    0.0    0.0 \n' + \
        'subject to:\n' + \
        '       NL     BS     NL     NL \n' + \
        ' 1: BS    1.0      0      0    5.0  <=    1.0 \n' + \
        ' 2: NU      0    1.0    1.5      0  <=   10.0 \n' + \
        '(*) Bounded variables:\n' + \
        'one in [0.0, 1.0]\n' + \
        'longthree in [0.0, inf]\n' + \
        'delta in [0.0, inf]'
        
    assert got == expected

    print(lpi) # no exception, not plain text

def test_basic():
    'test basic routines'

    lpi = make_lpi()

    # test get_types
    types = lpi.get_types()

    assert len(types) == 2
    assert types[0] == glpk.GLP_UP
    assert types[1] == glpk.GLP_UP

def test_copy_serialize():
    'test copy and serialize methods'

    lpi = make_lpi()
    assert lpi.is_feasible()

    other = LpInstance(lpi)
    assert other.is_feasible()

    other.serialize()
    other.deserialize()
    assert other.minimize([1, -1, 0, 0]) is not None

def test_add_row():
    'test adding row to lpi'

    arr = SwigArray.get_sequential_int_array(10)

    for i in range(10):
        assert arr[i+1] == i+1

    vec = np.array([1.0, 1.5, 2], dtype=float)
    arr2 = SwigArray.as_double_array(vec, vec.size)

    for i, val in enumerate(vec):
        assert arr2[i+1] == val

    lpi = make_lpi()
    vec = np.array([1, 0, 0, 5], dtype=float)
    
    lpi.add_dense_row(vec, 2)
    assert lpi.is_feasible()

def test_infeasible():
    'test infeasible lps'

    lpi = make_lpi()

    vec = np.array([1, 0, 0, 5], dtype=float)

    lpi.add_dense_row(vec, 2)
    # timeout
    params = get_lp_params()
    int_max = params.it_lim
    params.it_lim = 0

    with pytest.raises(RuntimeError): # out of iterations
        lpi.minimize([1, 1, 1, 1])

    params.it_lim = int_max

    with pytest.raises(RuntimeError): # unbounded solution
        lpi.minimize([1, 1, 1, 1])

    assert lpi.minimize([0, 0, 0, 0]) is not None
    assert lpi.minimize(None) is not None

    # make it infeasible
    lpi.add_dense_row(-1 * vec, -3)

    with pytest.raises(UnsatError): # unsat
        lpi.minimize(None)
