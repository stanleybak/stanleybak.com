'''
Prefilter logic

Overapproximation for shortciruiting splitting decisions during enumeration

Note: the logic for a lack of prefilter... using lp at each step, is also encoded here.
'''

import collections

import numpy as np

from nnstar.settings import Settings
from nnstar.util import Freezable, compress_init_box
from nnstar.zonotope import zono_from_compressed_init_box, Zonotope
from nnstar.timerutil import Timers
from nnstar.lpinstance import LpInstance

####
#
'''
Current thoughts:

need another optimization layer before where you don't short-circuit the operations (always compute lb and ub)

witnesses shouldn't be thrown away after you split, they should be inherited by one of the children
to do this, we need to store (input, output) witnesses instead of just (output) witnesses, so that we can
check efficiently which child gets the witness: (row * witness_column + bias <= 0??) 

however, if we've proven bounds are one-sided, then you don't need to copy those witnesses

are bounds part of the prefilter or part of the star state?
the witnesses seem to only come from LP solving (and maybe the center sim? and inherited on split?)

It seems like the center-sim first serves as a witness for every neuron

the actual bounds don't matter (LP), only if a witness is present

the prefilter bounds DO matter, as they can eliminate the need to find witnesses if they're one-sided
the LP bounds do matter, in that they can prove the bound is one-sided, which is inherited after splitting

it's generally faster to solve all upper bounds than all lower bounds instead of alternating (LP warm start)

I don't actually need to optimize using LP... I just a need a witness that exhibits both sides of a branch
If you know the input point corresponding to the center sim, and the direction to optimize in, then you
can find a point from center sim in the correct direction that meets all constraints by simple enumeration of
the linear constraints in the star. Once you have this, sim up to the current layer and check the sign of 
output neuron i. This is a sort of prefilter for split cases (as opposed to non-split cases)
'''
#
#

def prod(l):
    'like math.prod in python 3.8'

    rv = 1

    for i in l:
        rv *= i

    return rv

def exec_relus_up_to(state, index):
    'execute reluts on the passed in state vector up to index'

    for i in range(index):
        if state[i] < 0:
            state[i] = 0

class OutputBounds(Freezable):
    'container object for output bounds for each neuron in a single layet'

    def __init__(self, prefilter, num_outputs):
        self.prefilter = prefilter
        self.lb_min = None
        self.ub_max = None

        if num_outputs is not None:
            # outer bounds
            self.lb_min = np.full((num_outputs,), -np.inf, dtype=float)
            self.ub_max = np.full((num_outputs,), np.inf, dtype=float)

        self.branching_neurons = None

        self.freeze_attrs()

    def copy_prefilter_recompute_bounds(self, star, start_index):
        'recompute bounds with copy prefitler'

        num_outputs = self.lb_min.size
        
        for i in range(start_index, num_outputs):
            if self.lb_min[i] < 0 < self.ub_max[i]:
                neg = LpInstance(star.lpi)
                pos = LpInstance(star.lpi)

                row = star.a_mat[i]
                bias = star.bias[i]

                # pos gets output >= 0
                # neg gets output <= 0
                pos.add_dense_row(-row, bias)
                neg.add_dense_row(row, -bias)

                pos_feasible = pos.is_feasible()
                star.num_lps += 1

                neg_feasible = neg.is_feasible()
                star.num_lps += 1

                # don't know exact bounds, only enough to detect splitting
                if pos_feasible:
                    self.ub_max[i] = 1
                else:
                    self.ub_max[i] = -1

                if neg_feasible:
                    self.lb_min[i] = -1
                else:
                    self.lb_min[i] = 1

    def no_prefilter_recompute_bounds(self, star, start_index):
        'recompute bounds with no prefitler'

        num_outputs = self.lb_min.size
        
        # first do all mins then all maxes (slightly faster due to warm start)
        check = []

        for i in range(start_index, num_outputs):
            if self.lb_min[i] < 0 < self.ub_max[i]:
                check.append(i)

        for i in check:
            self.lb_min[i] = star.minimize_output(i)

            # round small values to zero
            if abs(self.lb_min[i]) <= Settings.SPLIT_TOLERANCE:
                self.lb_min[i] = 0

        for i in check:
            self.ub_max[i] = star.minimize_output(i, maximize=True)

            # round small values to zero
            if abs(self.ub_max[i]) <= Settings.SPLIT_TOLERANCE:
                self.ub_max[i] = 0

    def sim_prefilter_recompute_bounds(self, star, start_index):
        'recompute bounds using (at least) sim prefilter'

        Timers.tic('sim_prefilter_recompute_bounds')

        sim = self.prefilter.simulation[1] # sim output
        num_outputs = self.lb_min.size

        for i in range(start_index, num_outputs):
            if self.lb_min[i] < 0 < self.ub_max[i]:

                if sim[i] >= 0: # only compute min if it may reject branch
                    lb = star.minimize_output(i)

                    # round small values to zero
                    if abs(lb) <= Settings.SPLIT_TOLERANCE:
                        lb = 0

                    self.lb_min[i] = lb

                    if lb < 0 and self.prefilter.witness_index is None:
                        lb_witness = star.construct_last_io()
                        ub_witness = None

                        if sim[i] > 0:
                            sim_tuple = self.prefilter.simulation
                            ub_witness = sim_tuple#[sim_tuple[0].copy(), sim_tuple[1].copy()]
                        else:
                            # sim[i] == 0... we might not be branching
                            ub = star.minimize_output(i, maximize=True)

                            # round small values to zero
                            if abs(ub) <= Settings.SPLIT_TOLERANCE:
                                ub = 0

                             # it may not be computed next loop since we assigned witness_index
                            self.ub_max[i] = ub

                            if ub > 0:
                                ub_witness = star.construct_last_io()

                        # note sim[i] may be equal to zero, in which case wait till max is computed
                        if ub_witness is not None and ub_witness[1][i] > 0:
                            # store first witness for split
                            self.prefilter.witness_index = i # this will also prevent ub from being recomputed
                            self.prefilter.ub_witness = ub_witness
                            self.prefilter.lb_witness = lb_witness

        for i in range(start_index, num_outputs):
            if self.lb_min[i] < 0 < self.ub_max[i]:
                if sim[i] <= 0 and self.prefilter.witness_index != i: # only recompute max if it may reject branch
                    ub = star.minimize_output(i, maximize=True)

                    # round small values to zero
                    if abs(ub) <= Settings.SPLIT_TOLERANCE:
                        ub = 0

                    self.ub_max[i] = ub

                    if ub > 0 and (self.prefilter.witness_index is None or self.prefilter.witness_index > i):
                        ub_witness = star.construct_last_io()
                        lb_witness = None

                        if sim[i] < 0:
                            sim_tuple = self.prefilter.simulation
                            lb_witness = sim_tuple#[sim_tuple[0].copy(), sim_tuple[1].copy()]
                        else:
                            # sim[i] == 0... we might not be branching
                            lb = star.minimize_output(i)

                            if lb < 0:
                                lb_witness = star.construct_last_io()

                        # note sim[i] may be equal to zero, in which case wait till max is computed
                        if lb_witness is not None and lb_witness[1][i] < 0:
                            # store first witness for split
                            self.prefilter.witness_index = i
                            self.prefilter.ub_witness = ub_witness
                            self.prefilter.lb_witness = lb_witness

        Timers.tic('exec_relus')
        
        if self.prefilter.witness_index is not None:
            i = self.prefilter.witness_index

            assert self.prefilter.ub_witness[1][i] > 0
            assert self.prefilter.lb_witness[1][i] < 0
            
            # since we haven't assigned sim or star to be zero up to the split, we need to run relus
            exec_relus_up_to(self.prefilter.ub_witness[1], i+1)
            exec_relus_up_to(self.prefilter.lb_witness[1], i+1)
        else:
            # witness index is none, do relus for simulation to setup next layer
            size = self.prefilter.simulation[1].size
            exec_relus_up_to(self.prefilter.simulation[1], size)
            
        Timers.toc('exec_relus')

        Timers.toc('sim_prefilter_recompute_bounds')

    def eager_assign_zeros(self, star):
        '''
        assign the zeros to the star and prefilter eagerly (right after updating bounds)
        '''

        Timers.tic('eager_assign_zeros')
        assert Settings.PREFILTER_EAGER_BOUNDS

        if self.branching_neurons is None:
            num_outputs = self.lb_min.size
            self.branching_neurons = collections.deque(range(num_outputs))

        new_branching_neurons = collections.deque()

        for i in self.branching_neurons:
            if self.ub_max[i] <= 0:
                star.bias[i] = 0
                star.a_mat[i] = 0

                #self.prefilter.set_zonotope_zeros((i,))
                if self.prefilter.zono is not None:
                    assert self.prefilter.zono.mat_t is star.a_mat
                    assert self.prefilter.zono.center is star.bias

                # simulation never gets assigned zero in eager bounds
                # instead when assigning counter-example we do it
            elif self.lb_min[i] < 0:
                # branch is possible
                new_branching_neurons.append(i)

        self.branching_neurons = new_branching_neurons
                    
        Timers.toc('eager_assign_zeros')

    def recompute_bounds(self, star, start_index):
        '''recompute output bounds for the layer, starting at the passed-in index'''

        Timers.tic('recompute_bounds')
        self.prefilter.witness_index = None # index
        self.prefilter.lb_witness = None # (input / output)
        self.prefilter.ub_witness = None # (input / output)

        if Settings.PREFILTER_TYPE == Settings.TYPE_ZONO_PREFILTER:
            self.prefilter.zono.update_output_bounds(self.lb_min, self.ub_max, start_index)

            # zonotope bounds are not exact, need to use either sim or no prefilter for further trimming
            if Settings.ZONO_PREFILTER_USE_SIM:
                self.sim_prefilter_recompute_bounds(star, start_index)
            else:
                self.no_prefilter_recompute_bounds(star, start_index)
            
        elif Settings.PREFILTER_TYPE == Settings.TYPE_NO_PREFILTER:
            self.no_prefilter_recompute_bounds(star, start_index)
        elif Settings.PREFILTER_TYPE == Settings.TYPE_COPY_PREFILTER:
            self.copy_prefilter_recompute_bounds(star, start_index)
        else:
            assert Settings.PREFILTER_TYPE == Settings.TYPE_SIM_PREFILTER
            self.sim_prefilter_recompute_bounds(star, start_index)

        Timers.toc('recompute_bounds')
                                
    def split(self, other_prefilter, i, self_gets_positive):
        '''a star with this prefilter is being split along neuron i, 

        return a copy of the output bounds for the other star, adjusting
        the bounds based on how we split
        '''

        # manually copy
        rv = OutputBounds(other_prefilter, None)
        rv.lb_min = self.lb_min.copy()
        rv.ub_max = self.ub_max.copy()

        if self.branching_neurons is not None:
            rv.branching_neurons = self.branching_neurons.copy()

        # trim to appropriate side on neuron i
        if self_gets_positive:
            self.lb_min[i] = 0
            rv.ub_max[i] = 0
        else:
            rv.lb_min[i] = 0
            self.ub_max[i] = 0

        return rv

class Prefilter(Freezable):
    'main container for prefilter data and logic'

    def __init__(self):

        self.simulation = None # 2-list [input, output]        
        self.zono = None

        # used for prefilter_zonotope
        self.output_bounds = None

        
        # used for prefilter sim and above; witness of first split
        self.witness_index = None # index
        self.lb_witness = None # (input / output)
        self.ub_witness = None # (input / output)

        # stats
        self.layer_num = None
        
        self.prefilter_correct = 0
        self.prefilter_incorrect = 0
        self.prefilter_trimmed = 0

        self.freeze_attrs()

    def init_from_uncompressed_box(self, uncompressed_init_box, star, box_bounds):
        'initialize from an uncompressed initial box'

        if Settings.PREFILTER_TYPE >= Settings.TYPE_SIM_PREFILTER:
            # sim state is initially the center of the box
            sim_input = []
            sim_output = []
            tol = 1e-9

            if Settings.COMPRESS_INPUTS:
                for i in uncompressed_init_box:
                    mid = (i[0] + i[1]) / 2.0
                    sim_output.append(mid) # sim output is uncompressed

                    if abs(i[1] - i[0]) > tol: # sim input is compressed
                        sim_input.append(mid)
            else:
                
                for i in uncompressed_init_box:
                    mid = (i[0] + i[1]) / 2.0
                    sim_output.append(mid)
                    sim_input.append(mid)

            sim_input = np.array(sim_input, dtype=float)
            sim_output = np.array(sim_output, dtype=float)
                
            self.simulation = [sim_input, sim_output]

        if Settings.PREFILTER_TYPE >= Settings.TYPE_ZONO_PREFILTER:
            self.zono = Zonotope(star.bias, star.a_mat, box_bounds.copy())

            assert star.a_mat is self.zono.mat_t
            assert star.bias is self.zono.center

    def clear_output_bounds(self):
        'clear_output_bounds (new layer started)'

        self.output_bounds = None

    def set_simulation_zero(self, i):
        'apply the relu to the simulation output'

        if Settings.PREFILTER_TYPE == Settings.TYPE_SIM_PREFILTER or \
            (Settings.PREFILTER_TYPE == Settings.TYPE_ZONO_PREFILTER and Settings.ZONO_PREFILTER_USE_SIM):
            self.simulation[1][i] = 0

    def transform_fully_connected(self, layer, star):
        '''do the linear transform part of the fully-connected layer

        the passed-in star is already-transformed
        '''

        self.layer_num = layer.layer_num

        if self.simulation:
            self.simulation[1] = layer.execute(self.simulation[1], skip_relu=True)

        # zonotope
        if self.zono is not None:
            assert self.zono.mat_t is star.a_mat
            assert self.zono.center is star.bias

        if Settings.PREFILTER_EAGER_BOUNDS and layer.has_relu:
            num_outputs = prod(layer.get_output_shape())
            self.output_bounds = OutputBounds(self, num_outputs)

            self.output_bounds.recompute_bounds(star, 0)

            # unit testing function
            if Settings.TEST_FUNC_BEFORE_ASSIGNMENT is not None:
                Settings.TEST_FUNC_BEFORE_ASSIGNMENT()
            
            self.output_bounds.eager_assign_zeros(star)

    #def set_zonotope_zeros(self, indices):
    #    'set some of the zonotope outputs to zero'
    #
    #    if self.zono is not None:
    #        for i in indices:
    #            self.zono.center[i] = 0
    #            self.zono.mat_t[i] = 0

    def compute_sign_copy_prefilter(self, star, i):
        '''get neuron i's output sign (-1, 1 or 0 for split)'''

        neg = LpInstance(star.lpi)
        pos = LpInstance(star.lpi)

        row = star.a_mat[i]
        bias = star.bias[i]
            
        # pos gets output >= 0
        # neg gets output <= 0
        pos.add_dense_row(-row, bias)
        neg.add_dense_row(row, -bias)

        Timers.tic('check_feasible')
        pos_feasible = pos.is_feasible()
        star.num_lps += 1
        
        neg_feasible = neg.is_feasible()
        star.num_lps += 1
        Timers.toc('check_feasible')

        # sometimes, adding a constraint makes both children infeasible (numerical)
        
        if not neg_feasible:
            rv = 1
        elif not pos_feasible:
            rv = -1
        else:
            rv = 0

        return rv

    def compute_sign_no_prefilter(self, star, i):
        '''get neuron i's output sign (-1, 1 or 0 for split)'''

        lb = star.minimize_output(i)
        ub = star.minimize_output(i, maximize=True)

        #print(f"ub = {ub}, lb = {lb}")

        if abs(lb) <= Settings.SPLIT_TOLERANCE:
            lb = 0

        if abs(ub) <= Settings.SPLIT_TOLERANCE:
            ub = 0

        if ub <= 0:
            rv = -1
        elif lb >= 0:
            rv = 1
        else:
            rv = 0

        return rv

    def compute_sign_sim_prefilter(self, star, i):
        '''
        get neuron i outer bounds using the sim prefilter

        if there is a split, this will assign witness info to output_bounds

        returns (lb_min, ub_max)
        '''

        assert self.simulation is not None
        assert self.witness_index is None

        sim_output = self.simulation[1][i]

        if sim_output > 0:
            lb = star.minimize_output(i)

            if abs(lb) <= Settings.SPLIT_TOLERANCE:
                lb = 0

            if lb < 0:
                rv = 0

                self.witness_index = i
                self.lb_witness = star.construct_last_io()
                
                self.ub_witness = [self.simulation[0].copy(), self.simulation[1].copy()]
                
            else:
                rv = 1
        elif sim_output < 0:
            ub = star.minimize_output(i, maximize=True)

            if abs(ub) <= Settings.SPLIT_TOLERANCE:
                ub = 0

            if ub > 0:
                rv = 0

                self.witness_index = i
                self.lb_witness = [self.simulation[0].copy(), self.simulation[1].copy()]
                self.ub_witness = star.construct_last_io()
            else:
                rv = -1
        else:
            # simulation landed on zero
            lb = star.minimize_output(i)

            # need to construct this here before optimizing again
            # even though it may not be needed if no split exists
            self.lb_witness = star.construct_last_io()
            
            ub = star.minimize_output(i, maximize=True)

            if abs(lb) <= Settings.SPLIT_TOLERANCE:
                lb = 0
                
            if abs(ub) <= Settings.SPLIT_TOLERANCE:
                ub = 0

            if ub <= 0:
                rv = -1
            elif lb >= 0:
                rv = 1
            else:
                rv = 0

                self.ub_witness = star.construct_last_io()
                self.witness_index = i

        if self.witness_index is not None:
            assert rv == 0
            # apply relu to lb witness at index i

            # lb_witness[witness_index] should be negative
            
            self.lb_witness[1][self.witness_index] = 0 # execute relu

        return rv

    def compute_sign_zono_prefilter(self, star, i):
        '''
        get neuron i's output sign (-1, 1, or 0 for split)
        '''

        lb_min, ub_max = self.zono.get_single_output_bounds(i)

        if abs(lb_min) <= Settings.SPLIT_TOLERANCE:
            lb_min = 0

        if abs(ub_max) <= Settings.SPLIT_TOLERANCE:
            ub_max = 0

        if lb_min >= 0:
            rv = 1
        elif ub_max <= 0:
            rv = -1
        else:
            # zonotope didn't help, use exact
            if Settings.ZONO_PREFILTER_USE_SIM:
                rv = self.compute_sign_sim_prefilter(star, i)
            else:
                rv = self.compute_sign_no_prefilter(star, i)
            
        return rv

    def compute_output_sign(self, star, i):
        '''
        compute the output sign (-1=neg, 1=pos, 0=split) for neuron i, with the passed-in star

        this also assigns witnesses on splits (returns 0)
        '''

        assert not Settings.PREFILTER_EAGER_BOUNDS
        self.witness_index = None

        if Settings.PREFILTER_TYPE == Settings.TYPE_COPY_PREFILTER:
            rv = self.compute_sign_copy_prefilter(star, i)
        elif Settings.PREFILTER_TYPE == Settings.TYPE_NO_PREFILTER:
            rv = self.compute_sign_no_prefilter(star, i)
        elif Settings.PREFILTER_TYPE == Settings.TYPE_SIM_PREFILTER:
            rv = self.compute_sign_sim_prefilter(star, i)
        else:
            assert Settings.PREFILTER_TYPE == Settings.TYPE_ZONO_PREFILTER
            rv = self.compute_sign_zono_prefilter(star, i)

        return rv

    def contract_lp(self, star):
        'do lp zonotope contraction'

        Timers.tic("contract_zonotope_lp")

        cur_box = self.zono.init_bounds

        new_bounds_list = star.input_box_bounds(cur_box, count_lps=False)

        for dim, lb, ub in new_bounds_list:
            self.zono.update_init_bounds(dim, (lb, ub))

        Timers.toc("contract_zonotope_lp")

    def split_relu(self, neuron_index, pos_star, neg_star, self_gets_positive):
        '''split the star associated with this prefilter. This updates this
        prefilter's prediction, as well as returns a new prefilter to be used with
        the other star associated with the split

        neuron_index - the neuron index on which we're splitting
        take_positive - does the self prefilter take the >= case (false is negative case)
        pos_star - the >= 0 direction split lp_star
        neg_star - the negative direction split lp_star

        returns a Prefilter object for the other star
        '''

        i = neuron_index
        rv = Prefilter()
        rv.layer_num = self.layer_num

        # self gets positive
        if self_gets_positive:
            pos, neg = self, rv
        else:
            neg, pos = self, rv

        if Settings.PREFILTER_TYPE == Settings.TYPE_SIM_PREFILTER or \
            (Settings.PREFILTER_TYPE == Settings.TYPE_ZONO_PREFILTER and Settings.ZONO_PREFILTER_USE_SIM):
            assert i == self.witness_index, \
                f"i was {i}, witness index was {self.witness_index}"
            
            lb_witness = self.lb_witness
            ub_witness = self.ub_witness

            assert lb_witness is not None
            assert ub_witness is not None

            neg.simulation = lb_witness
            pos.simulation = ub_witness

            assert lb_witness[1][i] <= Settings.SPLIT_TOLERANCE, f"lb witness wasn't negative: {lb_witness[1][i]}"
            assert ub_witness[1][i] >= -Settings.SPLIT_TOLERANCE, f"ub witness wasn't positive: {ub_witness[1][i]}"

        if self.output_bounds is not None:
            rv.output_bounds = self.output_bounds.split(rv, i, self_gets_positive)

        if self.zono:
            # only deep copy the init_bounds
            if self_gets_positive:
                rv.zono = Zonotope(neg_star.bias, neg_star.a_mat, self.zono.init_bounds.copy())
                assert rv.zono.mat_t is neg_star.a_mat
                assert rv.zono.center is neg_star.bias
            else:
                rv.zono = Zonotope(pos_star.bias, pos_star.a_mat, self.zono.init_bounds.copy())
                assert rv.zono.mat_t is pos_star.a_mat
                assert rv.zono.center is pos_star.bias

            row = pos_star.a_mat[i]
            bias = pos_star.bias[i]

            ### try shrinking prefilter zonotopes ###
            if Settings.CONTRACT_ZONOTOPE:
                Timers.tic("contract_zonotope")
                pos.zono.contract_domain(-row, bias)
                #pos.zono.update_output_bounds(pos.cur_layer_bounds, full_update=False, start_index=i+1)

                neg.zono.contract_domain(row, -bias)
                #neg.zono.update_output_bounds(neg.cur_layer_bounds, full_update=False, start_index=i+1)
                Timers.toc("contract_zonotope")

            if Settings.CONTRACT_ZONOTOPE_LP:
                pos.contract_lp(pos_star)
                neg.contract_lp(neg_star)

        ### RECOMPUTE LAYER BOUNDS (for remaining neurons)
        if Settings.PREFILTER_EAGER_BOUNDS:
            # recompute bounds for remaining neurons
            num_outputs = self.output_bounds.lb_min.size

            if i+1 < num_outputs:
                pos.output_bounds.recompute_bounds(pos_star, i+1)
                neg.output_bounds.recompute_bounds(neg_star, i+1)

                pos.output_bounds.eager_assign_zeros(pos_star)
                neg.output_bounds.eager_assign_zeros(neg_star)

        if Settings.PREFILTER_TYPE == Settings.TYPE_SIM_PREFILTER or \
                (Settings.PREFILTER_TYPE == Settings.TYPE_ZONO_PREFILTER and Settings.ZONO_PREFILTER_USE_SIM):
            assert rv.simulation is not None
            
        return rv
