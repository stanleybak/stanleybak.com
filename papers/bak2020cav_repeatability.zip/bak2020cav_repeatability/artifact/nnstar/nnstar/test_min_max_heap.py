'''
testing functions for min_max_heap
'''

from min_max_heap import MinMaxHeap

def test_basic():
    'basic functionality test adding from either side and popping'

    h = MinMaxHeap()
    assert not h

    try:
        h.pop(False)
        assert False, "expected index error"
    except IndexError:
        pass

    h.push(5)
    assert h
    assert len(h) == 1
    
    h.push(3)
    h.push(7) # push 7 twice
    h.push(7)

    assert h
    assert h.pop(False) == 3
    assert len(h) == 3

    assert h.pop(False) == 5
    assert len(h) == 2
    assert h

    assert h.pop(True) == 7
    assert h
    
    assert h.pop(False) == 7
    assert not h
    assert len(h) == 0

    try:
        h.pop(False)
        assert False, "expected index error"
    except IndexError:
        pass

    try:
        h.pop(True)
        assert False, "expected index error"
    except IndexError:
        pass
    
    assert len(h) == 0
