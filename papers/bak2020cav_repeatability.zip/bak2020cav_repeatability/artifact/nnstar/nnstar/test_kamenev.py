'''
Miscilanous tests for nnstar

Stanley Bak
'''

import numpy as np

from kamenev import get_verts
import util
from timerutil import Timers

def test_get_verts_box():
    'test for get_verts, unit box'

    def supp_point_func(vec):
        'support function pt'

        if vec[0] <= 0:
            x = 0
        else:
            x = 1

        if vec[1] <= 0:
            y = 0
        else:
            y = 1

        return np.array([x, y], dtype=float)
    
    verts = get_verts(2, supp_point_func)
    assert len(verts) == 5

    expected = [[0, 0], [1, 0], [0, 1], [1, 1]]
    util.assert_verts_equals(verts, expected)

def test_get_verts_line():
    'test for get_verts, line along y axis'

    def supp_point_func(vec):
        'support function pt'

        if vec[1] < 0:
            y = 0
        else:
            y = 1

        return np.array([0, y], dtype=float)
    
    verts = get_verts(2, supp_point_func)
    assert len(verts) == 2

    expected = [[0, 0], [0, 1]]
    util.assert_verts_equals(verts, expected)

def test_verts_box_nd():
    'test verts on n-d unit box'

    for dims in [2, 3, 4, 5]:

        def supp_point_func(vec):
            'support function pt'

            rv = []

            for x in vec:
                if x <= 0:
                    rv.append(0)
                else:
                    rv.append(1)

            return np.array(rv, dtype=float)

        verts = get_verts(dims, supp_point_func)
        expected = 2**dims + (1 if dims == 2 else 0)
        assert len(verts) == expected

def test_get_verts_circle():
    'test for get_verts, line along y axis'

    def supp_point_func(vec):
        'support function pt'

        return vec / np.linalg.norm(vec)
    
    verts1 = get_verts(2, supp_point_func, epsilon=1e-4)
    verts2 = get_verts(2, supp_point_func, epsilon=1e-5)

    assert len(verts1) <= len(verts2)

