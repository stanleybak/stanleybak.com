'''
test methods for specification.py
'''

from nnstar.lp_star_state import LpStarState
from nnstar.specification import Specification

def test_box_single():
    'test single specification against unit box'

    init_box = [[0, 1], [0, 1]]

    ss = LpStarState(init_box)

    # x <= -1
    spec = Specification([[1, 0]], [-1])

    assert not spec.is_violation([0, 0])
    assert not spec.is_violation([0, -2])
    assert spec.is_violation([-2, 0])

    assert spec.get_violation_star(ss.star) is None

    spec = Specification([[1, 0]], [0.5])
    assert spec.is_violation([0, 0])

    assert spec.get_violation_star(ss.star) is not None

def test_box_bias():
    'test specification against offset unit box'

    init_box = [[0, 1], [0, 1]]

    ss = LpStarState(init_box)

    # x <= -1
    spec = Specification([[1, 0]], [-1])

    # set box xoffset to -0.5
    ss.star.bias[0] = -0.5

    assert not spec.get_violation_star(ss.star)
        
    # set box xoffset to -1.5
    ss.star.bias[0] = -1.5

    assert spec.get_violation_star(ss.star)

def test_box_box():
    'test box specification against box'

    init_box = [[0, 1], [0, 1]]

    ss = LpStarState(init_box)

    spec_mat = [[1, 0],
                [-1, 0],
                [0, 1],
                [0, -1]]
    spec_rhs = [2, -1.1, 2, -1.1]
    
    spec = Specification(spec_mat, spec_rhs)

    assert spec.get_violation_star(ss.star) is None

    # set box xoffset to -0.5
    ss.star.bias[0] = 0.5

    assert spec.get_violation_star(ss.star) is None

    # set box yoffset to -0.5
    ss.star.bias[1] = 0.5

    assert spec.get_violation_star(ss.star) is not None
