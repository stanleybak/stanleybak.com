'''
Presolver functionality
'''

import multiprocessing
import traceback

import numpy as np

from nnstar.result import Result
from nnstar.settings import Settings
from nnstar.timerutil import Timers
from nnstar.lp_star_state import LpStarState
from nnstar.network import FullyConnectedLayer
from nnstar.util import Freezable, compress_init_box
from nnstar.zonotope import zono_from_compressed_init_box

def output(s):
    'print a string to output if printing is enabled'

    if Settings.PRINT_OUTPUT:
        print(s)
 
def verify(init_box, network, spec):
    '''verify using the presolver method

    returns a Result object which has result_str = "none" if inconclusive
    '''

    Timers.tic('presolver')

    output(f"\nTrying to verify with overapproximation presolver...")

    entry_timer = None if not Timers.stack else Timers.stack[-1]

    result = Result(network)

    try:
        ss = LpStarState(init_box)
        ss.prefilter = None # don't use prefilter when doing overapproximation
        zonos = MultiZono(init_box)
        
        presolver_advance(ss, zonos, network)

        # try zonotope prefilter on spec
        may_violate = zonos.might_violate_spec(spec)
        output(f"Zonotope overapprox may violate spec: {may_violate}")

        if not may_violate:
            # done! construct a results object
            result.result_str = "safe"
        else:
            # try star constructed from zonotope bounds on spec
            res = spec.get_violation_star(ss.star)

            if res is None:
                output(f"Overapprox star using zonotope ranges cannot violate spec")
                result.result_str = "safe"
            else:
                # witness input does not correspond to witness output since it's an overapproximation
                # try to simulate nn to check concrete path

                winput, _ = res.minimize_vec(None, return_io=True)

                output(f"Overapprox star using zonotope ranges might violate spec, trying concrete input")

                winput = winput[:network.get_num_inputs()] # trim overapprox generator inputs

                real_output = network.execute(winput)
                confirmed = spec.is_violation(real_output)

                if confirmed:
                    output(f"Concrete input violated spec")
                    result.result_str = "unsafe"
                                    
                    result.found_counterexample.value = 1
                    result.found_confirmed_counterexample.value = 1

                    for i, val in enumerate(winput):
                        result.cinput[i] = val

                    for i, val in enumerate(real_output):
                        result.coutput[i] = val
                else:
                    output(f"Concrete input did not violate spec")

        if result.result_str == "none": # presolver was inconclusive
            output(f"Presolver was inconclusive\n")
        else:
            output(f"Verification completed with presolver: {result.result_str}\n")

        if result.result_str == "safe":
            if Settings.RESULT_SAVE_OUTPUT_RANGES:
                dims = ss.star.a_mat.shape[0]

                for i in range(dims):
                    result.output_min[i] = ss.star.minimize_output(i)
                    result.output_max[i] = ss.star.minimize_output(i, maximize=True)

            if Settings.RESULT_SAVE_STARS:
                ss.star.lpi.serialize()
                result.stars.append(ss.star)
    except:
        if Settings.PRINT_OUTPUT:
            print("\n")
            traceback.print_exc()

        print(f"\nPresolver had exception")

        # pop timers until entry_timer is current timer
        if entry_timer is None:
            while Timers.stack:
                Timers.toc(Timers.stack[-1].name)
        else:
            while Timers.stack[-1].name != entry_timer.name:
                Timers.toc(Timers.stack[-1].name)
        
        result.result_str = "error"

    Timers.toc('presolver')
        
    return result
    
def presolver_advance(ss, zonos, network, num_steps=np.inf):
    '''advance an approx star and multi-zonos all the way through the network

    num_steps indicates the maximum number of steps to advance (used when testing)
    '''

    Timers.tic('presolver_advance')

    if zonos.zonos:
        init_gens = zonos.zonos[0].mat_t.shape[1]
        output(f"Initial overapprox zono has {init_gens} generators")

    assert ss.prefilter is None

    step_num = 0

    while ss.cur_layer < len(network.layers) and step_num < num_steps:
        step_num += 1
        cur_layer = ss.cur_layer
        
        if ss.next_neuron_index == -1:
            ####### linear transformation #######
            layer = network.layers[cur_layer]

            if not isinstance(layer, FullyConnectedLayer):
                raise NotImplementedError('unsupported layer type in presolver')

            ss.transform_fully_connected(layer)
            zonos.transform_fully_connected(layer)
            
            #ss.apply_linear_map(layer.weights, layer.biases, layer.has_relu)
            #zonos.apply_linear_map(layer.weights, layer.biases)
        else:
            ####### ReLU #######
            layer_bounds = zonos.get_box_bounds()

            #print(f"before LP: {layer_bounds}")

            if Settings.PRESOLVER_LP:
                update_bounds_lp(layer_bounds, ss)
            
            zonos.update_with_bounds(layer_bounds)

            # execute relus right away
            ss.execute_relus_overapprox(layer_bounds)

            if zonos.zonos:
                num_gens = zonos.zonos[0].mat_t.shape[1]
                output(f"After layer {cur_layer}, overapprox zono has {num_gens - init_gens} new generators")

    Timers.toc('presolver_advance')

def update_bounds_lp(layer_bounds, ss):
    'update the passed in bounds using an lp solver (if two-sided)'

    for i, bounds in enumerate(layer_bounds):
        lb, ub = bounds

        if lb < 0 < ub:
            ub_first = -lb < ub
            
            # recompute bounds
            if ub_first:
                # try upper bound fider
                ub = ss.star.minimize_output(i, maximize=True)
            else:
                lb = ss.star.minimize_output(i)

            if lb >= 0 or ub <= 0:
                # branch was rejected, done
                layer_bounds[i] = (lb, ub)
                
                #print(f"{i}: rejected branch after one LP")
                continue

            # try the other side
            if ub_first:
                lb = ss.star.minimize_output(i)
            else:
                ub = ss.star.minimize_output(i, maximize=True)

            layer_bounds[i] = (lb, ub)
            #print(f"computed both bounds {i}: {lb, ub}")
        #else:
        #    print(f"skipping both bounds {i}")
            

class MultiZono(Freezable):
    'multiple zonotopes prefilter'

    def __init__(self, uncompressed_init_box):

        self.zonos = [] # list of prefilter zonotopes
        self.zono_bounds = [] # list of bounds

        self.dims = len(uncompressed_init_box)

        if Settings.COMPRESS_INPUTS:
            init_bm, init_bias, init_box = compress_init_box(uncompressed_init_box)
        else:
            dims = len(uncompressed_init_box)

            init_bm = np.identity(dims)
            init_bias = np.zeros((dims,), dtype=float)
            init_box = uncompressed_init_box
            
        num_zonos = sum([Settings.PRESOLVER_BEST_AREA_ZONO, Settings.PRESOLVER_INTERVAL_ZONO, \
                                   Settings.PRESOLVER_YBLOAT_ZONO])

        if num_zonos == 0:
            assert Settings.PRESOLVER_LP, "presolver num_zonos was 0 and PRESOLVER_LP was False"

        for _ in range(num_zonos):
            zono = zono_from_compressed_init_box(init_bm, init_bias, init_box)
            self.zonos.append(zono)
            self.zono_bounds.append(None) # assigned later

        self.freeze_attrs()

    def might_violate_spec(self, spec):
        'might the spec be violated by the union of the current zonos?'

        # if any of them doesn't violate the spec, we're done

        rv = True

        for zono in self.zonos:
            if not spec.zono_might_violate_spec(zono):
                rv = False
                break

        return rv

    def transform_fully_connected(self, layer):
        'apply fully connected layer linear transform to the prefilter zonos'

        self.dims = layer.biases.size

        # zonotopes
        for z in self.zonos:
            layer.transform_zono(z)
            
            #z.mat_t = np.dot(layer_mat, z.mat_t)
            #z.center = np.dot(layer_mat, z.center) + bias_vec

    def get_box_bounds(self):
        '''get zonotope box bounds

        This returns an intersection of the box bounds of each of the zonotopes, since they're all a valid overapprox
        '''

        # use prefilter
        tightest_bounds = [(-np.inf, np.inf) for _ in range(self.dims)]

        for zono_index, z in enumerate(self.zonos):
            zono_bounds = z.box_bounds()

            self.zono_bounds[zono_index] = zono_bounds

            # use the tighter of the two bounds
            for dim, (lb, ub) in enumerate(tightest_bounds):

                if ub < 0 or lb > 0:
                    continue # one-sided; dont need to tighten

                z_lb, z_ub = zono_bounds[dim]

                #if z_lb > lb or z_ub < ub:
                #    print(f"id {id_index}, bounds were tighter for zono {zono_index} in dim {dim}!")
                #    print(f"old bounds: {lb, ub}, new bounds: {z_lb, z_ub}")

                tightest_bounds[dim] = (max(lb, z_lb), min(ub, z_ub))

        return tightest_bounds

    def update_with_bounds(self, layer_bounds):
        'update the zonotopes with the passed-in bounds, which may be tighter than the individual zonotope bounds'

        relu_update_funcs = []

        # check if we need to create all zonotopes

        if Settings.PRESOLVER_BEST_AREA_ZONO:
            relu_update_funcs.append(relu_update_best_area_zono)

        if Settings.PRESOLVER_INTERVAL_ZONO:
            relu_update_funcs.append(relu_update_interval_zono)

        if Settings.PRESOLVER_YBLOAT_ZONO:
            relu_update_funcs.append(relu_update_ybloat_zono)

        assert len(self.zonos) == len(relu_update_funcs)

        for zono_index, z in enumerate(self.zonos):
            # this assumes apply_linear_map was done first, so that only ReLU processing remains
            assert len(z.center) == len(layer_bounds), "zonotope dims is wrong"

            bounds = layer_bounds if Settings.PRESOLVER_USE_LAYER_BOUNDS_OPT else self.zono_bounds[zono_index]

            gen_mat_t = z.mat_t
            center = z.center
            new_generators = []

            # these are the bounds on the input for each neuron in the current layer
            for i, (lb, ub) in enumerate(bounds):

                if ub <= 0:
                    # output = zeros
                    center[i] = 0
                    gen_mat_t[i] = 0

                elif lb >= 0:
                    # output = input
                    # center[i] stays the same
                    pass
                else:
                    relu_update_func = relu_update_funcs[zono_index]
                    # need to add a new generator for the overapproximation
                    new_gen = np.zeros((gen_mat_t.shape[0],), dtype=float)
                    new_generators.append(new_gen)

                    relu_update_func(lb, ub, i, gen_mat_t, center, new_gen)

            if new_generators:
                # need to update zonotope with new generators
                z.init_bounds += [(-1, 1) for _ in range(len(new_generators))]
                new_gen_t = np.array(new_generators).transpose().copy()
                z.mat_t = np.hstack([z.mat_t, new_gen_t])

def relu_update_interval_zono(_lb, ub, output_dim, gen_mat_t, center, new_gen):
    '''update one dimension (output) of a zonotope due to a relu split
    This function produces the interval zonotope.
    '''

    gen_mat_t[output_dim] = 0
    
    y_offset = ub / 2.0
    center[output_dim] = y_offset

    new_gen[output_dim] = y_offset

def relu_update_ybloat_zono(lb, _ub, output_dim, _gen_mat_t, center, new_gen):
    '''update one dimension (output) of a zonotope due to a relu split
    This function produces the ybloat zonotope (new generator is vertical).
    '''

    y_offset = -lb / 2.0

    center[output_dim] += y_offset
    new_gen[output_dim] = y_offset

def relu_update_best_area_zono(lb, ub, output_dim, gen_mat_t, center, new_gen):
    '''update one dimension (output) of a zonotope due to a relu split
    This function produces the best-area zonotope.
    '''

    slope_lambda = ub / (ub - lb) 
    gen_mat_t[output_dim] *= slope_lambda

    # add new generator value to bm
    mu = -1 * (ub * lb) / (2 * (ub - lb))
    new_gen[output_dim] = mu

    # modify center
    center[output_dim] = center[output_dim] * slope_lambda + mu
