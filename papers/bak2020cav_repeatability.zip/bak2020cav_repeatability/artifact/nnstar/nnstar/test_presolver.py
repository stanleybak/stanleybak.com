'''
Tests for overapprox star and presolver
'''

import matplotlib.pyplot as plt

import numpy as np

from nnstar.lp_star_state import LpStarState
from nnstar.settings import Settings
from nnstar.presolver import presolver_advance, MultiZono
from nnstar.network import FullyConnectedLayer, NeuralNetwork, weights_biases_to_nn
from nnstar import util

def setup_function(_):
    '''setup method for each test'''

    Settings.reset()
    Settings.NUM_PROCESSES = 1 # don't use parallelism

def test_simple_relu():
    'test simple relu behavior'

    init_box = [[-10, 5]]

    ss = LpStarState(init_box)
    ss.prefilter = None # don't use the built-in zonotope prefilter
    zonos = MultiZono(init_box)

    weights = np.array([[1.0], [1.0]], dtype=float)
    biases = np.array([0, 0], dtype=float)
    
    network = NeuralNetwork([FullyConnectedLayer(0, weights, biases, True)])
    presolver_advance(ss, zonos, network, num_steps=1)
    ss.next_neuron_index = 1 # skip neuron 0
    presolver_advance(ss, zonos, network, num_steps=1)

    assert ss.cur_layer == 1
    assert ss.next_neuron_index == -1
    
    assert len(zonos.zonos) == 3
    
    verts = ss.star.verts(xdim=0, ydim=1)

    util.assert_verts_equals(verts, [[-10, 0], [0, 0], [5, 5]])

def test_overapprox_bias():
    'test split overapprox with bias'

    init_box = [[-1, 1]]
    
    ss = LpStarState(init_box)
    ss.prefilter = None
    zonos = MultiZono(init_box)

    weights = np.array([[1.0], [1.0]], dtype=float)
    biases = np.array([0, 0.5], dtype=float)
    network = NeuralNetwork([FullyConnectedLayer(0, weights, biases, True)])
    
    presolver_advance(ss, zonos, network, num_steps=1)
    
    layer_bounds = zonos.get_box_bounds()
    assert np.allclose(layer_bounds[0], [-1, 1])
    assert np.allclose(layer_bounds[1], [-0.5, 1.5])
    
    ss.next_neuron_index = 1
    presolver_advance(ss, zonos, network, num_steps=1)
    
    assert ss.cur_layer == 1
    assert ss.next_neuron_index == -1
    
    verts = ss.star.verts(xdim=0, ydim=1)
    
    assert len(verts) > 2, f"verts was {verts}"

    util.assert_verts_equals(verts, [[-1, 0], [-0.5, 0], [1.0, 1.5]])

def test_relu_weights():
    'test more complex relu case'

    init_box = [[0, 1], [-10, 10]]

    ss = LpStarState(init_box)
    ss.prefilter = None
    zonos = MultiZono(init_box)

    weights = np.array([[2.0, 0.5], [2.0, 0.5]], dtype=float)
    biases = np.array([0.1, 0.1], dtype=float)
    
    network = NeuralNetwork([FullyConnectedLayer(0, weights, biases, True)])

    presolver_advance(ss, zonos, network, num_steps=1)
    layer_bounds = zonos.get_box_bounds()

    for i in range(2):
        assert np.allclose(layer_bounds[i], [-4.9, 7.1])
    
    ss.next_neuron_index = 1 # start at index 1
    
    presolver_advance(ss, zonos, network, num_steps=1) # execute relus

    assert ss.cur_layer == 1
    assert ss.next_neuron_index == -1

    verts = ss.star.verts(xdim=0, ydim=1)
    
    assert len(verts) > 2, f"verts was {verts}"

    util.assert_verts_equals(verts, [[-4.9, 0], [0, 0], [7.1, 7.1]])


def test_relu_zono():
    'test relu behaviors with zonotopes'

    init_box = [[0, 1]]

    ss = LpStarState(init_box)
    ss.prefilter = None

    Settings.PRESOLVER_BEST_AREA_ZONO = True
    Settings.PRESOLVER_INTERVAL_ZONO = False
    Settings.PRESOLVER_YBLOAT_ZONO = False
    
    zonos = MultiZono(init_box)

    layer1 = [[1.0], [1.0]]
    layer2 = [[1.0, 0.0], [0.0, 1.0]] # output layer (no relu)
    weights = [layer1, layer2]
    biases = [[0.0, -0.5], [-0.5, 0.0]]

    # first output should be the input to the first layer ([-0.5, 0.5])
    # second output should be the output of the first layer after ReLU
    network = weights_biases_to_nn(weights, biases)

    presolver_advance(ss, zonos, network)

    zono = zonos.zonos[0]

    # test zono plot
    zono.plot()

    util.assert_verts_equals(zono.verts(), [[-0.5, 0], [-0.5, -0.25], [0.5, 0.5], [0.5, 0.25]])
    
