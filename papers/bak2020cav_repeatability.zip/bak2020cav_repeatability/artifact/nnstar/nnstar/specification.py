'''
Stanley Bak
Specification container object
'''

import numpy as np

from nnstar.util import Freezable

from nnstar.timerutil import Timers

class DisjunctiveSpec(Freezable):
    'disjunctive specification'

    def __init__(self, spec_list):
        # unsafe is any of the specs is unsafe

        assert spec_list, "spec_list must have > 0 Specficiation objects"

        self.spec_list = spec_list

        # sanity check expected variables matches
        expected_vars = self.spec_list[0].get_num_expected_variables()

        for spec in spec_list[1:]:
            assert spec.get_num_expected_variables() == expected_vars

        self.freeze_attrs()

    def __str__(self):
        s = ""

        for spec in self.spec_list:
            if s:
                s += " or "

            s += str(spec)

    def get_num_expected_variables(self):
        'get the number of expected variables for this spec'

        return self.spec_list[0].get_num_expected_variables()

    def is_violation(self, state):
        'does this concrete state violate the specification?'

        rv = False

        for spec in self.spec_list:
            if spec.is_violation(state):
                rv = True
                break

        return rv
    
    def distance(self, state):
        '''get the minimum distance (l-1 norm) between this state and the boundary of the unsafe states
        0 = violation
        '''

        return min([spec.distance(state) for spec in self.spec_list])

    def zono_might_violate_spec(self, zono):
        '''is it possible that the zonotope violates the spec?

        returns True or False
        '''

        # strategy: check if each row individually can have a violation... necessary condition for intersection

        rv = False

        for spec in self.spec_list:
            if spec.zono_might_violate_spec(zono):
                rv = True
                break

        return rv

    def get_violation_star(self, lp_star):
        '''does this lp_star violate the spec?

        if so, return a new, non-empty star object with the violation region
        '''

        Timers.tic('get_violation_star')

        res = None

        for spec in self.spec_list:
            res = spec.get_violation_star(lp_star)

            if res is not None:
                break
            
        Timers.toc('get_violation_star')

        return res            

class Specification(Freezable):
    'specification container'

    def __init__(self, mat, rhs):
        # unsafe if there is some state where, mat * state <= rhs

        if not isinstance(mat, np.ndarray):
            assert isinstance(rhs, list)
            mat = np.array(mat, dtype=float)

        if not isinstance(rhs, np.ndarray):
            assert isinstance(rhs, list)
            rhs = np.array(rhs, dtype=float)

        self.mat = mat
        self.rhs = rhs

        assert len(rhs.shape) == 1
        assert len(rhs) == mat.shape[0]

    def __str__(self):

        s = ""

        for i, row in enumerate(self.mat):
            if s:
                s += " & "
                
            s += f"{row} <= {self.rhs[i]}"

        return s

    def get_num_expected_variables(self):
        'get the number of expected variables for this spec'

        return self.mat.shape[1]

    def is_violation(self, state):
        'does this concrete state violate the specification?'

        res = np.dot(self.mat, state)

        rv = True

        for got, ub in zip(res, self.rhs):
            if got > ub:
                rv = False
                break

        return rv

    def distance(self, state):
        '''get the minimum distance (l-1 norm) between this state and the boundary of the unsafe states
        0 = violation
        '''

        res = np.dot(self.mat, state)
        dist = 0

        for got, ub in zip(res, self.rhs):
            if got > ub:
                dist += got - ub

        return dist

    def zono_might_violate_spec(self, zono):
        '''is it possible that the zonotope violates the spec?

        sometimes we can prove it's impossible. If this returns True, though, it doesn't mean there's an
        intersection (except in the case of single-row specifications)

        returns True or False
        '''

        # strategy: check if each row individually can have a violation... necessary condition for intersection

        Timers.tic('zono_might_violate_spec')

        might_violate = True

        for i, row in enumerate(self.mat):
            min_dot = np.dot(row, zono.maximize(-1 * row))
            
            if min_dot > self.rhs[i]:
                might_violate = False
                break

        Timers.toc('zono_might_violate_spec')

        return might_violate

    def get_violation_star(self, lp_star):
        '''does this lp_star violate the spec?

        if so, return a new, non-empty star object with the violation region
        '''

        Timers.tic('get_violation_star')
        rv = None

        # optimization, first check the sufficient condition that all rows are
        # individually satifiable, since this doesn't require any copies
        is_violation = True

        for i, vec in enumerate(self.mat):
            woutput = lp_star.minimize_vec(vec, return_io=False)
            
            min_dot = np.dot(woutput, vec)
            is_violation = min_dot <= self.rhs[i]

            if not is_violation:
                break

        if is_violation:
            # constructing a new star and do exact check
            copy = lp_star.copy()

            # add constraints on the outputs

            # output = a_mat.tranpose * input_col
            
            # a_mat.transpose * self.mat.transpose
            # same as (self.mat * a_mat).transpose
            
            init_spec = np.dot(self.mat, copy.a_mat)
            lpi = copy.lpi

            init_bias = np.dot(self.mat, copy.bias)

            # use sum_spec for optimization direction (to try to get away from violation boundaries for more robsutness)
            sum_spec = init_spec[0].copy()

            for row in init_spec[1:]:
                sum_spec += row

            for i, row in enumerate(init_spec):
                lpi.add_dense_row(row, self.rhs[i] - init_bias[i])

            winput = lpi.minimize(sum_spec, fail_on_unsat=False)

            if winput is None:
                # when we check all the specification directions at the same time, there is no violaton
                is_violation = False
            else:
                is_violation = True
                rv = copy
                #woutput = np.dot(copy.a_mat, winput) + copy.bias
                #assert self.is_violation(woutput), f"witness output {woutput} was not a violation of {self}"

        Timers.toc('get_violation_star')

        return rv if is_violation else None
