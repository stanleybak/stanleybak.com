'''
LP Star State (includes enumeration state variables)
Stanley Bak
'''

import numpy as np

from nnstar.settings import Settings
from nnstar.lp_star import LpStar
from nnstar.network import FullyConnectedLayer
from nnstar.prefilter import Prefilter
from nnstar.timerutil import Timers
from nnstar.util import Freezable, compress_init_box

class LpStarState(Freezable):
    'variables and methods associated with verification using lp star representation'

    def __init__(self, uncompressed_init_box=None):
        self.star = None
        self.prefilter = None
        
        self.next_neuron_index = -1 # -1 means linear transformation is next
        self.cur_layer = 0
        self.work_frac = 1.0 # fraction of work represented by this star

        # a list of 3-tuples describing the branching taken for this star (layer_index, neuron_index, branch_type)
        # see netowork.execute for the values of branch_type used by the different layer types
        self.branch_tuples = []

        self.contracted = True

        if uncompressed_init_box is not None:
            self.from_init_box(uncompressed_init_box)

        self.freeze_attrs()

    def __str__(self):
        return f"LpStateState at layer {self.cur_layer} on neuron {self.next_neuron_index} with " + \
               f"star.a_mat.shape {self.star.a_mat.shape}"

    def from_init_box(self, uncompressed_init_box):
        'initialize from an initial box'

        if Settings.COMPRESS_INPUTS:
            init_bm, init_bias, init_box = compress_init_box(uncompressed_init_box)
        else:
            dims = len(uncompressed_init_box)

            init_bm = np.identity(dims)
            init_bias = np.zeros((dims,), dtype=float)
            init_box = uncompressed_init_box
        
        self.star = LpStar(init_bm, init_bias, init_box)

        self.prefilter = Prefilter()
        self.prefilter.init_from_uncompressed_box(uncompressed_init_box, self.star, init_box)

    def heap_item(self):
        'return a tuple representation of this StarState for use on a min-heap'

        return (self.cur_layer, self.next_neuron_index, id(self), self)

    def advance(self, network):
        '''
        advance the star through the passed-in layer up to the first split, 
        returning a new star state if splitting occurs
        '''

        rv = None
        layer = network.layers[self.cur_layer]

        # start of a new layer
        if self.next_neuron_index == -1:
            self.prefilter.clear_output_bounds()
            
            # start of a new layer
            assert isinstance(layer, FullyConnectedLayer)
            self.transform_fully_connected(layer)

        if self.next_neuron_index != -1:
            assert layer.has_relu
            
            # relu layer
            rv = self.execute_relus()

        return rv

    def transform_fully_connected(self, layer):
        'apply linear transformation part of fully connected layer'

        Timers.tic('starstate.transform_fully_connected')
        
        # star
        Timers.tic('transform_star')
        layer.transform_star(self.star)
        Timers.toc('transform_star')

        if self.prefilter and self.prefilter.zono is not None:
            # update zonotope shallow copy
            self.prefilter.zono.mat_t = self.star.a_mat
            self.prefilter.zono.center = self.star.bias

        if self.prefilter:
            self.prefilter.transform_fully_connected(layer, self.star)

        if layer.has_relu:
            self.next_neuron_index = 0
        else:
            # no ReLU; proceed to next layer
            self.cur_layer += 1
            self.next_neuron_index = -1 # -1 means linear transformation

        Timers.toc('starstate.transform_fully_connected')

    def split_enumerate(self, i):
        '''
        helper for execute_relus

        split using enumerative strategy, returns the child LpStarState object

        ss is the lp star state
        i is the output (neuron) index we're splitting on
        '''

        Timers.tic('split_enumerate')

        child = LpStarState()
        child.star = self.star.copy()
        # prefilter gets copied later

        child.contracted = False
        self.contracted = False

        child.next_neuron_index = self.next_neuron_index
        child.cur_layer = self.cur_layer

        # split work among 2 children
        self.work_frac /= 2.0
        child.work_frac = self.work_frac

        # self gets positive
        self_gets_positive = True

        if self_gets_positive:
            pos, neg = self, child
        else:
            neg, pos = self, child
            
        child.branch_tuples = self.branch_tuples.copy()
        pos.branch_tuples.append((pos.cur_layer, i, True))
        neg.branch_tuples.append((neg.cur_layer, i, False))

        ### ADD INITIAL STATE INTERSECTION
        row = self.star.a_mat[i]
        bias = self.star.bias[i]

        # pos gets output >= 0
        # neg gets output <= 0
        pos.star.lpi.add_dense_row(-row, bias)
        neg.star.lpi.add_dense_row(row, -bias)

        ### ASSIGN NEURON i OUTPUT
        # neg has 0 output
        neg.star.a_mat[i] = 0
        neg.star.bias[i] = 0 # reset the current bias as well

        Timers.tic('prefilter_split_relu')
        child.prefilter = self.prefilter.split_relu(i, pos.star, neg.star, self_gets_positive)

        if child.prefilter.zono is not None:
            assert child.prefilter.zono.mat_t is child.star.a_mat
            assert child.prefilter.zono.center is child.star.bias
        
        Timers.toc('prefilter_split_relu')

        Timers.toc('split_enumerate')

        return child

    def split_overapprox(self, new_generators_bm, i, lb, ub):
        '''helper for execute_relus_overapprox

        split a ReLU using a star overapproximation'''

        Timers.tic('split_overapprox')

        # make a new variable y for the output
        self.star.lpi.add_positive_cols([f'y{self.cur_layer}_{i}'])
        num_cols = self.star.lpi.get_num_cols()
        num_zeros = num_cols - self.star.a_mat.shape[1] - 1

        #zero_row = np.zeros((self.star.a_mat.shape[1],))

        # create 3 constraints for new variable
        # (1) y >= 0 === -y <= 0
        # this constraint is automatically added in lp_star for all non-cur variables

        # (2) y >= x[i] === x[i] - y <= 0
        # x[i] equals row i in the basis matrix (also the bias on the rhs)

        row = np.zeros((num_cols,), dtype=float)
        a_mat_width = self.star.a_mat.shape[1]

        assert a_mat_width <= num_cols, f"a_mat_width: {a_mat_width}, num_cols: {num_cols}"

        row[:a_mat_width] = self.star.a_mat[i, :]
        row[-1] = -1
        self.star.lpi.add_dense_row(row, -self.star.bias[i])

        # (3) y <= ub*(x[i]-lb) / (ub - lb) === y - ub*x[i] / (ub - lb) - (ub*(-lb) / (ub - lb)) <= 0
        # === y - ub(ub - lb) * x[i] <= ub*(-lb) / (ub - lb)
        # x[i] equals row i in the basis matrix
        factor = ub / (ub - lb)
        row = np.zeros((num_cols,), dtype=float)
        row[:self.star.a_mat.shape[1]] = -1 * factor * self.star.a_mat[i]
        row[-1] = 1
        rhs = -lb * factor + self.star.bias[i] * factor
        self.star.lpi.add_dense_row(row, rhs)

        # reset the current bias
        # the rhs of the current variable is not referenced by other constraints (constraints never ref rhs)
        self.star.bias[i] = 0

        # ReLU case, introduce new variable
        self.star.a_mat[i] = 0

        new_generators_bm[i] = [0] * num_zeros + [1]

        Timers.toc('split_overapprox')

    def execute_relus(self):
        '''
        run the relu part of the star update for the current layer up to the first split

        returns a new star (if a split occured) or None
        '''

        rv = None
        
        if Settings.PREFILTER_EAGER_BOUNDS:
            rv = self.execute_relus_eager()
        else:
            rv = self.execute_relus_noneager()

        return rv

    def execute_relus_noneager(self):
        '''
        run the relu part of the star update for the current layer up to the first split

        returns a new star (if a split occured) or None
        '''

        Timers.tic('execute_relus_noneager')

        assert not Settings.PREFILTER_EAGER_BOUNDS

        assert self.next_neuron_index >= 0
        
        rv = None
        num_neurons = self.star.a_mat.shape[0]

        while self.next_neuron_index < num_neurons:
            
            i = self.next_neuron_index
            Timers.tic('compute_output_sign')
            sign = self.prefilter.compute_output_sign(self.star, i)
            Timers.toc('compute_output_sign')
            self.next_neuron_index += 1 # increment here so child gets correct next index

            if sign == -1:
                Timers.tic('negative relu case')
                # set output in simulation to zero
                self.prefilter.set_simulation_zero(i)

                # set output to zero in star
                self.star.a_mat[i] = 0 #np.zeros((self.star.a_mat.shape[1],))
                self.star.bias[i] = 0 # reset the current bias as well

                # also in zonotope
                if self.prefilter.zono is not None:
                    assert self.prefilter.zono.mat_t is self.star.a_mat
                    assert self.prefilter.zono.center is self.star.bias
                #self.prefilter.set_zonotope_zeros((i,))

                Timers.toc('negative relu case')
            elif sign == 0: # relu split
                assert sign == 0
                # split by creating copies of the star
                rv = self.split_enumerate(i)
                assert rv.star.a_mat.shape == self.star.a_mat.shape

                break

        # proceed to next layer if finished
        if self.next_neuron_index == num_neurons:
            self.cur_layer += 1
            self.next_neuron_index = -1 # -1 means linear transformation

        Timers.toc('execute_relus_noneager')

        return rv

    def execute_relus_eager(self):
        '''
        run the relu part of the star update for the current layer up to the first split

        returns a new star (if a split occured) or None
        '''

        Timers.tic('execute_relus_eager')

        assert Settings.PREFILTER_EAGER_BOUNDS
        assert self.prefilter.output_bounds.branching_neurons is not None
        
        rv = None

        if self.prefilter.output_bounds.branching_neurons:
            index = self.prefilter.output_bounds.branching_neurons.popleft()
            rv = self.split_enumerate(index)
            assert rv.star.a_mat.shape == self.star.a_mat.shape

            self.next_neuron_index = index + 1 # update for consistency with non-eager
        else:
            # no more branches, done with current layer
            self.cur_layer += 1
            self.next_neuron_index = -1 # -1 means linear transformation

        Timers.toc('execute_relus_eager')

        return rv

    def execute_relus_overapprox(self, layer_bounds):
        '''
        run the relu part of the star update for the *entire* layer, using overapproximation instead of splitting
        '''

        Timers.tic('execute_relus_overapprox')

        assert self.next_neuron_index >= 0
        assert self.prefilter is None, "prefilter should be disabled for overapprox"

        ss = self

        num_outputs = ss.star.a_mat.shape[0]
        assert len(layer_bounds) == num_outputs, f"outputs is {num_outputs}, but num " + \
            f"layer bounds {len(layer_bounds)}"

        new_generators_bm = [[] for _ in range(num_outputs)]

        for i in range(self.next_neuron_index, num_outputs):
            lb, ub = layer_bounds[i]
            
            if ub <= 0:
                # output = zeros
                ss.star.a_mat[i] = 0 #np.zeros((ss.star.a_mat.shape[1],))
                ss.star.bias[i] = 0 # reset the current bias as well
                #ss.cur_layer_bounds[i] = (0, 0) # update layer bounds
            elif lb >= 0:
                # output = input
                pass
            else: # relu overapprox
                self.split_overapprox(new_generators_bm, i, lb, ub)

        Timers.tic('overapprox bm update')
        num_zeros = self.star.lpi.get_num_cols() - self.star.a_mat.shape[1]

        if num_zeros > 0:
            for bm_row in new_generators_bm:
                bm_row += [0] * (num_zeros - len(bm_row))

            self.star.a_mat = np.hstack([self.star.a_mat, new_generators_bm])
            assert self.star.a_mat.shape[1] == self.star.lpi.get_num_cols()

        Timers.toc('overapprox bm update')

        # proceed to next layer
        ss.cur_layer += 1
        ss.next_neuron_index = -1 # -1 means linear transformation

        Timers.toc('execute_relus_overapprox')
