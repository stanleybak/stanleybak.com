'''
Tests for full neural network execution
'''

from scipy.io import loadmat
import numpy as np

from nnstar.network import PoolingLayer, Convolutional2dLayer, FullyConnectedLayer, NeuralNetwork, images_to_init_box
from nnstar import network
from nnstar.settings import Settings
from nnstar.enumerate import enumerate_network

def setup_function(_):
    '''setup method for each test'''

    Settings.reset()
    Settings.NUM_PROCESSES = 1 # don't use parallelism during tests unless explicitly stated

def load_sample_conv():
    'load a CNN and return it'

    matfile = loadmat('../examples/networks/conv_test/test_data_tran.mat')

    layers = []

    # weights in file is <height, width, input_channels, output_channels
    # but we expect <output_channels, input_channels, height, width>

    layer_num = len(layers)
    weights = matfile['conv1_weights']
    weights = weights.transpose((3, 2, 0, 1))
    biases = matfile['conv1_bias']
    biases.shape = (biases.shape[-1], ) # expected single-dim bias
    prev_layer_output_shape = (28, 28, 1)
    layers.append(Convolutional2dLayer(layer_num, weights, biases, True, prev_layer_output_shape))
    prev_layer_output_shape = layers[-1].get_output_shape()

    # max pooling layer
    layer_num = len(layers)
    layers.append(PoolingLayer(layer_num, 2, prev_layer_output_shape))
    prev_layer_output_shape = layers[-1].get_output_shape()

    layer_num = len(layers)
    weights = matfile['conv2_weights']
    weights = weights.transpose((3, 2, 0, 1))
    biases = matfile['conv2_bias']
    biases.shape = (biases.shape[-1], ) # expected single-dim bias
    layers.append(Convolutional2dLayer(layer_num, weights, biases, True, prev_layer_output_shape))
    prev_layer_output_shape = layers[-1].get_output_shape()

    # fully connected layer
    layer_num = len(layers)
    weights = matfile['fc_weights']
    biases = matfile['fc_bias']
    biases.shape = (biases.shape[0], ) # expected single-dim bias
    has_relu = False
    layers.append(FullyConnectedLayer(layer_num, weights, biases, has_relu, prev_layer_output_shape))

    ##########
    nn = NeuralNetwork(layers)
    avg_image = matfile['averageImage']

    return nn, avg_image
    
def test_exec_cnn():
    'test a CNN execution'

    nn, avg_image = load_sample_conv()
    
    image_data = loadmat('../examples/networks/conv_test/test_images_tran.mat')

    for index in [1, 500]:

        orig_image = np.array(image_data['IM_data'][:, :, index], dtype=float)
        im0 = orig_image - avg_image
        im0.shape = (28, 28, 1)

        out = nn.execute(im0)

        got = np.argmax(out)
        expected = image_data['IM_labels'][index, 0] - 1

        assert got == expected # images 1 and 500 classify correctly

def test_exec_cnn_flat():
    'test a CNN execution with a flat state'

    nn, avg_image = load_sample_conv()
    
    image_data = loadmat('../examples/networks/conv_test/test_images_tran.mat')
    index = 1

    orig_image = np.array(image_data['IM_data'][:, :, index], dtype=float)
    im0 = orig_image - avg_image
    im0.shape = (28, 28, 1)

    # execute normally
    normal_output = nn.execute(im0)

    # execute manually layer by layer with flattened state
    state = network.nn_flatten(im0)

    for layer in nn.layers:
        state = network.nn_unflatten(state, layer.get_input_shape())

        state = layer.execute(state)

        state = network.nn_flatten(state)

    # compare outputs
    assert np.allclose(state, normal_output)

