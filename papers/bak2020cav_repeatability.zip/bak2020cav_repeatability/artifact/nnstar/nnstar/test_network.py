'Tests for network.py'

import numpy as np

from network import FullyConnectedLayer, NeuralNetwork, Convolutional2dLayer, PoolingLayer
import network

def test_relu():
    'test single-layer relu network'

    weights = [[1], [2]]
    biases = [0, -1]

    layer0 = FullyConnectedLayer(0, np.array(weights, dtype=float), np.array(biases, dtype=float), True)
    layer1 = FullyConnectedLayer(1, np.identity(2), np.array([0, 0], dtype=float), False)

    net = NeuralNetwork([layer0, layer1])

    net.check_io()

    out = net.execute([0.25])

    assert np.allclose(out, [0.25, 0])

    assert str(net) == '[NeuralNetwork with 2 layers with (1,) input and (2,) output]'
    assert str(net.layers[0]) == f'[FullyConnectedLayer (with ReLU) with (1,) input and (2,) output]'

    assert net.get_num_inputs() == 1
    assert net.get_num_outputs() == 2

    out, branch_list = net.execute([0.25], save_branching=True)

    assert branch_list == [[True, False], []]

def test_convert():
    'test convert_weights and convert_biases'

    weights = [np.identity(3), np.identity(3)]

    res = network.convert_weights(weights)
    assert isinstance(res, np.ndarray)
    assert np.allclose(res[0], np.identity(3))
    
    biases = [[0, 0, 0], [1, 2, 3]]
    res = network.convert_biases(biases)

    assert isinstance(res, np.ndarray)
    assert np.allclose(res[1], [1, 2, 3])
   
    nn = network.weights_biases_to_nn(weights, biases)

    assert len(nn.layers) == 2
    assert nn.get_num_inputs() == 3
    assert nn.get_num_outputs() == 3

def test_convolutional2d_layer():
    '''test convolutional2d layer from 
    https://medium.com/apache-mxnet/multi-channel-convolutions-explained-with-ms-excel-9bbf8eb77108
    '''

    input1 = [[1, 0, 1, 0, 2],
              [1, 1, 3, 2, 1],
              [1, 1, 0, 1, 1],
              [2, 3, 2, 1, 3],
              [0, 2, 0, 1, 0]]

    input2 = [[1, 0, 0, 1, 0],
              [2, 0, 1, 2, 0],
              [3, 1, 1, 3, 0],
              [0, 3, 0, 3, 2],
              [1, 0, 3, 2, 1]]

    input3 = [[2, 0, 1, 2, 1],
              [3, 3, 1, 3, 2],
              [2, 1, 1, 1, 0],
              [3, 1, 3, 2, 0],
              [1, 1, 2, 1, 1]]

    inputs = np.array([input1, input2, input3], dtype=float)

    # convert to y, x, z
    inputs = inputs.transpose((1, 2, 0))

    kernel1 = [[0, 1, 0], [0, 0, 2], [0, 1, 0]]
    kernel2 = [[2, 1, 0], [0, 0, 0], [0, 3, 0]]
    kernel3 = [[1, 0, 0], [1, 0, 0], [0, 0, 2]]
    kernels = np.array([[kernel1, kernel2, kernel3]], dtype=float)

    # expected shape is # output channels, # input channels, x, y

    # one bias per output
    biases = np.zeros((1, ), dtype=float)

    prev_layer_output_shape = (5, 5, 3)
    layer = Convolutional2dLayer(0, kernels, biases, True, prev_layer_output_shape, mode='valid')

    assert str(layer) == "[Convolutional2dLayer (with ReLU) with (5, 5, 3) input and (3, 3, 1) output]"

    out, branching = layer.execute(inputs, save_branching=True)

    assert out.shape == (3, 3, 1)

    assert branching == [True] * 9

    out.shape = (3, 3)
    assert np.allclose(out,
                       [[19, 13, 15],
                        [28, 16, 20],
                        [23, 18, 25]])

def test_full_conv():
    '''test convolutional2d layer using default conv2d settings
    '''

    input1 = [[1, 0, 1, 0, 2],
              [1, 1, 3, 2, 1],
              [1, 1, 0, 1, 1],
              [2, 3, 2, 1, 3],
              [0, 2, 0, 1, 0]]

    input2 = [[1, 0, 0, 1, 0],
              [2, 0, 1, 2, 0],
              [3, 1, 1, 3, 0],
              [0, 3, 0, 3, 2],
              [1, 0, 3, 2, 1]]

    input3 = [[2, 0, 1, 2, 1],
              [3, 3, 1, 3, 2],
              [2, 1, 1, 1, 0],
              [3, 1, 3, 2, 0],
              [1, 1, 2, 1, 1]]

    inputs = np.array([input1, input2, input3], dtype=float)

    # convert to y, x, z
    inputs = inputs.transpose((1, 2, 0))

    kernel1 = [[0, 1, 0], [0, 0, 2], [0, 1, 0]]
    kernel2 = [[2, 1, 0], [0, 0, 0], [0, 3, 0]]
    kernel3 = [[1, 0, 0], [1, 0, 0], [0, 0, 2]]
    kernels = np.array([[kernel1, kernel2, kernel3]], dtype=float)

    # one bias per output
    biases = np.zeros((1, ), dtype=float)
    prev_layer_output_shape = (5, 5, 3)

    layer = Convolutional2dLayer(0, kernels, biases, True, prev_layer_output_shape)

    assert str(layer) == "[Convolutional2dLayer (with ReLU) with (5, 5, 3) input and (5, 5, 1) output]"

    out = layer.execute(inputs)
    assert out.shape == (5, 5, 1)
    out.shape = (5, 5)

    assert np.allclose(out,
                       [[[13, 7, 12, 17, 3],
                         [16, 19, 13, 15, 10],
                         [9, 28, 16, 20, 18],
                         [15, 23, 18, 25, 13],
                         [6, 10, 12, 9, 14]]])

def test_large_conv_connected():
    'test larger 2d convoluton connected to a fully connected layer'

    np.random.seed(0)
    
    kernel = np.random.random((1, 3, 3, 3))

    image = np.random.random((224, 224, 3))

    # one bias per output
    biases = np.zeros((1, ), dtype=float)
    prev_layer_output_shape = (224, 224, 3)
   
    layer = Convolutional2dLayer(0, kernel, biases, False, prev_layer_output_shape)

    # connect a fully connected layer
    inputs = 224 * 224
    weights_fc = np.random.random((10, inputs))
    biases_fc = np.random.random((10,))
    has_relu = True
    
    layer2 = FullyConnectedLayer(0, weights_fc, biases_fc, has_relu, prev_layer_output_shape=layer.get_output_shape())
    assert layer2.get_input_shape() == layer.get_output_shape()

    out = layer.execute(image)
        
    assert out.shape == (224, 224, 1)

    # execute fully connected layer
    out2 = layer2.execute(out)

    assert out2.shape == (10, )

def test_max_pool_execute():
    'test max pooling layer'

    input1 = [[1, 0, 1, 0],
              [1, 1, 5, 2],
              [1, 1, 0, 1],
              [2, 3, 2, 1]]

    input2 = [[1, 0, 0, 1],
              [2, 0, 1, 2],
              [3, 1, 1, 3],
              [0, 3, 0, 4]]

    inputs = np.array([input1, input2], dtype=float)

    # convert to y, x, z
    inputs = inputs.transpose((1, 2, 0))

    input_shape = (4, 4, 2)
    layer = PoolingLayer(0, 2, input_shape)

    # layer input and output should be undefined
    assert layer.get_input_shape() == input_shape
    assert layer.get_output_shape() == (2, 2, 2)

    assert str(layer) == "[PoolingLayer (max) 2x2 with stride 2, input shape (4, 4, 2) and output shape (2, 2, 2)]"

    out1 = layer.execute(inputs)

    out2, branch_list = layer.execute(inputs, save_branching=True)

    expected = np.array([[[1, 5], [3, 2]], [[2, 2], [3, 4]]], dtype=float)
    expected = expected.transpose((1, 2, 0))

    assert np.allclose(out2, expected)

    assert np.allclose(out1, out2)
    assert branch_list == [[0, 2, 3], 2, 3, 2, \
                           2, 3, [0, 3], 3]
    #"02322303"

def test_mean_pool():
    'test mean pooling layer'

    input1 = [[1, 0, 1, 0],
              [1, 1, 5, 2],
              [1, 1, 0, 1],
              [2, 3, 2, 1]]

    input2 = [[1, 0, 0, 1],
              [2, 0, 1, 2],
              [3, 1, 1, 3],
              [0, 3, 0, 4]]

    inputs = np.array([input1, input2], dtype=float)

    # convert to y, x, z
    inputs = inputs.transpose((1, 2, 0))

    input_shape = (4, 4, 2)
    layer = PoolingLayer(0, 2, input_shape, method='mean')

    assert str(layer) == "[PoolingLayer (mean) 2x2 with stride 2, input shape (4, 4, 2) and output shape (2, 2, 2)]"

    out1 = layer.execute(inputs)

    out2, branch_list = layer.execute(inputs, save_branching=True)

    expected = np.array([[[0.75, 2], [1.75, 1]], [[0.75, 1], [1.75, 2]]], dtype=float)
    expected = expected.transpose((1, 2, 0))

    assert np.allclose(out2, expected)

    assert np.allclose(out1, out2)
    assert branch_list == []

def test_large_maxpool():
    'test larger max pool'

    np.random.seed(0)

    image = np.random.random((224, 224, 3))

    input_shape = (224, 224, 4)
    layer = PoolingLayer(0, 2, input_shape)

    out_mine, _ = layer.execute(image, save_branching=True)
    assert out_mine.shape == (112, 112, 3)

    out_theirs = layer.execute(image, save_branching=False)
    assert out_theirs.shape == (112, 112, 3)

    assert np.allclose(out_mine, out_theirs)

def test_flatten_fc():
    'test flatting before a fully connected layer (should be fortran order)'

    # from tran's test network, it looks like flattening is done in fortran order before fully connected layers

    weights = np.identity(4)
    biases = [0, 0, 0, 0]

    expected_shape = (2, 2)
    layer = FullyConnectedLayer(0, np.array(weights, dtype=float), np.array(biases, dtype=float), False, expected_shape)

    i = np.array([[1, 2], [3, 4]])
    o = layer.execute(i)

    assert np.allclose(o, [1, 3, 2, 4])

def test_flatten_unflatten():
    'test flatten and unflatten of an image'

    input1 = [[1, 0, 1, 0, 2],
              [1, 1, 3, 2, 1],
              [1, 1, 0, 1, 1],
              [2, 3, 2, 1, 3],
              [0, 2, 0, 1, 0]]

    input2 = [[1, 0, 0, 1, 0],
              [2, 0, 1, 2, 0],
              [3, 1, 1, 3, 0],
              [0, 3, 0, 3, 2],
              [1, 0, 3, 2, 1]]

    input3 = [[2, 0, 1, 2, 1],
              [3, 3, 1, 3, 2],
              [2, 1, 1, 1, 0],
              [3, 1, 3, 2, 0],
              [1, 1, 2, 1, 1]]

    inputs = np.array([input1, input2, input3], dtype=float)

    # convert to y, x, z
    inputs = inputs.transpose((1, 2, 0))

    original = inputs.copy()

    preshape = inputs.shape
    inputs_flat = network.nn_flatten(inputs)
    inputs_unflattened = network.nn_unflatten(inputs_flat, preshape)

    assert np.allclose(original, inputs_unflattened)

def test_convolutional2d_layer():
    '''test convolutional2d layer from 
    https://medium.com/apache-mxnet/multi-channel-convolutions-explained-with-ms-excel-9bbf8eb77108
    '''

    input1 = [[1, 0, 1, 0, 2],
              [1, 1, 3, 2, 1],
              [1, 1, 0, 1, 1],
              [2, 3, 2, 1, 3],
              [0, 2, 0, 1, 0]]

    input2 = [[1, 0, 0, 1, 0],
              [2, 0, 1, 2, 0],
              [3, 1, 1, 3, 0],
              [0, 3, 0, 3, 2],
              [1, 0, 3, 2, 1]]

    input3 = [[2, 0, 1, 2, 1],
              [3, 3, 1, 3, 2],
              [2, 1, 1, 1, 0],
              [3, 1, 3, 2, 0],
              [1, 1, 2, 1, 1]]

    inputs = np.array([input1, input2, input3], dtype=float)

    # convert to y, x, z
    inputs = inputs.transpose((1, 2, 0))

    kernel1 = [[0, 1, 0], [0, 0, 2], [0, 1, 0]]
    kernel2 = [[2, 1, 0], [0, 0, 0], [0, 3, 0]]
    kernel3 = [[1, 0, 0], [1, 0, 0], [0, 0, 2]]
    kernels = np.array([[kernel1, kernel2, kernel3]], dtype=float)

    # expected shape is # output channels, # input channels, x, y

    # one bias per output
    biases = np.zeros((1, ), dtype=float)

    prev_layer_output_shape = (5, 5, 3)
    layer = Convolutional2dLayer(0, kernels, biases, True, prev_layer_output_shape, mode='valid')

    assert str(layer) == "[Convolutional2dLayer (with ReLU) with (5, 5, 3) input and (3, 3, 1) output]"

    out, branching = layer.execute(inputs, save_branching=True)

    assert out.shape == (3, 3, 1)

    assert branching == [True] * 9

    out.shape = (3, 3)
    assert np.allclose(out,
                       [[19, 13, 15],
                        [28, 16, 20],
                        [23, 18, 25]])

def test_full_conv():
    '''test convolutional2d layer using default conv2d settings
    '''

    input1 = [[1, 0, 1, 0, 2],
              [1, 1, 3, 2, 1],
              [1, 1, 0, 1, 1],
              [2, 3, 2, 1, 3],
              [0, 2, 0, 1, 0]]

    input2 = [[1, 0, 0, 1, 0],
              [2, 0, 1, 2, 0],
              [3, 1, 1, 3, 0],
              [0, 3, 0, 3, 2],
              [1, 0, 3, 2, 1]]

    input3 = [[2, 0, 1, 2, 1],
              [3, 3, 1, 3, 2],
              [2, 1, 1, 1, 0],
              [3, 1, 3, 2, 0],
              [1, 1, 2, 1, 1]]

    inputs = np.array([input1, input2, input3], dtype=float)

    # convert to y, x, z
    inputs = inputs.transpose((1, 2, 0))

    kernel1 = [[0, 1, 0], [0, 0, 2], [0, 1, 0]]
    kernel2 = [[2, 1, 0], [0, 0, 0], [0, 3, 0]]
    kernel3 = [[1, 0, 0], [1, 0, 0], [0, 0, 2]]
    kernels = np.array([[kernel1, kernel2, kernel3]], dtype=float)

    # one bias per output
    biases = np.zeros((1, ), dtype=float)
    prev_layer_output_shape = (5, 5, 3)

    layer = Convolutional2dLayer(0, kernels, biases, True, prev_layer_output_shape)

    assert str(layer) == "[Convolutional2dLayer (with ReLU) with (5, 5, 3) input and (5, 5, 1) output]"

    out = layer.execute(inputs)
    assert out.shape == (5, 5, 1)
    out.shape = (5, 5)

    assert np.allclose(out,
                       [[[13, 7, 12, 17, 3],
                         [16, 19, 13, 15, 10],
                         [9, 28, 16, 20, 18],
                         [15, 23, 18, 25, 13],
                         [6, 10, 12, 9, 14]]])

def test_large_conv_connected():
    'test larger 2d convoluton connected to a fully connected layer'

    np.random.seed(0)
    
    kernel = np.random.random((1, 3, 3, 3))

    image = np.random.random((224, 224, 3))

    # one bias per output
    biases = np.zeros((1, ), dtype=float)
    prev_layer_output_shape = (224, 224, 3)
   
    layer = Convolutional2dLayer(0, kernel, biases, False, prev_layer_output_shape)

    # connect a fully connected layer
    inputs = 224 * 224
    weights_fc = np.random.random((10, inputs))
    biases_fc = np.random.random((10,))
    has_relu = True
    
    layer2 = FullyConnectedLayer(0, weights_fc, biases_fc, has_relu, prev_layer_output_shape=layer.get_output_shape())
    assert layer2.get_input_shape() == layer.get_output_shape()

    out = layer.execute(image)
        
    assert out.shape == (224, 224, 1)

    # execute fully connected layer
    out2 = layer2.execute(out)

    assert out2.shape == (10, )
