'''
Stanley Bak
Tests for prefilter
'''

import numpy as np

from nnstar.settings import Settings
from nnstar.network import FullyConnectedLayer, NeuralNetwork
from nnstar.enumerate import enumerate_network

def setup_function(_):
    '''setup method for each test'''

    Settings.reset()
    Settings.NUM_PROCESSES = 1 # don't use parallelism during tests unless explicitly stated

def test_no_prefilter_lazy_bounds():
    'test without a prefilter, lazy bounds'

    Settings.PREFILTER_TYPE = Settings.TYPE_NO_PREFILTER

    Settings.PREFILTER_EAGER_BOUNDS = False
    Settings.RESULT_SAVE_STARS = True

    weights = [[1, 0], [0, 1]]
    biases = [0, 0]

    layer0 = FullyConnectedLayer(0, np.array(weights, dtype=float), np.array(biases, dtype=float), True)
    #layer1 = FullyConnectedLayer(1, np.identity(2), np.array([0, 0], dtype=float), False)

    net = NeuralNetwork([layer0])
    
    init_box = [[-1, 2], [1, 2]]

    res = enumerate_network(init_box, net)
    assert res.result_str != "error"

    stars = res.stars

    assert len(stars) == 2
    assert res.total_lps == 6 # 2 lps for first split, and 2 in each of the children stars for second split

def test_no_prefilter_eager_bounds():
    'test without a prefilter, lazy bounds'

    Settings.PREFILTER_TYPE = Settings.TYPE_NO_PREFILTER

    Settings.PREFILTER_EAGER_BOUNDS = True
    Settings.RESULT_SAVE_STARS = True

    weights = [[1, 0], [0, 1]]
    biases = [0, 0]

    layer0 = FullyConnectedLayer(0, np.array(weights, dtype=float), np.array(biases, dtype=float), True)
    #layer1 = FullyConnectedLayer(1, np.identity(2), np.array([0, 0], dtype=float), False)

    net = NeuralNetwork([layer0])
    
    init_box = [[-1, 2], [1, 2]]

    res = enumerate_network(init_box, net)
    assert res.result_str != "error"

    stars = res.stars

    assert len(stars) == 2
    assert res.total_lps == 4 # 4 lps before first split, no more after that

def test_sim_prefilter():
    'test with only simulation prefilter'

    Settings.PREFILTER_TYPE = Settings.TYPE_SIM_PREFILTER
    Settings.RESULT_SAVE_STARS = True
    Settings.PREFILTER_EAGER_BOUNDS = True

    init_box = [[0, 1]]
    weights = [[1], [2]]
    biases = [0, -1]

    layer0 = FullyConnectedLayer(0, np.array(weights, dtype=float), np.array(biases, dtype=float), True)
    #layer1 = FullyConnectedLayer(1, np.identity(2), np.array([0, 0], dtype=float), False)

    net = NeuralNetwork([layer0])

    res = enumerate_network(init_box, net)
    assert res.result_str != "error"

    stars = res.stars

    assert len(stars) == 2
    assert res.total_lps == 3 # simulation lands on zero so two lps are needed for second output

def test_zono_prefilter_noeager():
    '''test with zonotope prefilter without eager computation
    '''

    # in this example the zonotope analysis is able to reject all potential branches

    Settings.PREFILTER_TYPE = Settings.TYPE_ZONO_PREFILTER
    Settings.CONTRACT_ZONOTOPE = False
    Settings.RESULT_SAVE_STARS = True
    Settings.PREFILTER_EAGER_BOUNDS = False

    init_box = [[0, 1]]
    weights = [[1], [2]]
    biases = [0, -10]

    # expected input bounds to be: [0, 1] and [-10, -8]

    layer0 = FullyConnectedLayer(0, np.array(weights, dtype=float), np.array(biases, dtype=float), True)
    #layer1 = FullyConnectedLayer(1, np.identity(2), np.array([0, 0], dtype=float), False)

    net = NeuralNetwork([layer0])


    res = enumerate_network(init_box, net)
    assert res.result_str != "error"

    stars = res.stars

    assert len(stars) == 1
    assert res.total_lps == 0 # simulation lands on zero so two lps are needed for second output

def test_zono_prefilter_eager():
    '''test with zonotope prefilter with eager computation and a split
    '''

    Settings.PREFILTER_TYPE = Settings.TYPE_ZONO_PREFILTER
    Settings.CONTRACT_ZONOTOPE = False
    Settings.RESULT_SAVE_STARS = True

    init_box = [[0, 1]]
    weights = [[1], [2]]
    biases = [-0.1, -10]

    # expected input bounds to be: [-0.1, 0.9] and [-10, -8]

    layer0 = FullyConnectedLayer(0, np.array(weights, dtype=float), np.array(biases, dtype=float), True)

    net = NeuralNetwork([layer0])

    res = enumerate_network(init_box, net)
    assert res.result_str != "error"

    stars = res.stars

    assert len(stars) == 2
    assert res.total_lps == 1 # simulation lands on zero so two lps are needed for second output

def test_prefilter_lp_contract():
    '''test with zonotope prefilter with lp contraction
    '''

    Settings.PREFILTER_TYPE = Settings.TYPE_ZONO_PREFILTER
    Settings.CONTRACT_ZONOTOPE = False
    Settings.CONTRACT_ZONOTOPE_LP = True
    Settings.RESULT_SAVE_STARS = True

    init_box = [[0, 1]]
    weights = [[1], [2]]
    biases = [-0.1, -10]

    # expected input bounds to be: [-0.1, 0.9] and [-10, -8]

    layer0 = FullyConnectedLayer(0, np.array(weights, dtype=float), np.array(biases, dtype=float), True)

    net = NeuralNetwork([layer0])

    res = enumerate_network(init_box, net)
    assert res.result_str != "error"

    stars = res.stars

    assert len(stars) == 2
    assert res.total_lps == 1 # simulation lands on zero so two lps are needed for second output
