'''
Measurement script parlallel performance comparison on Property 2, network (4, 2)
'''

import sys
import os
import time
import subprocess
import math

from termcolor import cprint
from nnstar.result import Result

# single-run timeout in seconds. note this doesn't apply in subprocesses (for acasxu_generic.py)
TIMEOUT = 60 * 60

ACCUMULATE_ONLY = False

# should we store results in the AWS folder?
IS_AWS = False

def main():
    'main entry point'

    # hard:
    # net = (4, 2)
    # spec = 2

    # medium:
    net = (4, 2)
    spec = 2

    start = time.time()

    for aws in [True, False]:
        if aws and not IS_AWS:
            print("skiping aws measurement...")
            continue
        
        for method_name in ['multibfs']:
            num_cores = 96 if aws else len(os.sched_getaffinity(0))
            
            core_list = []
            time_list = []

            while True:
                secs = measure(method_name, num_cores, spec, net[0], net[1], aws)

                core_list.append(num_cores)
                time_list.append(secs)

                # decrease number of cores for next iteration
                if num_cores == 1:
                    break

                num_cores = int(math.floor(num_cores / 1.3))

            aws_str = "aws" if aws else "local"
            
            filename = f'results/{method_name}_{aws_str}_parallel.dat'

            with open(filename, "w") as f:
                for cores, secs in zip(core_list, time_list):
                    f.write(f"{cores}\t{secs}\n")

            print(f"\nWrote results summary to {filename}")

    mins = (time.time() - start) / 60.0
    print(f"Finished in {round(mins, 2)} minutes")

def measure(method_name, num_cores, spec, a_prev, tau, aws):
    '''run a generic comparison with the given settings
    '''

    # make sure results directory exists
    folder = 'results'
    
    if not os.path.exists(folder):
        os.makedirs(folder)

    if aws:
        indiv_folder = os.path.join(folder, 'individual_aws')
    else:
        indiv_folder = os.path.join(folder, 'individual')

    if not os.path.exists(indiv_folder):
        os.makedirs(indiv_folder)

    ###############################
    aws_str = "aws" if aws else "local"

    cprint(f"\nRunning {method_name} ({num_cores} cores) {aws_str}", "grey", "on_blue")
    print("")

    res_str, secs = run_single(indiv_folder, method_name, num_cores, a_prev, tau, spec, aws)

    s = f"{a_prev}_{tau}\t{spec}\t{res_str}\t{secs}"

    print(s)

    if res_str in ["timeout", "error", "none"]:
        print(f"WARNING: result was {res_str}")
        secs = TIMEOUT

    return secs

def run_single(indiv_folder, method_name, num_cores, a_prev, tau, spec, aws):
    '''
    run a single measurement (or load cached result)

    returns res_str, secs
    '''

    filename = f"{method_name}{num_cores}_{a_prev}_{tau}_{spec}.dat"
    path = os.path.join(indiv_folder, filename)

    res_str = None
    secs = None

    timeout_rerun = TIMEOUT # if timeone was less than this, result gets re-ran

    if os.path.exists(path):
        # try opening and read results from file
        with open(path, "r") as f:
            res_str = f.readline().strip()
            secs = f.readline().strip()

        try:
            secs = float(secs)
        except ValueError:
            print(f"float convert error with {path}")
            res_str = 'error'
            secs = 0

        if res_str == 'error' or (res_str == 'timeout' and secs < timeout_rerun):
            print(f"\n{path}: res_str was '{res_str}', with time {secs}, rerunning measurement")
            
            # re-run
            res_str = None
            secs = None

    if res_str is None:            
        net_pair = (a_prev, tau)

        res_str = "none"
        secs = "-"

        aws_str = "aws" if aws else "local"
                    
        cprint(f"\nRunning {method_name} on network {net_pair} with spec {spec} {aws_str}", "grey", "on_green")

        # if we're just accumulating for AWS
        if aws and not IS_AWS:
            print("skipping aws measurment")
        elif ACCUMULATE_ONLY:
            print("skipping measurement (accumulate only)")
        else:
            res_str, secs = run_process(net_pair, spec, method_name, num_cores)

            # write the cache file
            with open(path, "w") as f:
                f.write(f'{res_str}\n{secs}')

    return res_str, secs

def run_process(net_pair, spec, method_name, num_cores):
    '''create a new process and run a measurement

    returns result_str, secs
    '''

    start = time.perf_counter()

    args = [sys.executable, "acasxu_generic.py", str(net_pair[0]), str(net_pair[1]), str(spec),
            method_name, str(num_cores)]
    result = subprocess.run(args, check=False)

    if 0 <= result.returncode < len(Result.results):        
        res_str = Result.results[result.returncode]
    else:
        res_str = 'error'

    diff = time.perf_counter() - start

    return res_str, diff

if __name__ == '__main__':
    main()
