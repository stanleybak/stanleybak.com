clear
% measure 5-10, skiping perop 7 and 9

timeout_sec = 10 * 60 * 60; % 10 hours

if ~exist('individual', 'dir')
   mkdir('individual')
end

% before running the loop, verify a simple property to warm up the parallel
% pool / cache
start_clock = clock;
lb = [1500; -0.06; 3.1; 980; 960];
ub = [1501; -0.06; 3.11; 980; 960];
unsafe_mat = [1 -1 0 0 0; 1 0 -1 0 0; 1 0 0 -1 0; 1 0 0 0 -1];
unsafe_vec = [0; 0; 0; 0];
[results, ~] = verify_index(2, 3, 3, 7);
fprintf("\nDone warming up parallel pool.\n");
 
% 1 = approx, 2 = exact
name = 'exact';
func_index = 2;

prop_n1_n2 = [5, 1, 1; 61, 1, 1; 62, 1, 1; 10, 4, 5 ; 8, 2, 9];

% NOTE: sometimes we used easier properties since disjunctive properties 
% are harder to encode, and the majority of runtime is the 
% enumeration process as opposed to safety checking

for index = 1:size(prop_n1_n2, 1)
    p0 = prop_n1_n2(index, 1);
    n1 = prop_n1_n2(index, 2);
    n2 = prop_n1_n2(index, 3);
    
    fprintf('\nRunning on prop: %d; Network: %d-%d\n', p0, n1, n2);
    
    switch p0
        case 5
            lb = [250; 0.2; -3.141592; 100; 0];
        	ub = [400; 0.4; -3.141592 + 0.005; 400; 400];
        
            % easier spec: unsafe if strong right > weak right
            unsafe_mat = [0 0 1 0 -1];
            unsafe_vec = [0];
            
        case 61
            lb = [12000; 0.7; -3.141592; 100; 0];
            ub = [62000; 3.141592; -3.141592 + 0.005; 1200; 1200];
            
            % easier spec: unsafe if coc > weak right
            unsafe_mat = [-1 0 1 0 0];
            unsafe_vec = [0];
        
        case 62
            lb = [12000; -3.141592; -3.141592; 100; 0];
            ub = [62000; -0.7; -3.141592 + 0.005; 1200; 1200];
            
            % easier spec: unsafe if coc > weak right
            unsafe_mat = [-1 0 1 0 0];
            unsafe_vec = [0];
            
        case 7
        	lb = [0; -3.141592; -3.141592; 100; 0];
            ub = [60760; 3.141592; 3.141592; 1200; 1200];
            
            % original spec: unsafe if strong left or strong right is minimal
% Result: network is UNSAFE, confirmed counterexample:
% Input: [-0.32842287715105956, -0.49572953606516656, -0.4699416952788917, 0.2731880371715635, -0.4697236838874057]
% Output: [-0.020234483767271657, -0.019691020245034118, -0.01989446415122484, -0.020614834566997232, -0.020236402225987833]

            % easier spec to encode: unsafe if strong left less than coc,
            % left, and weak right
            unsafe_mat = [-1, 0, 0, 1, 0; 0, -1, 0, 1, 0; 0, 0, -1, 1, 0];
            unsafe_vec = [0, 0, 0];
                                   
        case 8
            lb = [0; -3.141592; -0.1; 600; 600];
            ub = [60760; -0.75*3.141592; 0.1; 1200; 1200];
            
            % original spec: weak left or coc is minimal
% Result: network is UNSAFE, confirmed counterexample:
% Input: [-0.32842287715105956, -0.49214904515666835, 0.015915494309188486, 0.02666242070604799, 0.11368791701443262]
% Output: [0.019466615800431693, -0.02168992749574757, 0.018760405342879045, -0.01805831009985866, 0.018814052679411806]

            % easier spec: unsafe if strong_left < weak left and strong_left < coc
            unsafe_mat = [-1 0 0 1 0; 0 -1 0 1 0];
            unsafe_vec = [0; 0];
        case 10
            lb = [36000; 0.7; -3.141592; 900; 600];
            ub = [60760; 3.141592; -3.141592 + 0.01; 1200; 1200];
            
            % easier spec: unsafe if coc > weak right
            unsafe_mat = [-1 0 1 0 0];
            unsafe_vec = [0];
        otherwise
            fprintf('ERRRO: unknown prop %d. Skipping.\n', p0);
            break
    end

    fprintf("Running prop=%d, n=(%d, %d)\n", p0, n1, n2);

    filename = sprintf('individual/%s_%d_%d_%d.dat', name, p0, n1, n2);

    if false && exist(filename, 'file')
        fid = fopen(filename,'r');
        assert(fid > 0);

        line1 = fgetl(fid);
        line2 = fgetl(fid);

        fclose(fid);

         fprintf("(loaded) f=%d, prop=%d, n=(%d, %d), result: %s, with total time: %s\n", ...
            func_index, p0, n1, n2, line1, line2);
    else

        % %%%%%%%%%%%% exact star
        start_clock = clock;

        %profile on
        [results, ~] = verify_index(func_index, p0, n1, n2);
        result_str = 'error';

        %profile viewer
        if etime(clock, start_clock) > timeout_sec || results.total_time > timeout_sec
            result_str = 'timeout';
            time = timeout_sec + 0.001;
        else
            time = results.total_time;

            if results.safe == -1
                result_str = 'none';
            elseif results.safe == 0
                result_str = 'unsafe';
            elseif results.safe == 1
                result_str = 'safe';
            else
                result_str = 'error';
                fprintf("result was: %d\n", results.safe);
            end
        end

        % -1 = unknown, 0 = unsafe, 1 = safe
        fprintf("\nf=%d, prop=%d, n=(%d, %d), result: %s, with total time: %f (%f)\n", ...
            func_index, p0, n1, n2, result_str, time, results.total_time);

        filename = sprintf('individual/%s_%d_%d_%d.dat', name, p0, n1, n2);

        fid = fopen(filename,'w'); 
        assert(fid > 0)
        fprintf(fid, '%s\n', result_str) ;
        fprintf(fid, '%f', time);
        fclose(fid) ;
    end
end

%% helper functions
function [results, R1] = verify_P0_N00_star_appr(P0, N1, N2)

% addpath(genpath("../../engine"));
% addpath(genpath("../../tbxmanager"));
% addpath("nnet-mat-files/")

lb = evalin('base', 'lb');
ub = evalin('base', 'ub');
unsafe_mat = evalin('base', 'unsafe_mat');
unsafe_vec = evalin('base', 'unsafe_vec');

load(['ACASXU_run2a_',num2str(N1),'_',num2str(N2),'_batch_2000.mat']);

Layers = [];
n = length(b);
for i=1:n - 1
    bi = cell2mat(b(i));
    Wi = cell2mat(W(i));
    Li = LayerS(Wi, bi, 'poslin');
    Layers = [Layers Li];
end
bn = cell2mat(b(n));
Wn = cell2mat(W(n));
Ln = LayerS(Wn, bn, 'purelin');

Layers = [Layers Ln];
F = FFNNS(Layers);

% normalize input
for i=1:5
    lb(i) = (lb(i) - means_for_scaling(i))/range_for_scaling(i);
    ub(i) = (ub(i) - means_for_scaling(i))/range_for_scaling(i);   
end

I = Star(lb, ub);


[R1, ~] = F.reach(I, 'approx-star'); % approximate reach set using star

if isempty(R1)
    results.safe = -1;
    results.set_number = length(F.outputSet);
    results.total_time =  F.totalReachTime;
else
    normalized_mat = range_for_scaling(6) * eye(5);
    normalized_vec = means_for_scaling(6) * ones(5,1);

    t = tic;
    %fprintf('\nVerifying over-approximate star reach set...');
    R1_norm = R1.affineMap(normalized_mat, normalized_vec); % over-approximate normalized reach set using star
    S = R1_norm.intersectHalfSpace(unsafe_mat, unsafe_vec);
    check_time = toc(t);

    if isempty(S)
        safe = 1;
    else
        safe = -1;
    end

    results.safe = safe;
    results.set_number = length(F.outputSet);
    results.total_time = check_time + F.totalReachTime;
%save(['batch_star_appr\P',num2str(P0),'_N',num2str(N1),num2str(N2),'_star_appr.mat'],'results')
end

end

function [results, R1] = verify_P0_N00_star(P0, N1, N2)

% addpath(genpath("../../engine"));
% addpath(genpath("../../tbxmanager"));
% addpath("nnet-mat-files/")

lb = evalin('base', 'lb');
ub = evalin('base', 'ub');
unsafe_mat = evalin('base', 'unsafe_mat');
unsafe_vec = evalin('base', 'unsafe_vec');

load(['ACASXU_run2a_',num2str(N1),'_',num2str(N2),'_batch_2000.mat']);

Layers = [];
n = length(b);
for i=1:n - 1
    bi = cell2mat(b(i));
    Wi = cell2mat(W(i));
    Li = LayerS(Wi, bi, 'poslin');
    Layers = [Layers Li];
end
bn = cell2mat(b(n));
Wn = cell2mat(W(n));
Ln = LayerS(Wn, bn, 'purelin');

Layers = [Layers Ln];
F = FFNNS(Layers);

% normalize input
for i=1:5
    lb(i) = (lb(i) - means_for_scaling(i))/range_for_scaling(i);
    ub(i) = (ub(i) - means_for_scaling(i))/range_for_scaling(i);   
end

I = Star(lb, ub);

c = parcluster('local');
numCores = c.NumWorkers;
%numCores = 1

[R1, ~] = F.reach(I, 'exact-star', numCores); % exact reach set using star

 start_clock = evalin('base', 'start_clock');
timeout_sec = evalin('base', 'timeout_sec');

if etime(clock, start_clock) > timeout_sec % timeout
    safe = -1;
    check_time = 0;
else
    normalized_mat = range_for_scaling(6) * eye(5);
    normalized_vec = means_for_scaling(6) * ones(5,1);

    t = tic;
    n = length(R1);
    R1_norm = [];
    parfor i=1:n
        R1_norm = [R1_norm  R1(i).affineMap(normalized_mat, normalized_vec)]; % exact normalized reach set
    end
    check_time = toc(t);

    t = tic;
    %fprintf('\nVerifying exact star reach set...');
    unsafe = 0;
    n = length(R1);
    
    fprintf("\nlength(R1) (stars): %d", n);
    
    parfor i=1:n
        S = R1_norm(i).intersectHalfSpace(unsafe_mat, unsafe_vec);
        if ~isempty(S)
            unsafe = unsafe + 1;
        end
    end

    check_time = check_time + toc(t);

    if unsafe>=1
        safe = 0;
    else
        safe = 1;
    end
end

results.safe = safe;
results.set_number = length(F.outputSet);
results.total_time = check_time + F.totalReachTime;
%save(['batch_star\P',num2str(P0),'_N',num2str(N1),num2str(N2),'_star.mat'],'results')

end

function [results, R1] = verify_index(index, P0, N1, N2)
    if index == 1
        [results, R1] = verify_P0_N00_star_appr(P0, N1, N2);
    else
        assert(index == 2);
        [results, R1] = verify_P0_N00_star(P0, N1, N2);
    end
end 
