clear
% 3 5 1 - 40 secs
% 3 3 7- 1.1 secs

timeout_sec = 24 * 60 * 60; %  24 hours

if ~exist('individual', 'dir')
   mkdir('individual')
end

% before running the loop, verify a simple property to warm up the parallel
% pool / cache
start_clock = clock;
lb = [1500; -0.06; 3.1; 980; 960];
ub = [1501; -0.06; 3.11; 980; 960];
unsafe_mat = [1 -1 0 0 0; 1 0 -1 0 0; 1 0 0 -1 0; 1 0 0 0 -1];
unsafe_vec = [0; 0; 0; 0];
[results, ~] = verify_index(2, 3, 3, 7);
fprintf("\nDone warming up parallel pool.\n");
 
% 1 = approx, 2 = exact
names = {'approx', 'exact'};
for func_index=2:2
    % property 9
    lb = [2000; -0.4; -3.141592; 100; 0];
    ub = [7000; -0.14; -3.141592 + 0.01; 150; 150];
    
    % disjunctive unsafe mat... instead use simpler unsafe if left > strong_left
    unsafe_mat = [0 1 0 -1 0];
    unsafe_vec = [0];
    p0 = 9;

    for n1 = 3:3
        for n2 = 3:3
            name = names{func_index};
            fprintf("Running %s, prop=%d, n=(%d, %d)\n", name, p0, n1, n2);

            filename = sprintf('individual/%s_%d_%d_%d.dat', name, p0, n1, n2);

            if exist(filename, 'file')
                fid = fopen(filename,'r');
                assert(fid > 0);

                line1 = fgetl(fid);
                line2 = fgetl(fid);

                fclose(fid);

                 fprintf("(loaded) f=%d, prop=%d, n=(%d, %d), result: %s, with total time: %s\n", ...
                    func_index, p0, n1, n2, line1, line2);
            else

                % %%%%%%%%%%%% exact star
                start_clock = clock;

                %profile on
                [results, ~] = verify_index(func_index, p0, n1, n2);
                result_str = 'error';

                %profile viewer
                if etime(clock, start_clock) > timeout_sec || results.total_time > timeout_sec
                    result_str = 'timeout';
                    time = timeout_sec + 0.001;
                else
                    time = results.total_time;

                    if results.safe == -1
                        result_str = 'none';
                    elseif results.safe == 0
                        result_str = 'unsafe';
                    elseif results.safe == 1
                        result_str = 'safe';
                    else
                        result_str = 'error';
                        fprintf("result was: %d\n", results.safe);
                    end
                end

                % -1 = unknown, 0 = unsafe, 1 = safe
                fprintf("\nf=%d, prop=%d, n=(%d, %d), result: %s, with total time: %f (%f)\n", ...
                    func_index, p0, n1, n2, result_str, time, results.total_time);

                name = names{func_index};
                filename = sprintf('individual/%s_%d_%d_%d.dat', name, p0, n1, n2);

                fid = fopen(filename,'w'); 
                assert(fid > 0)
                fprintf(fid, '%s\n', result_str) ;
                fprintf(fid, '%f', time);
                fclose(fid) ;
            end
        end
    end
end


%% helper functions
function [results, R1] = verify_P0_N00_star_appr(P0, N1, N2)

% addpath(genpath("../../engine"));
% addpath(genpath("../../tbxmanager"));
% addpath("nnet-mat-files/")

lb = evalin('base', 'lb');
ub = evalin('base', 'ub');
unsafe_mat = evalin('base', 'unsafe_mat');
unsafe_vec = evalin('base', 'unsafe_vec');

load(['ACASXU_run2a_',num2str(N1),'_',num2str(N2),'_batch_2000.mat']);

Layers = [];
n = length(b);
for i=1:n - 1
    bi = cell2mat(b(i));
    Wi = cell2mat(W(i));
    Li = LayerS(Wi, bi, 'poslin');
    Layers = [Layers Li];
end
bn = cell2mat(b(n));
Wn = cell2mat(W(n));
Ln = LayerS(Wn, bn, 'purelin');

Layers = [Layers Ln];
F = FFNNS(Layers);

% normalize input
for i=1:5
    lb(i) = (lb(i) - means_for_scaling(i))/range_for_scaling(i);
    ub(i) = (ub(i) - means_for_scaling(i))/range_for_scaling(i);   
end

I = Star(lb, ub);


[R1, ~] = F.reach(I, 'approx-star'); % approximate reach set using star

if isempty(R1)
    results.safe = -1;
    results.set_number = length(F.outputSet);
    results.total_time =  F.totalReachTime;
else
    normalized_mat = range_for_scaling(6) * eye(5);
    normalized_vec = means_for_scaling(6) * ones(5,1);

    t = tic;
    %fprintf('\nVerifying over-approximate star reach set...');
    R1_norm = R1.affineMap(normalized_mat, normalized_vec); % over-approximate normalized reach set using star
    S = R1_norm.intersectHalfSpace(unsafe_mat, unsafe_vec);
    check_time = toc(t);

    if isempty(S)
        safe = 1;
    else
        safe = -1;
    end

    results.safe = safe;
    results.set_number = length(F.outputSet);
    results.total_time = check_time + F.totalReachTime;
%save(['batch_star_appr\P',num2str(P0),'_N',num2str(N1),num2str(N2),'_star_appr.mat'],'results')
end

end

function [results, R1] = verify_P0_N00_star(P0, N1, N2)

% addpath(genpath("../../engine"));
% addpath(genpath("../../tbxmanager"));
% addpath("nnet-mat-files/")

lb = evalin('base', 'lb');
ub = evalin('base', 'ub');
unsafe_mat = evalin('base', 'unsafe_mat');
unsafe_vec = evalin('base', 'unsafe_vec');

load(['ACASXU_run2a_',num2str(N1),'_',num2str(N2),'_batch_2000.mat']);

Layers = [];
n = length(b);
for i=1:n - 1
    bi = cell2mat(b(i));
    Wi = cell2mat(W(i));
    Li = LayerS(Wi, bi, 'poslin');
    Layers = [Layers Li];
end
bn = cell2mat(b(n));
Wn = cell2mat(W(n));
Ln = LayerS(Wn, bn, 'purelin');

Layers = [Layers Ln];
F = FFNNS(Layers);

% normalize input
for i=1:5
    lb(i) = (lb(i) - means_for_scaling(i))/range_for_scaling(i);
    ub(i) = (ub(i) - means_for_scaling(i))/range_for_scaling(i);   
end

I = Star(lb, ub);

c = parcluster('local');
numCores = c.NumWorkers;
%numCores = 1

[R1, ~] = F.reach(I, 'exact-star', numCores); % exact reach set using star

 start_clock = evalin('base', 'start_clock');
timeout_sec = evalin('base', 'timeout_sec');

if etime(clock, start_clock) > timeout_sec % timeout
    safe = -1;
    check_time = 0;
else
    normalized_mat = range_for_scaling(6) * eye(5);
    normalized_vec = means_for_scaling(6) * ones(5,1);

    t = tic;
    n = length(R1);
    R1_norm = [];
    parfor i=1:n
        R1_norm = [R1_norm  R1(i).affineMap(normalized_mat, normalized_vec)]; % exact normalized reach set
    end
    check_time = toc(t);

    t = tic;
    %fprintf('\nVerifying exact star reach set...');
    unsafe = 0;
    n = length(R1);
    
    fprintf("\nlength(R1) (stars): %d", n);
    
    parfor i=1:n
        S = R1_norm(i).intersectHalfSpace(unsafe_mat, unsafe_vec);
        if ~isempty(S)
            unsafe = unsafe + 1;
        end
    end

    check_time = check_time + toc(t);

    if unsafe>=1
        safe = 0;
    else
        safe = 1;
    end
end

results.safe = safe;
results.set_number = length(F.outputSet);
results.total_time = check_time + F.totalReachTime;
%save(['batch_star\P',num2str(P0),'_N',num2str(N1),num2str(N2),'_star.mat'],'results')

end

function [results, R1] = verify_index(index, P0, N1, N2)
    if index == 1
        [results, R1] = verify_P0_N00_star_appr(P0, N1, N2);
    else
        assert(index == 2);
        [results, R1] = verify_P0_N00_star(P0, N1, N2);
    end
end 
