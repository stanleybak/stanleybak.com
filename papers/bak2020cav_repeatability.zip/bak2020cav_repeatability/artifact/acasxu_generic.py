'''
Stanley Bak

generic ACAS-Xu analyis script

Use verify_acasxu(net, spec) to verify a specific instance
'''

import sys
import multiprocessing

from scipy.io import loadmat
import numpy as np

from nnstar.enumerate import enumerate_network
from nnstar.network import weights_biases_to_nn, FullyConnectedLayer

from nnstar.specification import Specification, DisjunctiveSpec
from nnstar.result import Result
from nnstar.settings import Settings

def get_init_box(property_num):
    'get lb, ub lists for the given property'

    if property_num in (1, 2):
        init_lb = [55947.691, -3.141592, -3.141592, 1145, 0]
        init_ub = [60760, 3.141592, 3.141592, 1200, 60]
    elif property_num == 3:
        init_lb = [1500, -0.06, 3.1, 980, 960]
        init_ub = [1800, 0.06, 3.141592, 1200, 1200]
    elif property_num == 4:
        init_lb = [1500, -0.06, 0, 1000, 700]
        init_ub = [1800, 0.06, 0, 1200, 800]
    elif property_num == 5:
        init_lb = [250, 0.2, -3.141592, 100, 0]
        init_ub = [400, 0.4, -3.141592 + 0.005, 400, 400]
    elif property_num == 6.1:
        init_lb = [12000, 0.7, -3.141592, 100, 0]
        init_ub = [62000, 3.141592, -3.141592 + 0.005, 1200, 1200]
    elif property_num == 6.2:
        init_lb = [12000, -3.141592, -3.141592, 100, 0]
        init_ub = [62000, -0.7, -3.141592 + 0.005, 1200, 1200]
    elif property_num == 7:
        init_lb = [0, -3.141592, -3.141592, 100, 0]
        init_ub = [60760, 3.141592, 3.141592, 1200, 1200]
    elif property_num == 8:
        init_lb = [0, -3.141592, -0.1, 600, 600]
        init_ub = [60760, -0.75*3.141592, 0.1, 1200, 1200]
    elif property_num == 9:
        init_lb = [2000, -0.4, -3.141592, 100, 0]
        init_ub = [7000, -0.14, -3.141592 + 0.01, 150, 150]
    elif property_num == 10:
        init_lb = [36000, 0.7, -3.141592, 900, 600]
        init_ub = [60760, 3.141592, -3.141592 + 0.01, 1200, 1200]
    else:
        raise RuntimeError(f"init_box undefined for property {property_num}")

    #print("Warning: small init")
    #init_lb[0] = init_ub[0] - 1
    #init_lb[1] = init_ub[1] - 0.001

    return init_lb, init_ub

def is_minimal_spec(index):
    'create a disjunctive spec that a specific output is minimal'

    spec_list = []

    for i in range(5):
        if i == index: # index 3 is strong left
            continue

        l = [0, 0, 0, 0, 0]
        l[index] = -1
        l[i] = 1

        spec_list.append(Specification([l], [0]))

    return DisjunctiveSpec(spec_list)

def get_spec(property_num):
    'get the specification'

    #labels = ['Clear of Conflict (COC)', 'Weak Left', 'Weak Right', 'Strong Left', 'Strong Right']
    if property_num == 1:
        # unsafe if COC >= 1500

        # Output scaling is 373.94992 with a bias of 7.518884
        # (1500 - 7.518884) / 373.94992 = 3.991125
        threshold = (1500 - 7.518884) / 373.94992
        spec = Specification([[-1, 0, 0, 0, 0]], [-threshold])
        
    elif property_num == 2:
        # unsafe if COC is maximal:
        # y0 > y1 and y0 > y1 and y0 > y2 and y0 > y3 and y0 > y4
        spec = Specification([[-1, 1, 0, 0, 0],
                              [-1, 0, 1, 0, 0],
                              [-1, 0, 0, 1, 0],
                              [-1, 0, 0, 0, 1]], [0, 0, 0, 0])
    elif property_num in (3, 4):
        # unsafe if COC is minimal score
        spec = Specification([[1, -1, 0, 0, 0],
                              [1, 0, -1, 0, 0],
                              [1, 0, 0, -1, 0],
                              [1, 0, 0, 0, -1]], [0, 0, 0, 0])
    elif property_num == 5:
        # strong right should be minimal
        spec = is_minimal_spec(4)
    elif property_num in [6.1, 6.2, 10]:
        # coc should be mininal
        spec = is_minimal_spec(0)
    elif property_num == 7:
        # unsafe if strong left is minimial or strong right is minimal
        spec_left = Specification([[-1, 0, 0, 1, 0],
                                   [0, -1, 0, 1, 0],
                                   [0, 0, -1, 1, 0]], [0, 0, 0])

        spec_right = Specification([[-1, 0, 0, 0, 1],
                                    [0, -1, 0, 0, 1],
                                    [0, 0, -1, 0, 1]], [0, 0, 0])
        
        spec = DisjunctiveSpec([spec_left, spec_right])
    elif property_num == 8:
        # weak left is minimal or COC is minimal
        coc_min = is_minimal_spec(0)
        left_min = is_minimal_spec(1)

        spec = DisjunctiveSpec([coc_min, left_min])
        
    elif property_num == 9:
        # strong left should be minimal...
        spec = is_minimal_spec(3)
        
    else:
        raise RuntimeError(f"spec undefined for property {property_num}")

    return spec

def load_init_network(net_pair, property_num):
    '''load the network / spec and return it

    the network is based on the net_pair, using specification spec

    returns (init_box, network, spec)
    '''

    # load the network and prepare input / output specs
    n1, n2 = net_pair
    matfile = loadmat(f'acasxu/ACASXU_run2a_{n1}_{n2}_batch_2000.mat')

    weights = matfile['W'][0]
    biases = matfile['b'][0]

    for b in biases:
        b.shape = (len(b),)

    range_for_scaling = matfile['range_for_scaling'][0]
    means_for_scaling = matfile['means_for_scaling'][0]

    num_inputs = weights[0].shape[1]
    init_lb, init_ub = get_init_box(property_num)

    # normalize input
    for i in range(num_inputs):
        init_lb[i] = (init_lb[i] - means_for_scaling[i]) / range_for_scaling[i]
        init_ub[i] = (init_ub[i] - means_for_scaling[i]) / range_for_scaling[i]

        #print(f"Input {i}: {init_lb[i], init_ub[i]}")

    print(f"input ub: {init_ub}")
    print(f"input lb: {init_lb}")

    spec = get_spec(property_num)
    
    init_box = list(zip(init_lb, init_ub))
    
    network = weights_biases_to_nn(weights, biases)

    scale_outputs = False

    if scale_outputs:
        # add one more layer to the network for the output scaling
        output_mult, output_bias = range_for_scaling[-1], means_for_scaling[-1]
        output_mult_mat = np.identity(5) * output_mult
        output_bias_vec = np.array([output_bias] * 5, dtype=float)
        layer_num = len(network.layers)
        network.layers.append(FullyConnectedLayer(layer_num, output_mult_mat, output_bias_vec, False))

    return init_box, network, spec

def verify_acasxu(net, spec):
    ''''verify a system, 

    returns a verification result object'''

    assert spec != 6, "spec 6 is a disjunctive initial set, use 6.1 or 6.2 for the two parts"

    required_spec_net_list = [
        [5, (1, 1)],
        [6.1, (1, 1)],
        [6.2, (1, 1)],
        [7, (1, 9)],
        [8, (2, 9)],
        [9, (3, 3)],
        [10, (4, 5)]]

    for req_spec, tup in required_spec_net_list:
        if spec == req_spec:
            assert net == tup, f"spec {spec} should only be run on net {tup}"

    init_box, network, spec = load_init_network(net, spec)
    res = enumerate_network(init_box, network, spec)

    return res

# method-specific settings. Function retuns name of method
def bfs():
    'set settings'

    Settings.LOCAL_DFS = False
    Settings.USE_PRESOLVER = False
    Settings.PREFILTER_EAGER_BOUNDS = False
    Settings.NUM_PROCESSES = 1
    Settings.PREFILTER_TYPE = Settings.TYPE_COPY_PREFILTER

    return 'bfs'

def copy():
    'set settings'

    Settings.LOCAL_DFS = True
    Settings.USE_PRESOLVER = False
    Settings.PREFILTER_EAGER_BOUNDS = False
    Settings.NUM_PROCESSES = 1
    Settings.PREFILTER_TYPE = Settings.TYPE_COPY_PREFILTER

    return 'copy'

def bounds():
    'set settings'

    Settings.PREFILTER_TYPE = Settings.TYPE_NO_PREFILTER

    return 'bounds'

def sim():
    'set settings'

    Settings.PREFILTER_TYPE = Settings.TYPE_SIM_PREFILTER

    return 'sim'

def zono():
    'set settings'

    Settings.PREFILTER_TYPE = Settings.TYPE_ZONO_PREFILTER
    Settings.ZONO_PREFILTER_USE_SIM = False
    Settings.CONTRACT_ZONOTOPE = False

    return 'zono'

def zono_sim():
    'set settings'

    Settings.ZONO_PREFILTER_USE_SIM = True

    return 'zonosim'

def eager():
    'set settings'

    Settings.PREFILTER_EAGER_BOUNDS = True

    return 'eager'

def contractlp():
    'set settings'

    Settings.CONTRACT_ZONOTOPE_LP = True

    return 'contractlp'

def contract():
    'set settings'

    Settings.CONTRACT_ZONOTOPE_LP = False
    Settings.CONTRACT_ZONOTOPE = True

    return 'contract'

def multidfs():
    'set settings'

    Settings.LOCAL_DFS = True
    Settings.OFFLOAD_CLOSEST_TO_ROOT = True
    Settings.NUM_PROCESSES = multiprocessing.cpu_count() # use multiple cores

    return 'multidfs'

def multibfs():
    'set settings'

    Settings.OFFLOAD_CLOSEST_TO_ROOT = False

    return 'multibfs'

def main():
    'used when running as subprocess'

    if len(sys.argv) < 5:
        print("expected at least 4 args: net1 net2 spec_num settings_name [num_processes] [timeout]")
        sys.exit(Result.results.index('error'))

    net1 = int(sys.argv[1])
    net2 = int(sys.argv[2])
    spec_num = float(sys.argv[3])
    settings_name = sys.argv[4]
    override_num_cores = None
    override_timeout = None

    if len(sys.argv) > 5:
        override_num_cores = int(sys.argv[5])

    if len(sys.argv) > 6:
        override_timeout = float(sys.argv[6])

    # set settings
    methods = [bfs, copy, bounds, sim, zono, zono_sim, eager, contractlp, contract, multidfs, multibfs]

    Settings.reset()

    found = False

    for method in methods:
        name = method()

        if name == settings_name:
            found = True
            break

    assert found, f"settings {settings_name} not found"

    print(f"Using settings profile: '{settings_name}'. Override num process: {override_num_cores}")

    if override_num_cores is not None and override_num_cores > 0:
        assert override_num_cores < 1e6
        Settings.NUM_PROCESSES = override_num_cores

    if override_timeout is not None:
        Settings.TIMEOUT = override_timeout
            
    res = verify_acasxu((net1, net2), spec_num)

    sys.exit(Result.results.index(res.result_str))

def print_marabou_specs():
    'print marabou specs 5-10'

    # example output:
    # x0 >= -0.295234
    # x0 <= -0.212262
    # x1 >= -0.063662
    # x1 <= -0.022282
    # ...
    # +y1 -y3 <= 0

    required_spec_net_list = [
        [5, (1, 1)],
        [6.1, (1, 1)],
        [6.2, (1, 1)],
        [7, (1, 9)],
        [8, (2, 9)],
        [9, (3, 3)],
        [10, (4, 5)]]

    for spec, net in required_spec_net_list:
        print(f"\nSpec {spec}:")

        init_box, _, _ = load_init_network(net, spec)

        for i, (lb, ub) in enumerate(init_box):
            print(f"x{i} >= {lb}")
            print(f"x{i} <= {ub}")
        

    print("finished printing marabou specs")

if __name__ == '__main__':
    main()

    #print("debug: printing marabou specs")
    #print_marabou_specs()
