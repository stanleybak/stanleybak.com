set terminal pdfcairo enhanced dashed font 'Verdana,18' fontscale 0.45 dl 0.4

set size ratio 0.5
set lmargin at screen 0.12
set rmargin at screen 0.98
set bmargin at screen 0.15
set tmargin at screen 0.9

set autoscale

set xtic auto
set ytic auto
set xlabel "Number of Cores" offset 0,0.5
set ylabel "Time (sec)" offset 2.2,0

set style line 1 lc rgb "#0000ff" lt 1 lw 1.5 pt 7 ps 0.8
set style line 2 lc rgb "#ff0000" lt 1 lw 1.5 pt 6 ps 0.8 pi -1

set style line 3 lc rgb "#000000" lt 1 lw 1.5 

set style line 9 lc rgb "#808080" lw 2 pt 13 ps 0.8 dt 2

set key on top right

set logscale y
set logscale x 2

set xrange [1:]
set yrange [10:]

set output 'parallel.pdf'

set title 'Parallelization Evaluation' font 'Verdana,28' offset 0,-1

# For paper plot, use aws measurement
#stats "results/multibfs_aws_parallel.dat" using 1:2 nooutput
stats "results/multibfs_local_parallel.dat" using 1:2 nooutput

set arrow 50 from 1, 60 to STATS_max_x, 60 nohead ls 9
set label 21 "One Minute" at 1.3,60 font 'Verdana,14' tc rgb "#808080" offset 0, 0.4

set arrow 51 from 1, 600 to STATS_max_x, 600 nohead ls 9
set label 22 "Ten Minutes" at 1.3,600 font 'Verdana,14' tc rgb "#808080" offset 0, 0.4

# # physical cores
#set arrow 52 from 48, 25 to 48, 18 head ls 2
#set label 23 "48 Physical Cores" at 48, 25 center font 'Verdana,14' tc rgb "#ff0000" offset 0, 0.4

#set arrow 53 from 6, 240 to 6, 170 head ls 1
#set label 24 "6 Physical Cores" at 6, 240 center font 'Verdana,14' tc rgb "#0000ff" offset 0, 0.4

#set arrow 52 from xmax, ymin_str to xmax, ymax nohead ls 8 
#all_instances_y = int(all_instances_y_str)
#set label 24 "All Instances" at xmax,all_instances_y font 'Verdana,14' tc rgb "#000000" offset -1, 0 rotate right

set grid ytics lc '#606060' lw 0.25 lt 1 dt 3
set grid xtics lc '#606060' lw 0.25 lt 1 dt 3

plot "results/multibfs_local_parallel.dat" using 1:2 title "Laptop" with linespoints ls 1, \
	 "results/multibfs_aws_parallel.dat" using 1:2 title "AWS Server" with linespoints ls 2, 
