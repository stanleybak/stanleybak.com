Things that go wrong:

No output in MNA5 model file (matlab crashes) -> use scipy on raw .mat file to print output

SpaceEx Model Editor freezes when opening model -> Use text editor instead

Cannot open printed .xml and .cfg files -> Use Geany instead of Gedit

Cannot import into Hyst (ANTRL Grammar Exception) -> Use Balanced conjunction instead of recursive
Initial states are 11k * 2 conjunctions

Hyst Stack Overflow -> Internal conversion to unbalanced expression... cannot walk recursively 

Hyst Stack Overflow -> Initial Location extraction created recursive expression. Internal data structure needs two children per AND expression

800 MB Python Script Produced -> OS effectively freezes when reading the script... basically using SWAP is way too slow. Recommend to turn swap off when dealing with large-memory issues.
First line not printed in script -> change Hyst printer to initialize matrix of zeros, and then assign individual elements -> down to 3 MB script size

Out of memory while computing. This is the most serious problem. Basically, each 'dense' matrix takes up ~1GB (8 bytes per entry, 11kx11k entries).
Don't simulate entire system at once. Run a small number of timesteps at a time, then do LP solving, then throw away old simulations and redo simulations.
It would be best if the LP solving could be in-the-loop of the simulation engine, but that's not the interface that python provides with ODEINT, which is the most scalable / fastest simulation method benchmarked
added desired_mb parameter
-> also, python doesn't have threads for paralllellism... instead it uses subprocesses... so memory must be copied
added sparse option, which would pass sparse matrices rather than dense onces.... Also, disabled use of Jacobian parameter to ODE INT... this slows down the simulation a little, but prevents an extra
copy of the matrix from being made.
-> This also solved Python-Pickle errors when passing lage matrices (Python 2.7 has a bug when pickling large objects that would cause random crashes... solution is to upgrade to Python 3).

Still need to tune the desired_mb, some freezing... again, better to turn off swap in these cases. Finally, run 2 steps at a time seemed to work.

Counter-example trace file too large -> need to output sparse matrix definition for dynamics, as well as input conditions.

Strange things: Python crashes with MNA5 occasionally (free issue)... At one point the code kept seg faulting on GLPK calls... even after multiple process restarts... at different points in the code.
