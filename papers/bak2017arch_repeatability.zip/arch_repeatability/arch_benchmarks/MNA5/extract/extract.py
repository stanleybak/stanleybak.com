' Stanley Bak, printing MNA5 to a file to make spaceex files'

import scipy.io as sio

data = sio.loadmat('MNA_5.mat')
tol = 1e-9
first_row = True

a = data['A'].toarray()
b = data['B'].toarray()


with open('mna5_out.py', 'w') as f:
    for var in xrange(len(a)):
        
        if first_row:
            first_row = False
        else:
            f.write("&amp; ")
        
        print "{} / {}".format(var, len(a))
        f.write("x{}' == ".format(var+1))
        
        line = None
        
        # x
        for i in xrange(len(a[var])):
            ele = a[var][i]
            
            if abs(ele) > tol:
                if line is None:
                    var_string = "{}*x{}".format(ele, i+1)
                    line = var_string
                else:
                    if ele < 0:
                        line += " - {}*x{}".format(-ele, i+1)
                    else:
                        line += " + {}*x{}".format(ele, i+1)
                    
        # u
        for i in xrange(len(b[var])):
            ele = b[var][i]
            
            if abs(ele) > tol:
                if line is None:
                    var_string = "{}*u{}".format(ele, i+1)
                    line = var_string
                else:
                    if ele < 0:
                        line += " - {}*u{}".format(-ele, i+1)
                    else:
                        line += " + {}*u{}".format(ele, i+1)
        
        f.write(line)
        f.write("\n")
        
