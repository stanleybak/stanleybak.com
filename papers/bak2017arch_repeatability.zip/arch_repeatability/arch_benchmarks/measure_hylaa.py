'''Script for running the arch benchmark systems with hylaa'''

import os
import time
import sys
import subprocess

# make sure hybridpy is on your PYTHONPATH: hyst/src/hybridpy
import hybridpy.hypy as hypy

def is_safe_result(res):
    '''check a result object and check if the tool's result is safe'''

    return res['safe']

def get_script_path(filename=__file__):
    '''get the path this script'''
    return os.path.dirname(os.path.realpath(filename))

def main():
    '''main entry point'''
    
    timeout_secs = 60 * 60 * 30

    # list of model name (used to define filenames)
    models = []
    models.append('Motor')
    models.append('Building')
    models.append('PDE')
    models.append('Heat')
    models.append('ISS')
    models.append('Beam')
    models.append('MNA1')
    models.append('FOM')
    models.append('MNA5')

    labels = []
    tool_params = []

    tool_params.append('-settings settings.simulation.sim_tol=1e-12')
    tool_params.append('-settings settings.simulation.sim_mode=SimulationSettings.MATRIX_EXP')
    
    labels.append('Simulation')
    labels.append('Matrix~Exp')
    
    assert len(tool_params) == len(labels)

    start = time.time()

    with open('benchmark_results.dat', "w") as f:        
        f.write('{\\bf Model} & {\\bf Dims} & {\\bf Unsafe Error Condition} & {\\bf Method} & {\\bf Step Size} & {\\bf Runtime} & ' +
                '{\\bf Safe?} & {\\bf CE Error} & {\\bf CE Time} \\\\\n')
        f.write('\\midrule\n')

        for model_name in models:
            
            for safe in [True, False]:
                first_model = True
                 
                for i in xrange(len(tool_params)):
                    first_tool_params = True
                    
                    if i == 1 and model_name == 'MNA5':
                        # Matrix Exp on MNA5
                        if safe:
                            steps = ["0.1"]
                        else:
                            steps = ["0.1", "0.01"]
                    else:
                        steps = ["0.1", "0.01", "0.001"]
                    
                    for step in steps:
                        
                        suffix = "" if safe else "_unsafe"
                        outfile = 'out/{}_{}{}_0-{}.py'.format(labels[i], model_name, suffix, step[2:])
                        infile = '{}/{}{}.xml'.format(model_name, model_name, suffix)
                        cfgfile = '{}/{}{}.cfg'.format(model_name, model_name, suffix)
                        trace_file = get_script_path() + '/out/{}_{}{}_0-{}_counterexample.py'.format(labels[i], model_name, suffix, step[2:])
                        params = tool_params[i]
                        
                        params += " settings.simulation.sim_in_memory_mb=6*1024"
                        params += " settings.counter_example_filename='{}'".format(trace_file)
                            
                        if model_name == 'MNA5':
                            params += ' settings.simulation.sparse=True' # was 70; 7000 = ~ 1/3 of 0.001
                            
                        params += " -step {}".format(step)

                        e = hypy.Engine('hylaa', params)
                        e.set_output(outfile)
                        e.set_input(infile)
                        e.add_pass("convert_havoc_flows", "")

                        print "Running '{}' on {} with timeout {}...".format(labels[i], infile, timeout_secs)
                        res = e.run(print_stdout=True, run_tool=True, parse_output=True, timeout=timeout_secs)
                        runtime = "-"
                        safe_checkmark = ""
                        is_safe = False
                        was_timeout = False

                        if res['code'] == hypy.Engine.TIMEOUT_TOOL:
                            was_timeout = True
                            runtime = "Timeout"
                            print "Timeout!"
                        elif res['code'] == hypy.Engine.SUCCESS:
                            runtime = runtime_string(res['tool_time'])
                            is_safe = is_safe_result(res['output'])

                            if is_safe:
                                safe_checkmark = '\\checkmark'

                            print "Completed after {} seconds and result is_safe={}".format(runtime, is_safe)
                        else:
                            #raise RuntimeError("Running Tool Failed: {}".format(res['code']))
                            was_timeout = True
                            runtime = "Error"
                            print "Error!"

                        error_condition, dims, _, original_star = extract_model_data(cfgfile)
                        ce_acc = ""
                        ce_time = ""
                        
                        if not is_safe and not was_timeout:
                            ce_data = get_counter_example_data(trace_file)
                            ce_acc = "${}$".format(ce_data[1]) # 0 is abs error, 1 is rel error
                            ce_time = ce_data[2]
                            
                        # overrides
                        print_model_name = model_name if first_model else ""
                        print_original_star = original_star if first_model else ""
                        print_dims = dims if first_model else ""
                        print_error_condition = error_condition if first_model else ""
                        first_model = False
                        
                        print_label = labels[i] if first_tool_params else ""
                        first_tool_params = False

                        f.write('{}{} & {} & {} & {} & {} & {} & {} & {} & {} \\\\\n'.format(
                            print_model_name, print_original_star, print_dims, print_error_condition, print_label, step, runtime, safe_checkmark, ce_acc, ce_time))
                        f.flush()
                        
                        if was_timeout:
                            break
                       
                    if i != len(tool_params) - 1:
                        f.write('\\hdashline[0.8pt/5pt]\n')
                
                f.write('\\midrule\n')

    dif = time.time() - start
    print "Measurement Completed in {:2f} seconds".format(dif)

def runtime_string(secs):
    'convert a float of seconds into a string for the table'
    
    rv = ""
    
    if secs < 60:
        rv = "{:.1f}s".format(secs)
    elif secs < 60 * 60:
        mins = int(secs / 60)
        secs = int(secs - 60 * mins)
        rv = "{}m{}s".format(mins, secs)
    else:
        mins = secs / 60.0
        hours = int(mins / 60)
        mins = int(mins - 60 * hours)
        rv = "{}h{}m".format(hours, mins)
        
    return rv

def get_counter_example_data(trace_file):
    '''
    get the l-2 norm of the absolute / relative error of the counter-example trace
    
    returns a latex string tuple (abs_error, rel_error, final_time)
    '''

    params = [sys.executable, trace_file, 'noplot']
    rv = ["", "", ""]

    try:
        proc = subprocess.Popen(params, stdout=subprocess.PIPE)

        line = proc.stdout.readline()

        while line:
            # process line
            line = line.strip()
            print line

             # max difference (l-infinity norm): 3.75398923058e-08 in dimension 5
            if "Absolute Error (l-2 norm):" in line:
                abs_error = "{:.1E}".format(float(line.split(" ")[4]))
                # convert to latex 
                parts = abs_error.split('E')
                rv[0] = "{} \\mkern1mu{{\\cdot}} 10^{{ {} }}".format(parts[0], int(parts[1]))

                print "Extracted absolute error: {}".format(rv[0])
            elif "Relative Error (l-2 norm):" in line:
                rel_error = "{:.1E}".format(float(line.split(" ")[4]))
                # convert to latex
                parts = rel_error.split('E')
                rv[1] = "{} \\mkern1mu{{\\cdot}} 10^{{ {} }}".format(parts[0], int(parts[1]))

                print "Extracted relative error: {}".format(rv[1])
            elif "Final Time:" in line:
                rv[2] = line.split(" ")[2]

            line = proc.stdout.readline()

        proc.wait()

    except OSError as e:
        raise RuntimeError("Error running counter-example trace: {}".format(e))

    return rv

def extract_model_data(cfgfile):
    'Extract data from the cfg file text. Returns a tuple of strings: (error_condition, dims, step, original_star)'

    error_condition = '-'
    dims = '-'
    step = '-'
    original_star = ''

    with open(cfgfile) as f:
        for line in f:
            line = line.strip()

            if 'dimensions: ' in line:
                dims = line.split(': ')[1]
            elif 'original system: ' in line:
                original_star = '*' if 'true' in line.split(': ')[1] else ''
            elif 'error condition: ' in line:
                error_condition = line.split(': ')[1]
            elif 'sampling-time = ' in line:
                step = line.split('= ')[1]

    return (error_condition, dims, step, original_star)

if __name__ == '__main__':
    main()
